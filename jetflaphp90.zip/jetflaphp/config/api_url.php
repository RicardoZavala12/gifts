<?php
define('GET_PASAJERO_API', 'http://localhost/jetflaphp/config/api.php?table=pasajeros');
define('GET_ADMINISTRADORES_API', 'http://localhost/jetflaphp/config/api.php?table=administradores');
define('GET_ASIENTOS_API', 'http://localhost/jetflaphp/config/api.php?table=asientos');
define('GET_ASIENTOS_RESERVAS_API', 'http://localhost/jetflaphp/config/api.php?table=asientos_reservas');
define('GET_CODIGOS_PROMOS_API', 'http://localhost/jetflaphp/config/api.php?table=codigos_promos');
define('GET_COSTOS_EXTRAS_API', 'http://localhost/jetflaphp/config/api.php?table=costos_extras');
define('GET_DESTINOS_API', 'http://localhost/jetflaphp/config/api.php?table=destinos');
define('GET_DESTINOS_NUEVOS_API', 'http://localhost/jetflaphp/config/api.php?table=destinos_nuevos');
define('GET_EQUIPAJE_API', 'http://localhost/jetflaphp/config/api.php?table=equipaje');
define('GET_FAQS_API', 'http://localhost/jetflaphp/config/api.php?table=faqs');
define('GET_HISTORIAL_COMPRAS_API', 'http://localhost/jetflaphp/config/api.php?table=historial_compras');
define('GET_IMAGENES_DESTINOS_API', 'http://localhost/jetflaphp/config/api.php?table=imagenes_destinos');
define('GET_RESERVAS_API', 'http://localhost/jetflaphp/config/api.php?table=reservas');
define('GET_VUELOS_API', 'http://localhost/jetflaphp/config/api.php?table=vuelos');