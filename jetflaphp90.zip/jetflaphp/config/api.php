<?php
require 'config.php';
require '../controllers/APIController.php';

// Definir encabezados para la API
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");

// Conectar a la base de datos
$controller = new ApiController($pdo);

// Obtener los parámetros de la URL
$table = $_GET['table'] ?? null;
$idField = null;
$id = null;

// Determinar el campo de ID y el valor del ID basados en la tabla
if ($table) {
    foreach ($_GET as $key => $value) {
        if (strpos($key, 'id_') === 0) {
            $idField = $key;
            $id = (int)$value;
            break;
        }
    }
}

// Determinar el método HTTP
$method = $_SERVER['REQUEST_METHOD'];
$data = json_decode(file_get_contents("php://input"), true);

if ($table) {
    switch ($method) {
        case 'GET':
            $controller->get($table, $idField, $id);
            break;
        case 'POST':
            $controller->create($table, $data);
            break;
        case 'PUT':
            if ($idField && $id) {
                $controller->update($table, $idField, $id, $data);
            } else {
                echo json_encode(['status' => 'error', 'message' => 'Campo de ID o ID no especificado para actualización']);
            }
            break;
        case 'DELETE':
            if ($idField && $id) {
                $controller->delete($table, $idField, $id);
            } else {
                echo json_encode(['status' => 'error', 'message' => 'Campo de ID o ID no especificado para eliminación']);
            }
            break;
        default:
            echo json_encode(['status' => 'error', 'message' => 'Método HTTP no soportado']);
            break;
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Tabla no especificada']);
}
