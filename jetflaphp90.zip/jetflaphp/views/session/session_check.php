<?php
// Verifica si la sesión está activa
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
//session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: index.php?controller=login&action=showLoginForm');
    exit();
}