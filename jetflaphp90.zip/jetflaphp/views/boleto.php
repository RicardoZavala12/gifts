<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Boleto de Avión - Card</title>
    <style>
        /* Estilos generales */
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        .ticket-card {
            background-color: #fff;
            border-radius: 15px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            width: 350px; /* Cambia el width según tus necesidades */
            max-width: 100%;
            border: 2px dashed #d1d1d1;
            position: relative;
        }

        /* Divisiones del boleto */
        .ticket-card .header, .ticket-card .footer {
            display: flex;
            justify-content: space-between;
            margin-bottom: 15px;
        }

        .ticket-card .info {
            display: flex;
            justify-content: space-between;
            border-top: 1px dashed #d1d1d1;
            padding-top: 15px;
            margin-top: 15px;
        }

        .ticket-card .footer {
            border-top: 1px dashed #d1d1d1;
            padding-top: 10px;
        }

        .label {
            font-size: 12px;
            color: #888;
        }

        .value {
            font-size: 18px;
            font-weight: bold;
            color: #333;
        }

        /* Estilo de iconos */
        .flight-icon {
            display: flex;
            align-items: center;
        }

        .flight-icon .line {
            width: 40px;
            height: 1px;
            background-color: #333;
            margin: 0 10px;
        }

        .flight-icon i {
            font-size: 18px;
            color: #333;
        }

        /* Estilo de puntos perforados a los lados */
        .dots {
            position: absolute;
            height: 100%;
            top: 0;
            left: -20px;
            border-right: 2px dashed #d1d1d1;
        }

        .dots.right {
            left: auto;
            right: -20px;
            border-left: 2px dashed #d1d1d1;
        }

    </style>
</head>
<body>

<div class="ticket-card">
    <!-- Dots perforados -->
    <div class="dots"></div>
    <div class="dots right"></div>

    <!-- Header del boleto -->
    <div class="header">
        <div>
            <span class="label">Origen</span><br>
            <span class="value">CDMX</span>
        </div>
        <div>
            <span class="label">Destino</span><br>
            <span class="value">MTY</span>
        </div>
    </div>

    <!-- Icono de avión -->
    <div class="flight-icon">
        <i class="fa fa-plane"></i>
        <div class="line"></div>
        <i class="fa fa-plane"></i>
    </div>

    <!-- Información del vuelo -->
    <div class="info">
        <div>
            <span class="label">Hora de Salida</span><br>
            <span class="value">22:00</span>
        </div>
        <div>
            <span class="label">Fecha</span><br>
            <span class="value">05/07/2024</span>
        </div>
    </div>

    <!-- Footer del boleto -->
    <div class="footer">
        <div>
            <span class="label">Asiento</span><br>
            <span class="value">12A</span>
        </div>
        <div>
            <span class="label">Precio</span><br>
            <span class="value">$799 MXN</span>
        </div>
    </div>
</div>

</body>
</html>
