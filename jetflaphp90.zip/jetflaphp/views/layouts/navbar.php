<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-light fixed-top fade-in" style="background-color: #262E55" aria-label="Ninth navbar example">
    <div class="container-xl">
        <a class="navbar-brand" href="#">
            <img id="logoCH" src="./assets/img/jetflaLogo.png" class="img-fluid hidden" alt="LogoCH" style="height: 50px;">
        </a>

        <!-- Botón del navbar con evento onclick -->
        <button style="background-color:white" class="navbar-toggler" type="button" aria-controls="navbarsExample07XL" aria-expanded="false" aria-label="Toggle navigation" onclick="toggleNavbar()">
            <span class="navbar-toggler-icon"></span>
        </button>

        <!-- Menú colapsable -->
        <div class="collapse navbar-collapse" id="navbarsExample07XL">
            <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="#" style="color:white;">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#" style="color:white;">Link</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link disabled" href="#" tabindex="-1" aria-disabled="true" style="color:white;">Disabled</a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="dropdown07XL" data-bs-toggle="dropdown" aria-expanded="false">Dropdown</a>
                    <ul class="dropdown-menu" aria-labelledby="dropdown07XL" style="color: red">
                        <li><a class="dropdown-item" href="#"><label style="color: black;">Action</label></a></li>
                        <li><a class="dropdown-item" href="#"><label style="color: black;">Another action</label></a></li>
                        <li><a class="dropdown-item" href="#"><label style="color: black;">Something else here</label></a></li>
                        <li><a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#exampleModal"><label style="color: black;">Iniciar sesion</label></a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</nav>

<script>
    function toggleNavbar() {
        const navbar = document.getElementById('navbarsExample07XL');

        // Alterna las clases 'show' y 'false'
        if (navbar.classList.contains('show')) {
            navbar.classList.remove('show');
            navbar.classList.add('false');
        } else {
            navbar.classList.add('show');
            navbar.classList.remove('false');
        }
    }
</script>

<!-- FIN Navbar -->