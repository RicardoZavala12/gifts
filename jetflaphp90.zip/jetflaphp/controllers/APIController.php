<?php
require 'config.php';

class ApiController
{
    private $pdo;

    public function __construct($pdo)
    {
        $this->pdo = $pdo;
    }

    // Función para obtener todos los registros o un solo registro por ID
    public function get($table, $idField = null, $id = null)
    {
        if ($id && $idField) {
            // Obtener un solo registro usando el campo ID específico
            $stmt = $this->pdo->prepare("SELECT * FROM $table WHERE $idField = :id");
            $stmt->bindParam(':id', $id, PDO::PARAM_INT);
            $stmt->execute();
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
        } else {
            // Obtener todos los registros de la tabla
            $stmt = $this->pdo->query("SELECT * FROM $table");
            $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        }
        echo json_encode($result);
    }

    // Función para crear un nuevo registro
    public function create($table, $data)
    {
        $columns = implode(", ", array_keys($data));
        $placeholders = ":" . implode(", :", array_keys($data));

        $stmt = $this->pdo->prepare("INSERT INTO $table ($columns) VALUES ($placeholders)");
        foreach ($data as $key => &$value) {
            $stmt->bindParam(":$key", $value);
        }
        $stmt->execute();
        echo json_encode(['status' => 'Registro creado con éxito']);
    }

    // Función para actualizar un registro
    public function update($table, $idField, $id, $data)
    {
        $set_clause = "";
        foreach ($data as $key => $value) {
            $set_clause .= "$key = :$key, ";
        }
        $set_clause = rtrim($set_clause, ", ");

        $stmt = $this->pdo->prepare("UPDATE $table SET $set_clause WHERE $idField = :id");
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        foreach ($data as $key => &$value) {
            $stmt->bindParam(":$key", $value);
        }
        $stmt->execute();
        echo json_encode(['status' => 'Registro actualizado con éxito']);
    }

    // Función para eliminar un registro
    public function delete($table, $idField, $id)
    {
        $stmt = $this->pdo->prepare("DELETE FROM $table WHERE $idField = :id");
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        echo json_encode(['status' => 'Registro eliminado con éxito']);
    }
}
