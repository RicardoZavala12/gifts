function toggleFlightDetails() {
    var flightDetails = document.getElementById("flight-detaInfoo");
    var alertSection = document.getElementById("alert-section");
    var costSection = document.getElementById("costosDetails");
    var arrowIcon = document.getElementById('arrow-iconDetaDesk');


    if (flightDetails.style.display === "none" || flightDetails.style.display === "") {
        flightDetails.style.display = "block";
        alertSection.style.marginTop = flightDetails.offsetHeight + "px"; // Añadir margen cuando se despliega
        costSection.style.marginTop = flightDetails.offsetHeight + "px"; // Añadir margen a costos
        arrowIcon.classList.remove('down');
        arrowIcon.classList.add('up');
    } else {
        flightDetails.style.display = "none";
        alertSection.style.marginTop = "0"; // Remover margen cuando se oculta
        costSection.style.marginTop = "0"; // Remover margen cuando se oculta
        arrowIcon.classList.remove('up');
        arrowIcon.classList.add('down');
    }
}

function toggleFlightDetailsRegreso() {
    var flightDetails = document.getElementById("flight-detaInfoo");
    var alertSection = document.getElementById("alert-section");
    var costSection = document.getElementById("costosDetails");
    var arrowIcon = document.getElementById('arrow-iconDetaDesk');


    if (flightDetails.style.display === "none" || flightDetails.style.display === "") {
        flightDetails.style.display = "block";
        //alertSection.style.marginTop = flightDetails.offsetHeight + "%"; // Añadir margen cuando se despliega
        costSection.style.marginTop = flightDetails.offsetHeight + "px"; // Añadir margen a costos
        arrowIcon.classList.remove('down');
        arrowIcon.classList.add('up');
    } else {
        flightDetails.style.display = "none";
        //alertSection.style.marginTop = "10"; // Remover margen cuando se oculta
        costSection.style.marginTop = "0"; // Remover margen cuando se oculta
        arrowIcon.classList.remove('up');
        arrowIcon.classList.add('down');
    }
}

