// JavaScript para el carrusel automático
const container = document.querySelector('.cards-container');
const cards = document.querySelectorAll('.card');

// Define el índice de inicio como 0 para "Equipaje"
let currentIndex = 0;

function startAutoScroll() {
    currentIndex++;

    // Reiniciar al inicio del carrusel
    if (currentIndex >= cards.length) {
        currentIndex = 0;
    }

    container.scrollTo({
        left: currentIndex * container.clientWidth,
        behavior: 'smooth'
    });
}

// Inicializa el carrusel desde la card "Equipaje"
container.scrollTo({
    left: currentIndex * container.clientWidth,
    behavior: 'smooth'
});

// Inicia el auto scroll del carrusel
setInterval(startAutoScroll, 3000);