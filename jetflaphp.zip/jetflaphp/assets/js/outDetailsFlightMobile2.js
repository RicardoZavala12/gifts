function toggleFlightDetailsMobile2() {
    var flightDetails2 = document.getElementById("flight-detaInfooMobile2");
    var alertSection2 = document.getElementById("botonMobile");
    var arrowIcon2 = document.getElementById('arrow-iconDetaM2');

    if (flightDetails2.style.display === "none" || flightDetails2.style.display === "") {
        flightDetails2.style.display = "block";
        alertSection2.style.marginTop = flightDetails2.offsetHeight + "px"; // Añadir margen cuando se despliega
        arrowIcon2.classList.remove('down');
        arrowIcon2.classList.add('up');
    } else {
        flightDetails2.style.display = "none";
        alertSection2.style.marginTop = "0"; // Remover margen cuando se oculta
        arrowIcon2.classList.remove('up');
        arrowIcon2.classList.add('down');
    }
}