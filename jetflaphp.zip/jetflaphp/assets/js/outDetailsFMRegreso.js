function toggleFlightDetailsMobileRegreso() {
    var flightDetails = document.getElementById("flight-detaInfooMobile");
    //var alertSection = document.getElementById("botonMobile");
    var costos = document.getElementById("costosSelect");
    var arrowIcon = document.getElementById('arrow-iconDetaM');

    if (flightDetails.style.display === "none" || flightDetails.style.display === "") {
        flightDetails.style.display = "block";
        //alertSection.style.marginTop = flightDetails.offsetHeight + "px"; // Añadir margen cuando se despliega
        costos.style.marginTop = flightDetails.offsetHeight + "px"; // Añadir margen cuando se despliega
        arrowIcon.classList.remove('down');
        arrowIcon.classList.add('up');
    } else {
        flightDetails.style.display = "none";
        //alertSection.style.marginTop = "0"; // Remover margen cuando se oculta
        costos.style.marginTop = "0"; // Remover margen cuando se oculta
        arrowIcon.classList.remove('up');
        arrowIcon.classList.add('down');
    }
}