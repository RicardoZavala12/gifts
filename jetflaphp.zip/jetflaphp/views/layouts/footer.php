<!doctype html>
<html lang="en" data-bs-theme="auto">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="canonical" href="https://getbootstrap.com/docs/5.3/examples/footers/">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@docsearch/css@3">
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
    <!-- Fuente Montserrat desde Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <style>
      /* Establecer Montserrat como fuente global 
      body {
          font-family: 'Montserrat', sans-serif;
      }*/

      /* Estilo para los enlaces */
      .nav-link, a {
          color: white !important;
          text-decoration: none;
      }

      /* Estilo para los elementos de la lista */
      .nav-itemm {
          font-size: 0.575rem; /* Tamaño de fuente más pequeño */
      }

      /* Centrado en móvil */
      @media (max-width: 576px) {
          footer,
          .footer-column,
          .footer-bottom,
          .footer-column h5,
          .footer-column ul,
          .footer-column .nav-itemm,
          .footer-title,
          .footer-text,
          .social-icons {
              text-align: center !important; /* Centrar todos los elementos solo en mobile */
          }
          .social-icons {
              justify-content: center !important; /* Centrar los íconos de redes sociales */
          }
          .footer-column {
              padding-left: 0 !important;
              padding-right: 0 !important; /* Ajustar padding en mobile */
          }
          img {
              display: block;
              margin: 0 auto; /* Centrar la imagen del logo */
          }
      }

      /* Ajuste de padding para mayor espacio lateral en escritorio */
      .footer-column {
          padding-left: 1.5rem;
          padding-right: 5rem;
      }

      /* Reducir margen superior del contenedor del texto "VIAJAR ES VIVIR" */
      .footer-bottom {
          margin-top: -40px; 
          margin-bottom: 40px; /* Ajusta este valor para reducir aún más el espacio */
      }

      /* Estilo para el texto "VIAJAR ES VIVIR" */
      .footer-title {
          font-size: 1.5rem;
          font-weight: bold;
          color: white;
      }

      /* Estilo para los otros textos en el footer */
      .footer-text {
          color: white;
          font-size: 0.575rem;
      }
      
      /* Estilos para los íconos de redes sociales */
      .social-icons svg {
          width: 24px;
          height: 24px;
          margin-right: 10px;
          fill: white; /* Color blanco para los íconos */
      }
    </style>
  </head>
  <br>
  <body>
    <div class="container" data-aos="fade-up">
      <footer class="row row-cols-1 row-cols-sm-2 row-cols-md-5 py-5 my-5 border-top justify-content-between">
        <div class="col mb-3 footer-column">
          <a href="/" class="d-flex align-items-center mb-3 link-body-emphasis text-decoration-none" alt="LogoFooter">
            <img id="logoCH" src="./assets/img/jetflaLogo.png" class="img-fluid" style="height: 50px;">
          </a>
          <!-- Logos de Redes Sociales -->
          <div class="social-icons d-flex">
            <!-- Instagram -->
            <a href="#" aria-label="Instagram" class="me-2">
              <i style="font-size:24px" class="fa">&#xf16d;</i>
            </a>
            <!-- YouTube -->
            <a href="#" aria-label="YouTube" class="me-2">
              <i style="font-size:24px" class="fa">&#xf16a;</i>
            </a>
            <!-- Facebook -->
            <a href="#" aria-label="Facebook">
              <i style="font-size:24px" class="fa">&#xf09a;</i>
            </a>
          </div>
        </div>
        <!-- Resto del footer -->
        <div class="col mb-3 footer-column">
          <h5 style="text-align: left">Destinos</h5>
          <ul class="nav flex-column" style="text-align: left">
            <li class="nav-itemm">Monterrey, Nuevo León (MTY)</li>
            <li class="nav-itemm">Guadalajara, Jalisco (GDL)</li>
            <li class="nav-itemm">Cancún, Quintana Roo (CUN)</li>
          </ul>
        </div>
        <div class="col mb-3 footer-column">
          <h5 style="text-align: left">Información para tu viaje</h5>
          <ul class="nav flex-column" style="text-align: left">
            <li class="nav-itemm mb-2"><a href="#" class="nav-link p-0">FAQ's</a></li>
            <li class="nav-itemm mb-2"><a href="#" class="nav-link p-0">Equipaje</a></li>
            <li class="nav-itemm mb-2"><a href="#" class="nav-link p-0">Cancelaciones</a></li>
          </ul>
        </div>
        <div class="col mb-3 footer-column">
          <h5 style="text-align: left">Sobre JETFLA</h5>
          <ul class="nav flex-column" style="text-align: left">
            <li class="nav-itemm mb-2"><a href="#" class="nav-link p-0">Términos y condiciones</a></li>
            <li class="nav-itemm mb-2"><a href="#" class="nav-link p-0">Aviso de privacidad</a></li>
            <li class="nav-itemm mb-2"><a href="#" class="nav-link p-0">Información legal</a></li>
            <li class="nav-itemm mb-2"><a href="#" class="nav-link p-0">Facturación</a></li>
          </ul>
        </div>
      </footer>
      <div class="col-12 footer-bottom" style="line-height: 60%">
        <p class="footer-title">VIAJAR ES VIVIR</p>
        <p class="footer-text mb-1">&copy; JETFLA 2024 - 2025</p>
        <p class="footer-text"><a href="#" class="nav-link">Rz Studios</a></p>
      </div>
    </div>
  </body>
</html>
