<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Responsive Layout</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@docsearch/css@3">
    <link href="../resources/css/cagrousel.css" rel="stylesheet">
    
    <style>
        @font-face {
            font-family: 'Designer';
            src: url('..assets/css/Designer.otf') format('opentype');
        }

        @import '~bootstrap/dist/css/bootstrap.min.css';

@font-face {
    font-family: 'Montserrat';
    src: url('https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&display=swap');
}

body {
    margin: 0;
    padding: 0;
    font-family: Arial, sans-serif;
}

/* Media query para pantallas móviles */
@media (max-width: 768px) {
    .carousel-caption {
        font-size: 14px;
        padding: 20px;
        max-width: 90%; /* Limita el ancho máximo del contenedor */
        left: 5%; /* Centra el contenido */
        transform: translateX(0); /* Ajusta la posición del contenido */
    }
    .carousel-caption h5 {
        font-size: 18px;
    }
    .carousel-caption p {
        font-size: 12px;
        margin-bottom: 20px; 
        white-space: normal; 
        margin-left: 20vh; 
        margin-right: 20vh; 
    }
    .carousel-caption .btn {
        padding: 10px 30px;
        font-size: 14px;
        margin-bottom: 20px;
    }
    .carousel-inner img {
        height: auto;
    }
}


.txtTitles {
    font-weight: bold;
    color: #262E55;
}

.carousel-inner img {
    width: 100vh;
    height: 470px;
    object-fit: cover;
    border-radius: 20px;
}

.carousel-caption {
    position: absolute;
    top: 38%;
    left: 50%;
    transform: translate(-50%, -50%);
    text-align: center;
    color: #fff;
    font-family: 'Designer', sans-serif;
    width: 200%;
    max-width: 800px;
}


.destinos.fade-in {
    width: 100%;
    padding: 0;
    margin: 0;
}


.carousel-caption h5 {
    font-size: 36px;
    margin-bottom: 0px;
    font-family: 'Designer', sans-serif;
    position: relative;
    z-index: 2;
}

.carousel-caption p {
    font-size: 16px;
    font-family: 'Montserrat', sans-serif;
    margin-bottom: 100px;
    position: relative;
    z-index: 2;
}

.carousel-caption .btn {
    margin-top: 10%;
    background-color: #861936 ;
    color: rgb(228, 218, 218);
    border-radius: 50px;
    padding: 10px 30px;
    text-transform: uppercase;
    font-weight: bold;
    font-size: 16px;
    position: relative;
    z-index: 2;
}
    </style>
</head>
  
<body>
    <!--------------------------
    CAROUSEL NUEVOS DESTINOS
    --------------------------->
    <div class="destinos fade-in w-100">
        <div id="carouselExample" class="carousel slide w-100" data-bs-ride="carousel" data-aos="fade-up">
            <div class="carousel-inner w-100">
                <div class="carousel-item active" data-interval="1000">
                    <img src="././assets/img/i1.jpg" class="d-block w-100" alt="Imagen 1">
                    <div class="carousel-caption">
                        <h5>Destino 1</h5><br><br>
                        <p>Lorem ipsum dolor sit amet, consectetsurss adipisicing elit.</p>
                        <a href="#" class="btn">¡RESERVA YA!</a>
                    </div>
                </div>
                <div class="carousel-item" data-interval="1000">
                    <img src="././assets/img/im2.jpg" class="d-block w-100" alt="Imagen 2">
                    <div class="carousel-caption">
                        <h5>Destino 2</h5><br><br>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
                        <a href="#" class="btn">¡RESERVA YA!</a>
                    </div>
                </div>
                <div class="carousel-item" data-interval="1000">
                    <img src="././assets/img/im3.jpg" class="d-block w-100" alt="Imagen 3">
                    <div class="carousel-caption">
                        <h5>Destino 3</h5><br><br>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
                        <a href="#" class="btn" style="margin-bottom:10vh;">¡RESERVA YA!</a>
                    </div>
                </div>
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#carouselExample" data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#carouselExample" data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </button>
        </div>
    </div>
    <!--------------------------
    FIN CAROUSEL NUEVOS DESTINOS
    --------------------------->
    </body>
</html>
