<!doctype html>
    <html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>JETFLA | Home</title>
        <!-- Bootstrap core CSS -->
        <link rel="canonical" href="https://getbootstrap.com/docs/5.0/examples/navbars/">

        <link href="/docs/5.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
        <meta name="theme-color" content="#7952b3">
        <link href="https://stackpath.bootstrapcdn.com/bootstrap/5.3.2/css/bootstrap.min.css" rel="stylesheet">
        <link href="https://getbootstrap.com/docs/5.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@docsearch/css@3">
        <link href="./assets/css/nabvar.css" rel="stylesheet">
        <link href="./assets/css/home.css" rel="stylesheet">
        <link href="./assets/css/quiensos.css" rel="stylesheet">

        <!-- Custom styles for this template -->
        <link href="navbar.css" rel="stylesheet">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.css" rel="stylesheet">
        <style> body {margin: 0;padding: 0;font-family: Arial, sans-serif;}.content {padding: 20px;}</style>
    </head>
    <body>
        <main>
            <nav class="navbar navbar-expand-lg navbar-light fixed-top fade-in" style="background-color: #262E55" aria-label="Ninth navbar example">
                <div class="container-xl">
                <a class="navbar-brand" href="#">
                <img id="logoCH" src="./assets/img/jetflaLogo.png" class="img-fluid hiddenIMG" alt="LogoCH" style="height: 50px;">            
                </a>
                <button style="background-color:white" class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarsExample07XL" aria-controls="navbarsExample07XL" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarsExample07XL">
                    <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="#" style="color:white;">Home</a>
                        </li>
                        <li class="nav-item">
                        <a class="nav-link" href="#" style="color:white;">Link</a>
                        </li>
                        <li class="nav-item">
                        <a class="nav-link disabled" href="#" tabindex="-1" aria-disabled="true" style="color:white;">Disabled</a>
                        </li>
                        <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="dropdown07XL" data-bs-toggle="dropdown" aria-expanded="false">Dropdown</a>
                        <ul class="dropdown-menu" aria-labelledby="dropdown07XL" style="color: red">
                            <li><a class="dropdown-item" href="#"><label style="color: black;">Action</label></a></li>
                            <li><a class="dropdown-item" href="#"><label style="color: black;">Another action</label></a></li>
                            <li><a class="dropdown-item" href="#"><label style="color: black;">Something else here</label></a></li>
                        </ul>
                        </li>
                    </ul> 
                </div>
            </div>
                
            </nav>
            <div class="d-none d-md-block fade-in" style="background-color: #262E55;  height: 240px;">
                <br>
                <div class="row w-100">
                    <div class="col-4 d-flex justify-content-start align-items-center">
                        <span class="fw-bold text-white fs-5" style="margin-left: 150px; margin-top: 50px;">Encuentra tu próximo vuelo</span>
                    </div>
                    <div class="col-4 mt-5 d-flex justify-content-center align-items-center" style="margin-top: 80px;">
                        <a href="#">
                            <img id="logoXL" src="./assets/img/jetflaLogo.png" alt="LogoXL" class="img-fluid visible" style="max-height: 150px; margin-bottom: -100px;" data-aos="fade-down">
                        </a>
                    </div>
                    <div class="col-3 mb-4"></div>
                    <label class="switch">
                        <input type="checkbox" id="tripTypeSwitch" checked>
                        <span class="slider"></span>
                        <span class="switch-label label-left">Sencillo</span>
                        <span class="switch-label label-right">Redondo</span>
                    </label>
                </div>  
            </div>
            <br><br><br>
            <div class="col-3 mb-4"></div>
                  <!-- SWITCH DE VIAJE SENCILLO/REDONDO -->
                    <label class="d-block d-lg-none switch fade-in" style="margin-left: 10px">
                        <input type="checkbox" id="tripTypeSwitch2" checked>
                        <span class="slider"></span>
                        <span class="switch-label label-left">Sencillo</span>
                        <span class="switch-label label-right">Redondo</span>
                    </label>
                    <!-- END SWITCH DE VIAJE SENCILLO/REDONDO --> 
                </div>
            </div>
            <div class="content" style="margin-top: -7%;">
             <!-- FORMULARIO Y VIDEO -->
                <div class="container form-video-section" data-aos="fade-up">
                <!-- FORMULARIO -->
                <div class="form-container fade-in">
                    <form>
                        <div class="row">
                            <!-- Columna Izquierda -->
                            <div class="col-6">
                                <div class="form-group custom-form-group">
                                    <label for="origen" class="form-label" style="opacity: 0.6;">Origen</label>
                                    <select class="form-control" id="origen" name="origen" required>
                                        <option value="" disabled selected>Seleccionar</option>
                                        <option value="cdmx">Ciudad de México</option>
                                        <option value="gdl">Guadalajara</option>
                                        <option value="mty">Monterrey</option>
                                    </select>
                                </div>
                                <div class="form-group custom-form-group">
                                    <label for="salida" class="form-label" style="opacity: 0.6;">Salida</label>
                                    <input type="date" class="form-control" id="salida" name="salida" required>
                                </div>
                                <div class="form-group custom-form-group">
                                    <label class="form-label" style="opacity: 0.6;">Pasajeros</label>
                                    <div class="custom-select">
                                        <div class="select-box" onclick="toggleDropdown()">
                                            <span id="selected-passengers">Seleccionar</span>
                                            <i class="arrow down"></i>
                                        </div>
                                        <div id="dropdown-content" class="dropdown-content" style="z-index: 1; margin-top: -200px;">
                                            <div class="passenger-counter">
                                                <div class="passenger-type">
                                                    <span>Adulto</span>
                                                    <div class="counter">
                                                        <button type="button" class="btn-decrement" onclick="updatePassengerCount('adult', -1)">-</button>
                                                        <input type="text" id="adult" value="0" readonly>
                                                        <button type="button" class="btn-increment" onclick="updatePassengerCount('adult', 1)">+</button>
                                                    </div>
                                                </div>
                                                <div class="passenger-type">
                                                    <span>Menor</span>
                                                    <div class="counter">
                                                        <button type="button" class="btn-decrement" onclick="updatePassengerCount('child', -1)">-</button>
                                                        <input type="text" id="child" value="0" readonly>
                                                        <button type="button" class="btn-increment" onclick="updatePassengerCount('child', 1)">+</button>
                                                    </div>
                                                </div>
                                                <div class="passenger-type">
                                                    <span>Bebé</span>
                                                    <div class="counter">
                                                        <button type="button" class="btn-decrement" onclick="updatePassengerCount('infant', -1)">-</button>
                                                        <input type="text" id="infant" value="0" readonly>
                                                        <button type="button" class="btn-increment" onclick="updatePassengerCount('infant', 1)">+</button>
                                                    </div>
                                                </div>
                                            </div>
                                                <button type="button" class="btn btn-success mt-2" onclick="closeDropdown()">Aceptar</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                
                            <!-- Columna Derecha -->
                            <div class="col-6">
                                <div class="form-group custom-form-group">
                                    <label for="destino" class="form-label" style="opacity: 0.6;">Destino</label>
                                    <select class="form-control" id="destino" name="destino" required>
                                        <option value="" disabled selected>Seleccionar</option>
                                        <option value="cdmx">Ciudad de México</option>
                                        <option value="gdl">Guadalajara</option>
                                        <option value="mty">Monterrey</option>
                                    </select>
                                </div>
                                <div class="form-group custom-form-group">
                                    <label for="regreso" class="form-label" style="opacity: 0.6;">Regreso</label>
                                    <input type="date" class="form-control" id="regreso" name="regreso" required>
                                </div>
                                <div class="form-group custom-form-group">
                                    <label for="clase" class="form-label" style="opacity: 0.6;">Código Promocional</label>
                                    <input style="font-style: italic;" type="text" class="form-control" id="codigoPromo" name="codigoPromo" placeholder="JETFLA1202" required>
                                </div>
                            </div>
                        </div>
                        <button type="submit" class="btn-submit">Buscar mi próximo vuelo</button>
                    </form>
                </div>
                
                
                
                <!-- VIDEO -->
                <div class="video-container fade-in">
                    <iframe src="https://www.youtube.com/embed/aQqOElcMvhw?autoplay=1&mute=1&controls=0&rel=0&showinfo=0&modestbranding=1" 
                            title="JESSICA AUDIFFRED @ EDC VEGAS 2024" 
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" 
                            >
                    </iframe>
                </div>
            </div><br><br>
            <div id="quienSos" class="who-we-are" onclick="toggleContent()" data-aos="fade-up">
                <h2 class="txtTitles">¿Quiénes Somos?</h2>
                <div id="extraContent" class="extra-content">
                    <p>Lozzrem ipsum dolor sit amet, consectetuer adipiscing elit. 
                        Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis 
                        parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, 
                        pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet 
                        nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. 
                        Nullam dictum felis eu pede mollis pretium. Integer tincidunt. Cras dapibus. Vivamus elementum 
                        semper nisi. Aenean vulputate eleifend tellus. Aenean leo ligula, porttitor eu, consequat vitae, 
                        eleifend ac, enim. Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus. Phasellus viverra 
                        nulla ut metus varius laoreet. Quisque rutrum. Aenean imperdiet. Etiam ultricies nisi vel augue. 
                        Curabitur ullamcorper ultricies nisi. Nam eget dui. Etiam rhoncus. Maecenas tempus, tellus eget 
                        condimentum rhoncus, sem quam semper libero, sit amet adipiscing sem neque sed ipsum. Nam quam nunc, 
                        blandit vel, luctus pulvinar, hendrerit id, lorem. Maecenas nec odio et ante tincidunt tempus. Donec 
                        vitae sapien ut libero venenatis faucibus. Nullam quis ante. Etiam sit amet orci eget eros faucibus tincidunt. 
                        Duis leo. Sed fringilla mauris sit amet nibh. Donec sodales sagittis magna. Sed consequat, leo eget bibendum sodales,
                        augue velit cursus nunc,

                    </p>
                </div>
            </div><br><br>

            <!--------------------------
            CAROUSEL NUEVOS DESTINOS
            --------------------------->
            <div class="destinos fade-in">
                <!--<h2 style="margin-bottom: -20px;" class="txtTitles" data-aos="fade-up">Nuevos destinos</h2>-->
                <?php include('layouts/newdestinos.php')?>
            </div>
            <!--------------------------
            FIN CAROUSEL NUEVOS DESTINOS
            --------------------------->

            <!-- CARDS PROMOS -->
            <link href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.css" rel="stylesheet">
            <script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>
            <script>AOS.init();</script>          
            <br><br>
            <div class="promos" data-aos="fade-up">
                <div class="promo-container" data-aos="fade-up">
                    <div class="promo-card" style="background-image: linear-gradient(rgba(0, 0, 0, 0.1), rgba(0, 0, 0, 0.7)), url('./assets/img/canada.jpg');">
                        <div class="promo-content">
                            <p class="small-text">Viaja a</p>
                            <h3>CANADA</h3>
                        </div>
                        <div class="price">
                            <a href="" class="nav-link"><p class="small-text">Desde</p>
                            <h4>$199 USD</h4></a>
                        </div>
                    </div>
                    <div class="promo-card" style="background-image: linear-gradient(rgba(0, 0, 0, 0.1), rgba(0, 0, 0, 0.7)), url('./assets/img/cancun.jpg');">
                        <div class="promo-content">
                            <p class="small-text">Viaja a</p>
                            <h3>CANCÚN</h3>
                        </div>
                        <div class="price">
                            <a href="" class="nav-link"><p class="small-text">Desde</p>
                            <h4>$199 USD</h4></a>
                        </div>
                    </div>
                    <div class="promo-card" style="background-image: linear-gradient(rgba(0, 0, 0, 0.1), rgba(0, 0, 0, 0.7)), url('./assets/img/ny.jpg');">
                        <div class="promo-content">
                            <p class="small-text">Viaja a</p>
                            <h3>NUEVA YORK</h3>
                        </div>
                        <div class="price">
                            <a href="" class="nav-link"><p class="small-text">Desde</p>
                            <h4>$199 USD</h4></a>
                        </div>
                    </div>
                    <div class="promo-card" style="background-image: linear-gradient(rgba(0, 0, 0, 0.1), rgba(0, 0, 0, 0.7)), url('./assets/img/dubai.jpg');">
                        <div class="promo-content">
                            <p class="small-text">Viaja a</p>
                            <h3>DUBAI</h3>
                        </div>
                        <div class="price">
                            <a href="" class="nav-link"><p class="small-text">Desde</p>
                            <h4>$199 USD</h4></a>
                        </div>
                    </div>
                </div>
            </div><br>
            <!-- FIN CARDS PROMOS -->

            <!-- CARDS BENEFICIOS -->
            <div class="beneficios fade-in" data-aos="fade-up" style="background-color: #F3F4F6; border-radius: 20px;"><br><br>
                <h2 style="margin-bottom: 40px;  text-decoration: none;" class="txtTitles" data-aos="fade-up">Beneficios</h2>

                <div class="cards-container" style="background-color: #F3F4F6; border-radius: 20px; text-align: center; ">
                    <div class="card">
                        <img id="security" src="./assets/img/security.svg" class="img-fluid" style="height: 35%;">
                        <h3><b>Seguridad</b></h3>
                        <p>Vuela con la tranquilidad de viajar seguro</p>
                    </div><br>
                    <div class="card">
                        <img id="money" src="./assets/img/money.svg" class="img-fluid" style="height: 35%;">
                        <h3><b>Bajo costo</b></h3>
                        <p>Tarifas asequibles para poder viajar más</p>
                    </div><br>
                    <div class="card">
                        <img id="food" src="./assets/img/food.svg" class="img-fluid" style="height: 35%;">
                        <h3><b>Alimentos</b></h3>
                        <p>Deliciosos alimentos gratis a bordo</p>
                    </div><br>
                    <div class="card">
                        <img id="suitcase" src="./assets/img/suitcase.svg" class="img-fluid" style="height: 35%;">
                        <h3><b>Equipaje</b></h3>
                        <p>Lleva más equipaje sin costo adicional</p>
                    </div><br>
                    <div class="card">
                        <img id="fast" src="./assets/img/fast.svg" class="img-fluid" style="height: 35%;">
                        <h3><b>Rapidez</b></h3>
                        <p>Llega a tu destino de manera rápida y eficiente</p>
                    </div>
                </div>
            </div><br><br>
            <!-- FIN CARDS BENEFICIOS -->

            </div><!-- Fin div content -->
            <footer class="footer" style="background-color: #262E55">
               <?php include('layouts/footer.php')?>
    </footer>
        </main>
            <!-- Bootstrap JS and dependencies -->
            <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/2.11.7/umd/popper.min.js"></script>
            <script src="https://stackpath.bootstrapcdn.com/bootstrap/5.3.2/js/bootstrap.min.js"></script>
            <script src="https://getbootstrap.com/docs/5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>   
            <script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>
            <script src="./assets/js/logo.js"></script>
            <script src="./assets/js/dropdownpasajeros.js"></script>    
            <script src="./assets/js/switch.js"></script>    
            <script src="./assets/js/formulario.js"></script>    
            <script src="./assets/js/carousell.js"></script>    
            <script>AOS.init();</script> 
            <script>
                AOS.init({
                duration: 1000, // Duración de la animación en milisegundos
                once: true // Si quieres que la animación se ejecute solo una vez
                });
            </script>
             <!-- JS para Quien sos-->
            <script>
                function toggleContent() {
                    const content = document.getElementById("extraContent");
                    content.classList.toggle("show");
                }
            </script>
    </body>
    </html>