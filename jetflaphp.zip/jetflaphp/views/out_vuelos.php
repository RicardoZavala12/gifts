<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>JETFLA | Seleccionar Salida</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="./assets/css/outFlights.css" rel="stylesheet">
</head>

<body>

    <div class="grid-container">
        <!-- Navbar -->
        <nav class="navbar navbar-expand-lg navbar-light fixed-top fade-in" style="background-color: #262E55" aria-label="Ninth navbar example">
            <div class="container-xl">
                <a class="navbar-brand" href="#">
                    <img id="logoCH" src="./assets/img/jetflaLogo.png" class="img-fluid hidden" alt="LogoCH" style="height: 50px;">
                </a>
                <button style="background-color:white" class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarsExample07XL" aria-controls="navbarsExample07XL" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarsExample07XL">
                    <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="#" style="color:white;">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#" style="color:white;">Link</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link disabled" href="#" tabindex="-1" aria-disabled="true" style="color:white;">Disabled</a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="dropdown07XL" data-bs-toggle="dropdown" aria-expanded="false">Dropdown</a>
                            <ul class="dropdown-menu" aria-labelledby="dropdown07XL" style="color: red">
                                <li><a class="dropdown-item" href="#"><label style="color: black;">Action</label></a></li>
                                <li><a class="dropdown-item" href="#"><label style="color: black;">Another action</label></a></li>
                                <li><a class="dropdown-item" href="#"><label style="color: black;">Something else here</label></a></li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </div>
        </nav><br><br><br><br><br>

        <!-- Main Content -->
        <div class="content-grid">
            <!-- Left Side -->
            <div class="left">
                <div class="left-text">
                    <div class="fade-in d-none d-md-block" id="salida-desktop" style="background-color: #ffffff; height: 240px; margin-left:10%;">
                        <div class="responsive-text">
                            <span class="fw-bold fs-5" style="color: #861936;">Elije tu vuelo de salida</span>
                            <span class="fw-light fs-5" style="margin-left: 0%; color: #861936;">&nbsp;CDMX → MTY</span>
                        </div>
                        <div class="responsive-text" style="margin-top: 0%;">
                            <span class="fw-light fs-6" style="color:#262E55;">Ciudad de Mexico a Monterrey | 21 Ago, 2024</span>
                        </div>
                    </div>

                    <!-- MOBILE VERSION -->
                    <div class="fade-in d-block d-md-none" id="salida-mobile" style="background-color: #ffffff; padding: 0px;">
                        <div class="responsive-text">
                            <span class="fw-bold fs-6" style="color: #861936;">Elije tu vuelo de salida</span>
                            <span class="fw-light fs-6" style="margin-left: 10px; color: #861936;">CDMX → MTY</span>
                        </div>
                        <div class="responsive-text mt-2">
                            <span class="fw-light fs-6" style="color: #262E55;">Ciudad de Mexico a Monterrey | 21 Ago, 2024</span>
                        </div>
                    </div><br>
                </div>

                <!-- Mobile: Toggleable div and button for mobile layout -->
                <div class="toggle-and-button d-block d-md-none fade-in">
                    <div class="alert flight-deta12Mobile" onclick="toggleFlightDetailsMobile()" style="color: #262E55;">
                        <strong>Detalles de reservación</strong>
                        <i class="arrow down" id="arrow-iconDetaM" style="margin-top:9px;"></i>
                    </div>

                    <div class="col-3 mb-4 flight-detaInfooMobile fade-in" id="flight-detaInfooMobile" style="margin-top:-3%; display: none; transition: max-height 0.5s ease-in-out;">
                        <p style="font-weight: bold;">Pasajeros</p>
                        <p>1 MOBILE</p>
                        <p style="font-weight: bold;">Origen</p>
                        <p>Ciudad de México (CDMX)</p>
                        <p style="font-weight: bold;">Destino</p>
                        <p>Monterrey, Nuevo León (MTY)</p>
                        <p style="font-weight: bold;">Fecha de salida</p>
                        <p>Vie, 05 jul, 2024</p>
                        <p style="font-weight: bold;">Fecha de regreso</p>
                        <p>Dom, 14 jul, 2024</p>
                    </div>
                    <button type="submit" class="btn-s btn-submit" id="botonMobilee" style="border-radius: 20px; padding: 8px 30px;">Modificar vuelo</button><br><br><br><br><br><br>
                </div>

                <!-- Cards -->
                <div class="card-container" style="margin-left:-12%; margin-top:-34%;">
                    <?php
                    //Mock data simulating database results
                    $flights = [
                        [
                            'departure_time' => '22:00 AM',
                            'departure_code' => 'CDMX',
                            'arrival_time' => '4:30 AM',
                            'arrival_code' => 'MTY',
                            'price' => '799 MXN',
                            'layover' => '1 Escala, 3 h 10 min',
                            'flight_number' => '1234',
                            'airline' => 'XYZ'
                        ],
                        [
                            'departure_time' => '22:00 AM',
                            'departure_code' => 'CDMX',
                            'arrival_time' => '4:30 AM',
                            'arrival_code' => 'MTY',
                            'price' => '799 MXN',
                            'layover' => '1 Escala, 3 h 10 min',
                            'flight_number' => '1234',
                            'airline' => 'XYZ'
                        ],
                        [
                            'departure_time' => '22:00 AM',
                            'departure_code' => 'CDMX',
                            'arrival_time' => '4:30 AM',
                            'arrival_code' => 'MTY',
                            'price' => '799 MXN',
                            'layover' => '1 Escala, 3 h 10 min',
                            'flight_number' => '1234',
                            'airline' => 'XYZ'
                        ],
                        [
                            'departure_time' => '22:00 AM',
                            'departure_code' => 'CDMX',
                            'arrival_time' => '4:30 AM',
                            'arrival_code' => 'MTY',
                            'price' => '799 MXN',
                            'layover' => '1 Escala, 3 h 10 min',
                            'flight_number' => '1234',
                            'airline' => 'XYZ'
                        ]
                    ];

                    foreach ($flights as $index => $flight) {
                        $detailsId = 'details-content-' . $index;
                        $detailsIcon = 'arrow-icon-' . $index;
                        echo '
        <div class="content fade-in " style="margin-top: 5%;">
            <div class="flight-info" id="flight-infoCard">
                <div class="flight-schedule" style="margin-top: -15px;">
                    <div class="flight-time">
                        <span class="time">' . $flight['departure_time'] . '</span><br>
                        <span class="airport-code">' . $flight['departure_code'] . '</span>
                    </div>
                    <div class="flight-icon">
                        <span class="line"></span>
                        <i class="fa fa-plane" ></i>
                        <span class="line"></span>
                    </div>
                    <div class="flight-time">
                        <span class="time">' . $flight['arrival_time'] . '</span><br>
                        <span class="airport-code">' . $flight['arrival_code'] . '</span>
                    </div>
                </div>
                <div class="flight-details">
                    <div class="price-details">
                        <span class="price">$' . $flight['price'] . '</span>
                    </div>
                    <br>
                    <a href="javascript:void(0)" class="details-link" onclick="dinamicaDetails(\'' . $detailsId . '\', \'' . $detailsIcon . '\')" style="align-items: center;">
                        <span class="details-text"><label for="details" class="text-black">Detalles</label></span>
                        <i class="arrow down" id="' . $detailsIcon . '"></i>
                    </a>
                </div>
                <div class="layover">' . $flight['layover'] . '</div>
            </div>

            <div id="' . $detailsId . '" class="details-card" style="margin-left: 0; display: none; margin-left: 12%;">
                <div class="card-content">
                    <p><label for="details_flight" style="font-size: 15px; font-weight: bold; color: #262E55;">Detalles del vuelo</label></p>
                    <ul>
                        <li>Vuelo: ' . $flight['flight_number'] . '</li>
                        <li>Aerolínea: ' . $flight['airline'] . '</li>
                        <li>Comida incluida</li>
                        <li>WiFi disponible</li>
                    </ul>
                </div>
                <div class="flight-card">
                    <p class="card-title"><strong>Directo</strong></p>
                    <ul>
                        <li>Lorem ipsum dolor</li>
                        <li>Lorem ipsum dolor</li>
                        <li>Lorem ipsum dolor</li>
                    </ul>
                    <button class="select-button">Seleccionar</button>
                </div>
                <div class="flight-card">
                    <p class="card-title"><strong>Escala</strong></p>
                    <ul>
                        <li>Lorem ipsum dolor</li>
                        <li>Lorem ipsum dolor</li>
                        <li>Lorem ipsum dolor</li>
                    </ul>
                    <button class="select-button">Seleccionar</button>
                </div>
            </div>
        </div>';
                    }
                    ?>
                </div>
                <!-- Mobile: Another div below (before footer) -->
                <div class="alert d-block d-md-none">
                    <div class="destinos fade-in">
                        <?php include('layouts/newdestinos.php') ?><br><br><br><br>
                    </div>
                </div>
            </div>

            <!-- Right Side (Visible only on desktop) -->
            <div class="right-side fade-in">
                <button type="submit" class="btn-s btn-submit" style="border-radius: 20px; padding: 8px 30px;">Modificar vuelo</button>

                <div class="alert flight-deta12" onclick="toggleFlightDetails()" style="color: #262E55;">
                    <b>Detalles de reservación</b>
                    <i class="arrow down" id="arrow-iconDetaDesk" style="margin-top:9px;"></i>
                </div>


                <div class="col-3 mb-4 flight-detaInfoo fade-in" id="flight-detaInfoo" style="margin-top:8.5%; display: none; transition: max-height 0.5s ease-in-out;">
                    <p style="font-weight: bold;">Pasajeros</p>
                    <p>1 MOBILE</p>
                    <p style="font-weight: bold;">Origen</p>
                    <p>Ciudad de México (CDMX)</p>
                    <p style="font-weight: bold;">Destino</p>
                    <p>Monterrey, Nuevo León (MTY)</p>
                    <p style="font-weight: bold;">Fecha de salida</p>
                    <p>Vie, 05 jul, 2024</p>
                    <p style="font-weight: bold;">Fecha de regreso</p>
                    <p>Dom, 14 jul, 2024</p>
                </div>

                <div class="alert" id="alert-section">
                    <div class="destinos fade-in" style="transition: all 0.5s ease;">
                        <?php include('layouts/newdestinos.php') ?>
                        <br><br><br>
                    </div>
                </div>
            </div>

        </div>
        <!-- Footer -->
        <div>
            <footer class="footer fade-in" id="footer-section" style="background-color: #262E55; margin-top:10%;">
                <?php include('layouts/footer.php') ?>
            </footer>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="./assets/js/logo.js"></script>
    <script src="./assets/js/outDetailsFlight.js"></script>
    <script src="./assets/js/outDetailsFM.js"></script>
    <script src="./assets/js/outDetailsFliCards.js"></script>
    <script>
        AOS.init();
    </script>
    <script>
        AOS.init({
            duration: 1000, // Duración de la animación en milisegundos
            once: true // Si quieres que la animación se ejecute solo una vez
        });
    </script>
</body>

</html>