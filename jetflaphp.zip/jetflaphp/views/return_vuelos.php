<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>JETFLA | Seleccionar Regreso</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="./assets/css/outFlights.css" rel="stylesheet">
    <link href="https://getbootstrap.com/docs/5.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@docsearch/css@3">

    <link href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.css" rel="stylesheet">
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
        }

        .content {
            padding: 20px;
        }
    </style>
</head>

<body>
    <div class="grid-container">
        <!-- Navbar -->
        <nav class="navbar navbar-expand-lg navbar-light fixed-top fade-in" style="background-color: #262E55" aria-label="Ninth navbar example">
            <div class="container-xl">
                <a class="navbar-brand" href="#">
                    <img id="logoCH" src="./assets/img/jetflaLogo.png" class="img-fluid hidden" alt="LogoCH" style="height: 50px;">
                </a>
                <button style="background-color:white" class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarsExample07XL" aria-controls="navbarsExample07XL" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarsExample07XL">
                    <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="#" style="color:white;">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#" style="color:white;">Link</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link disabled" href="#" tabindex="-1" aria-disabled="true" style="color:white;">Disabled</a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="dropdown07XL" data-bs-toggle="dropdown" aria-expanded="false">Dropdown</a>
                            <ul class="dropdown-menu" aria-labelledby="dropdown07XL" style="color: red">
                                <li><a class="dropdown-item" href="#"><label style="color: black;">Action</label></a></li>
                                <li><a class="dropdown-item" href="#"><label style="color: black;">Another action</label></a></li>
                                <li><a class="dropdown-item" href="#"><label style="color: black;">Something else here</label></a></li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </div>
        </nav><br><br><br><br><br>

        <!-- Main Content -->
        <div class="content-grid">
            <!-- Left Side -->
            <div class="left">
                <div class="left-text">
                    <div data-aos="fade-up" class="fade-in d-none d-md-block" id="salida-desktop" style="background-color: #ffffff; height: 240px; margin-left:10%;">
                        <div class="responsive-text">
                            <span class="fw-bold fs-8" style="color: #861936;">Vuelos seleccionados</span>
                        </div>

                    </div>

                    <!-- MOBILE VERSION -->
                    <div  data-aos="fade-up" class="fade-in d-block d-md-none" id="salida-mobile" style="background-color: #ffffff; padding: 0px; margin-top:-10%;">
                        <div class="responsive-text"><br><br><br>
                            <span class="fw-bold fs-8" style="color: #861936;">Vuelos seleccionados</span>
                        </div>
                        <div class="responsive-text mt-2">
                        </div>
                    </div><br><br>
                </div>
                <div class="card-container" style="margin-left:-12%; margin-top:-36%;" data-aos="fade-up">
                    <?php
                    //Mock data simulating database results
                    $flights = [
                        [
                            'departure_time' => '22:00 ',
                            'departure_code' => 'CDMX',
                            'arrival_time' => '4:30 ',
                            'arrival_code' => 'MTY',
                            'price' => '799 MXN',
                            'layover' => '1 Escala, 3 h 10 min',
                            'matriculaJet' => '1234',
                            'airline' => 'XYZ',
                            'flight_number' => 'Y2 1202',
                            'equipajeKg' => '10',
                            'fechaSalida' => 'Vie, 05 jul, 2024'
                        ],
                    ];

                    foreach ($flights as $index => $flight) {
                        $detailsId = 'details-content-' . $index;
                        $detailsIcon = 'arrow-icon-' . $index;
                        echo '
        <div class="content fade-in " style="margin-top: 5%;">
            <div class="flight-info" id="flight-infoCard" style="box-shadow: 0px 5px 10px rgba(0, 0, 0, 0.5);">
            <div class="flight-details">
                    <div class="price-details">
                        <span class="price">Salida</span><br>
                    </div>
                    <div style="margin-left: 0;">
                        <p style="margin: 0; padding: 0; display:flex;"><b>' . $flight['fechaSalida'] . '</b></p>
                        <p style="margin: 0; padding: 0; display:flex;">Vuelo&nbsp;<b>' . $flight['flight_number'] . '</b></p>
                        <p style="margin: 0; padding: 0; display:flex; flex-wrap: nowrap; gap: 5px;"><b>' . $flight['departure_time'] . '</b>&nbsp;' . $flight['departure_code'] . '</p>
                    </div>
                </div>
                <div class="flight-schedule" style="margin-top: -15px;">
                    <div class="flight-time">
                        <span class="time">' . $flight['departure_time'] . '</span><br>
                        <span class="airport-code">' . $flight['departure_code'] . '</span>
                    </div>
                    <div class="flight-icon">
                        <span class="line"></span>
                        <i class="fa fa-plane" style="transform: rotate(280deg);"></i>
                        <span class="line"></span>
                    </div>
                    <div class="flight-time">
                        <span class="time">' . $flight['arrival_time'] . '</span><br>
                        <span class="airport-code">' . $flight['arrival_code'] . '</span>
                    </div>
                </div>
                
                <div class="layover" style="margin-left:34%;">' . $flight['layover'] . '</div>
            </div>

            <div id="details-content" class="details-card d-none d-md-flex" style="box-shadow: 0px 5px 10px rgba(0, 0, 0, 0.5); margin-left: 0; display: flex; margin-left: 12%; max-height: 690px; width: 700%;">
                <div class="card-content">
                    <p><label for="details_flight" style="font-size: 14.2px; font-weight: bold; color: #262E55;">Detalles del vuelo</label></p>
                    <ul>
                        <li>Equipaje <b>' . $flight['equipajeKg'] . ' KG</b> </li>
                        <li>Comida incluida</li>
                        <li>WiFi disponible</li>
                    </ul>
                </div>
                <div class="flight-card" style="margin-left: 15% ;width: 60%; text-align: center;">
                    <p class="card-title"><strong>Directo</strong></p>
                    <div style="font-size: 30px; font-weight: bold; color: #262E55;">$799 MXN</div>
                </div>
            </div>
           
            
            <div id="details-content" class="details-card d-flex d-md-none" style="box-shadow: 0px 5px 10px rgba(0, 0, 0, 0.5); display: flex; margin-left: 6%; max-height: 694px; width: 700%;">
                <div class="card-content">
                    <p><label for="details_flight" style="font-size: 15px; font-weight: bold; color: #262E55;">Detallsses del vuelo</label></p>
                    <ul>
                        <li>Equipaje <b>' . $flight['equipajeKg'] . ' KG</b> </li>
                        <li>Comida incluida</li>
                        <li>WiFi disponible</li>
                    </ul>
                </div>
                <div class="flight-card">
                    <p class="card-title"><strong>Directo</strong></p>
                    <div style="font-size: 30px; font-weight: bold; color: #262E55;">$799 MXN</div>
                </div>
            </div>
        </div>';
                    }
                    ?>
                </div><br><br><br>
                <div class="left-text" >
                    <div class="fade-in d-none d-md-block" id="salida-desktop" style="background-color: #ffffff; height: 240px; margin-left:10%;" data-aos="fade-up">
                        <div class="responsive-text">
                            <span class="fw-bold fs-5" style="color: #861936;">Elije tu vuelo de regreso</span>
                            <span class="fw-light fs-5" style="margin-left: 0%; color: #861936;">&nbsp;MTY → CDMX</span>
                        </div>
                        <div class="responsive-text" style="margin-top: 0%;">
                            <span class="fw-light fs-6" style="color:#262E55;"> Monterrey a Ciudad de Mexico | 14 Jul, 2024</span>
                        </div>
                    </div>

                    <!-- MOBILE VERSION -->
                    <div class="fade-in d-block d-md-none" id="salida-mobile" style="background-color: #ffffff; padding: 0px;" data-aos="fade-up">
                        <div class="responsive-text">
                            <span class="fw-bold fs-6" style="color: #861936;">Elije tu vuelo de regreso</span>
                            <span class="fw-light fs-6" style="margin-left: 10px; color: #861936;">MTY → CDMX</span>
                        </div>
                        <div class="responsive-text mt-2">
                            <span class="fw-light fs-6" style="color: #262E55;"> Monterrey a Ciudad de Mexico | 14 Jul, 2024</span>
                        </div>
                    </div><br>
                </div>

                <!-- Mobile: Toggleable div and button for mobile layout -->
                <div class="toggle-and-button d-block d-md-none fade-in">
                    <!-- Detalles de reservación -->
                    <div class="alert flight-deta12Mobile" onclick="toggleFlightDetailsMobileRegreso()" style="color: #262E55;" >
                        <b>Detalles de reservación</b>
                        <i class="arrow down" id="arrow-iconDetaM" style="margin-top:9px;"></i>
                    </div>
                    <div class="col-3 mb-4 flight-detaInfooMobile fade-in" id="flight-detaInfooMobile" style="margin-top:-3%; display: none; transition: max-height 0.5s ease-in-out; width:80%; margin-left:0%;">
                        <p style="font-weight: bold;">Pasajeros</p>
                        <p>1 MOBILE</p>
                        <p style="font-weight: bold;">Origen</p>
                        <p>Ciudad de México (CDMX)</p>
                        <p style="font-weight: bold;">Destino</p>
                        <p>Monterrey, Nuevo León (MTY)</p>
                        <p style="font-weight: bold;">Fecha de salida</p>
                        <p>Vie, 05 jul, 2024</p>
                        <p style="font-weight: bold;">Fecha de regreso</p>
                        <p>Dom, 14 jul, 2024</p>
                    </div><br>

                    <!-- Costos -->
                    <div class="alert flight-deta12Mobile" id="costosSelect" onclick="toggleFlightDetailsMobile2()" style="color: #262E55;" >
                        <b>Costos de vuelo</b>
                        <i class="arrow down" id="arrow-iconDetaM2" style="margin-top:9px;"></i>
                    </div>
                    <div class="col-3 mb-4 flight-detaInfooMobile fade-in" id="flight-detaInfooMobile2" style="margin-top:-3%; display: none; transition: max-height 0.5s ease-in-out; width:80%; ">
                        <div style="display: flex; justify-content: space-between;">
                            <p style="font-weight: bold;">Tarifa base</p>
                            <p>$00.0</p>
                        </div>
                        <div style="display: flex; justify-content: space-between;">
                            <p style="font-weight: bold;">TUA
                                <span style="font-size: 17px; cursor: pointer;"
                                    title="El TUA es el impuesto de uso aeroportuario.">
                                    <i class="fa-solid fa-circle-question"></i>
                                </span>
                            </p>
                            <p>$00.0</p>
                        </div>
                        <div style="display: flex; justify-content: space-between;">
                            <p style="font-weight: bold;">Descuento</p>
                            <p>$00.0</p>
                        </div>
                        <div style="display: flex; justify-content: space-between;">
                            <p style="font-weight: bold;">Tarifa base con descuento</p>
                            <p>$00.0</p>
                        </div>
                        <div style="display: flex; justify-content: space-between;">
                            <p style="font-weight: bold;">IVA</p>
                            <p>$00.0</p>
                        </div>
                        <!---<div style="display: flex; justify-content: space-between;">
                            <p style="font-weight: bold;" class="text-success">TOTAL</p>
                            <p style="font-weight: bold; font-size:18px;" class="text-success">$00.0</p>
                        </div>--->
                    </div>
                    <button type="submit" class="btn-s btn-submit" id="botonMobile" style="border-radius: 20px; padding: 8px 30px;">Modificar vuelo</button><br><br><br><br><br><br>
                </div>
                <!-- Cards -->
                <div class="card-container" style="margin-left:-12%; margin-top:-34%;">
                    <?php
                    //Mock data simulating database results
                    $flights = [
                        [
                            'departure_time' => '22:00 AM',
                            'departure_code' => 'CDMX',
                            'arrival_time' => '4:30 AM',
                            'arrival_code' => 'MTY',
                            'price' => '799 MXN',
                            'layover' => '1 Escala, 3 h 10 min',
                            'flight_number' => '1234',
                            'airline' => 'XYZ',
                            'equipajeKg' => '10'
                        ],
                        [
                            'departure_time' => '22:00 AM',
                            'departure_code' => 'CDMX',
                            'arrival_time' => '4:30 AM',
                            'arrival_code' => 'MTY',
                            'price' => '799 MXN',
                            'layover' => '1 Escala, 3 h 10 min',
                            'flight_number' => '1234',
                            'airline' => 'XYZ',
                            'equipajeKg' => '10'
                        ],
                        [
                            'departure_time' => '22:00 AM',
                            'departure_code' => 'CDMX',
                            'arrival_time' => '4:30 AM',
                            'arrival_code' => 'MTY',
                            'price' => '799 MXN',
                            'layover' => '1 Escala, 3 h 10 min',
                            'flight_number' => '1234',
                            'airline' => 'XYZ',
                            'equipajeKg' => '10'
                        ],
                        [
                            'departure_time' => '22:00 AM',
                            'departure_code' => 'CDMX',
                            'arrival_time' => '4:30 AM',
                            'arrival_code' => 'MTY',
                            'price' => '799 MXN',
                            'layover' => '1 Escala, 3 h 10 min',
                            'flight_number' => '1234',
                            'airline' => 'XYZ',
                            'equipajeKg' => '10'
                        ]
                    ];

                    foreach ($flights as $index => $flight) {
                        $detailsId = 'details-content-' . $index;
                        $detailsIcon = 'arrow-icon-' . $index;
                        echo '
        <div class="content fade-in " style="margin-top: 5%;" data-aos="fade-up">
            <div class="flight-info" id="flight-infoCard">
                <div class="flight-schedule" style="margin-top: -15px;">
                    <div class="flight-time">
                        <span class="time">' . $flight['departure_time'] . '</span><br>
                        <span class="airport-code">' . $flight['departure_code'] . '</span>
                    </div>
                    <div class="flight-icon">
                        <span class="line"></span>
                        <i class="fa fa-plane"  style="transform: rotate(280deg);"></i>
                        <span class="line"></span>
                    </div>
                    <div class="flight-time">
                        <span class="time">' . $flight['arrival_time'] . '</span><br>
                        <span class="airport-code">' . $flight['arrival_code'] . '</span>
                    </div>
                </div>
                <div class="flight-details">
                    <div class="price-details">
                        <span class="price">$' . $flight['price'] . '</span>
                    </div>
                    <br>
                    <a href="javascript:void(0)" class="details-link" onclick="dinamicaDetails(\'' . $detailsId . '\', \'' . $detailsIcon . '\')" style="align-items: center;">
                        <span class="details-text"><label for="details" class="text-black">Detalles</label></span>
                        <i class="arrow down" id="' . $detailsIcon . '"></i>
                    </a>
                </div>
                <div class="layover">' . $flight['layover'] . '</div>
            </div>

            <div id="' . $detailsId . '" class="details-card" style="margin-left: 0; display: none; margin-left: 12%;">
                <div class="card-content">
                    <p><label for="details_flight" style="font-size: 14.2px; font-weight: bold; color: #262E55;">Detalles del vuelo</label></p>
                    <ul>
                        <li>Equipaje <b>' . $flight['equipajeKg'] . ' KG</b> </li>
                        <li>Comida incluida</li>
                        <li>WiFi disponible</li>
                    </ul>
                </div>
                <div class="flight-card">
                    <p class="card-title"><strong>Directo</strong></p>
                    <div style="font-size: 30px; font-weight: bold; color: #262E55;">$799 MXN</div>
                    <button class="select-button">Seleccionar</button>

                </div>
                <div class="flight-card">
                    <p class="card-title"><strong>Escala</strong></p>
                    <div style="font-size: 30px; font-weight: bold; color: #262E55;">$499 MXN</div>
                    <button class="select-button">Seleccionar</button>
                </div>
            </div>
        </div>';
                    } ?>
                </div>
                <!-- Mobile: Another div below (before footer) -->
                <div class="alert d-block d-md-none">
                    <div class="destinos fade-in">
                        <?php include('layouts/newdestinos.php') ?><br><br><br><br>
                    </div>
                </div>
            </div>

            <!-- Right Side (Visible only on desktop) -->
            <div class="right-side fade-in">
                <button type="submit" class="btn-s btn-submit" style="border-radius: 20px; padding: 8px 30px;">Modificar vuelo</button>

                <div class="alert flight-deta12" onclick="toggleFlightDetailsRegreso()" style="color: #262E55;">
                    <b>Detalles de reservación</b>
                    <i class="arrow down" id="arrow-iconDetaDesk" style="margin-top:9px;"></i>
                </div>
                <div class="col-3 mb-4 flight-detaInfoo fade-in" id="flight-detaInfoo" style="margin-top:10%; display: none; transition: max-height 0.5s ease-in-out; width:100%;">
                    <p style="font-weight: bold;">Pasajeros</p>
                    <p>1 DESK</p>
                    <p style="font-weight: bold;">Origen</p>
                    <p>Ciudad de México (CDMX)</p>
                    <p style="font-weight: bold;">Destino</p>
                    <p>Monterrey, Nuevo León (MTY)</p>
                    <p style="font-weight: bold;">Fecha de salida</p>
                    <p>Vie, 05 jul, 2024</p>
                    <p style="font-weight: bold;">Fecha de regreso</p>
                    <p>Dom, 14 jul, 2024</p>
                </div>

                <div class="alert flight-deta12" id="costosDetails" style="color: #262E55; margin-bottom:7%;">
                    <b>Costos de vuelo</b>
                    <div class="flight-detaInfoo fade-in" style="margin-top:10%; margin-left:-25%; width:120%;">
                        <div style="display: flex; justify-content: space-between;">
                            <p style="font-weight: bold;">Tarifa base</p>
                            <p>$00.0</p>
                        </div>
                        <div style="display: flex; justify-content: space-between;">
                            <p style="font-weight: bold;">TUA
                                <span style="font-size: 17px; cursor: pointer;"
                                    title="El TUA es el impuesto de uso aeroportuario.">
                                    <i class="fa-solid fa-circle-question"></i>
                                </span>
                            </p>
                            <p>$00.0</p>
                        </div>
                        <div style="display: flex; justify-content: space-between;">
                            <p style="font-weight: bold;">Descuento</p>
                            <p>$00.0</p>
                        </div>
                        <div style="display: flex; justify-content: space-between;">
                            <p style="font-weight: bold;">Tarifa base con descuento</p>
                            <p>$00.0</p>
                        </div>
                        <div style="display: flex; justify-content: space-between;">
                            <p style="font-weight: bold;">IVA</p>
                            <p>$00.0</p>
                        </div>
                        <!---<div style="display: flex; justify-content: space-between;">
                            <p style="font-weight: bold;" class="text-success">TOTAL</p>
                            <p style="font-weight: bold; font-size:18px;" class="text-success">$00.0</p>
                        </div>--->
                    </div>
                </div>
                <div class="alert fade-up" id="alert-section" style="margin-top: 55%;">
                    <div class="destinos fade-in" style="transition: all 0.5s ease;">
                        <?php include('layouts/newdestinos.php') ?>
                        <br><br><br>
                    </div>
                </div>
            </div>
        </div>
        <!-- Footer -->
        <div>
            <footer class="footer fade-in" id="footer-section" style="background-color: #262E55; margin-top:5%;">
                <?php include('layouts/footer.php') ?>
            </footer>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/5.3.2/js/bootstrap.min.js"></script>
    <script src="https://getbootstrap.com/docs/5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>
    <script src="./assets/js/logo.js"></script>
    <script src="./assets/js/outDetailsFlight.js"></script>
    <script src="./assets/js/outDetailsFM.js"></script>
    <script src="./assets/js/outDetailsFMRegreso.js"></script>
    <script src="./assets/js/outDetailsFlightMobile2.js"></script>
    <script src="./assets/js/outDetailsFliCards.js"></script>
    <script>
        AOS.init();
    </script>
    <script>
        AOS.init({
            duration: 1000, // Duración de la animación en milisegundos
            once: true // Si quieres que la animación se ejecute solo una vez
        });
    </script>
</body>

</html>