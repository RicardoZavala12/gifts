<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>JETFLA | Seleccionar Asientos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="./assets/css/outFlights.css" rel="stylesheet">
</head>

<body>
    <div class="grid-container">
        <!-- Navbar -->
        <nav class="navbar navbar-expand-lg navbar-light fixed-top fade-in" style="background-color: #262E55" aria-label="Ninth navbar example">
            <div class="container-xl">
                <a class="navbar-brand" href="#">
                    <img id="logoCH" src="./assets/img/jetflaLogo.png" class="img-fluid hidden" alt="LogoCH" style="height: 50px;">
                </a>
                <button style="background-color:white" class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarsExample07XL" aria-controls="navbarsExample07XL" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarsExample07XL">
                    <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="#" style="color:white;">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#" style="color:white;">Link</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link disabled" href="#" tabindex="-1" aria-disabled="true" style="color:white;">Disabled</a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="dropdown07XL" data-bs-toggle="dropdown" aria-expanded="false">Dropdown</a>
                            <ul class="dropdown-menu" aria-labelledby="dropdown07XL" style="color: red">
                                <li><a class="dropdown-item" href="#"><label style="color: black;">Action</label></a></li>
                                <li><a class="dropdown-item" href="#"><label style="color: black;">Another action</label></a></li>
                                <li><a class="dropdown-item" href="#"><label style="color: black;">Something else here</label></a></li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </div>
        </nav><br><br><br><br><br>

        <!-- Main Content -->
        <div class="content-grid">
            <!-- Left Side -->
            <div class="left">
                <div class="left-text">
                    <div class="fade-in d-none d-md-block" id="salida-desktop" style="background-color: #ffffff; height: 240px; margin-left:10%;">
                        <div class="responsive-text">
                            <span class="fw-bold fs-8" style="color: #861936; font-size:30px;">Vuelos seleccionados</span>
                        </div>

                    </div>

                    <!-- MOBILE VERSION -->
                    <div class="fade-in d-block d-md-none" id="salida-mobile" style="background-color: #ffffff; padding: 0px; margin-top:-10%;">
                        <div class="responsive-text"><br><br><br>
                            <span class="fw-bold fs-8" style="color: #861936; font-size:28px;">Vuelos seleccionados</span>
                        </div><br>
                        <div class="responsive-text mt-2">
                        </div>
                    </div><br><br>
                </div>
                <div class="card-container" style="margin-left:-12%; margin-top:-30%;">
                    <?php
                    //Mock data simulating database results
                    $flights = [
                        [
                            'tipo_vuelo' => 'Salida ',
                            'departure_time' => '22:00 ',
                            'departure_code' => 'CDMX',
                            'arrival_time' => '4:30 ',
                            'arrival_code' => 'MTY',
                            'price' => '799',
                            'layover' => '1 Escala, 3 h 10 min',
                            'matriculaJet' => '1234',
                            'airline' => 'XYZ',
                            'flight_number' => 'Y2 1202',
                            'equipajeKg' => '10',
                            'fechaSalida' => 'Vie, 05 jul, 2024'
                        ],
                        [
                            'tipo_vuelo' => 'Regreso ',
                            'departure_time' => '22:00 ',
                            'departure_code' => 'CDMX',
                            'arrival_time' => '4:30 ',
                            'arrival_code' => 'MTY',
                            'price' => '999',
                            'layover' => '1 Escala, 3 h 10 min',
                            'matriculaJet' => '1234',
                            'airline' => 'XYZ',
                            'flight_number' => 'Y2 1202',
                            'equipajeKg' => '10',
                            'fechaSalida' => 'Vie, 05 jul, 2024'
                        ],
                    ];

                    foreach ($flights as $index => $flight) {
                        $detailsId = 'details-content-' . $index;
                        $detailsIcon = 'arrow-icon-' . $index;
                        echo '
        <div class="content fade-in " style="margin-top: 5%;">
            <div class="flight-info" id="flight-infoCard" style="box-shadow: 0px 5px 10px rgba(0, 0, 0, 0.5);">
            <div class="flight-details">
                    <div class="price-details">
                        <span class="price">' . $flight['tipo_vuelo'] . '</span><br>
                    </div>
                    <div style="margin-left: 0;">
                        <p style="margin: 0; padding: 0; display:flex;"><b>' . $flight['fechaSalida'] . '</b></p>
                        <p style="margin: 0; padding: 0; display:flex;">Vuelo&nbsp;<b>' . $flight['flight_number'] . '</b></p>
                        <p style="margin: 0; padding: 0; display:flex; flex-wrap: nowrap; gap: 5px;"><b>' . $flight['departure_time'] . '</b>&nbsp;' . $flight['departure_code'] . '</p>
                    </div>
                </div>
                <div class="flight-schedule" style="margin-top: -15px;">
                    <div class="flight-time">
                        <span class="time">' . $flight['departure_time'] . '</span><br>
                        <span class="airport-code">' . $flight['departure_code'] . '</span>
                    </div>
                    <div class="flight-icon">
                        <span class="line"></span>
                            <i class="fa fa-plane" ' .
                            ($flight['tipo_vuelo'] == 'Regreso' ? 'style="transform: rotate(280deg);"' : '') .
                            '></i>                        <span class="line"></span>
                    </div> 
                    <div class="flight-time">
                        <span class="time">' . $flight['arrival_time'] . '</span><br>
                        <span class="airport-code">' . $flight['arrival_code'] . '</span>
                    </div>
                </div>
                
                <div class="layover" style="margin-left:34%;">' . $flight['layover'] . '</div>
            </div>

            <div id="details-content" class="details-card d-none d-md-flex" style="box-shadow: 0px 5px 10px rgba(0, 0, 0, 0.5); margin-left: 0; display: flex; margin-left: 12%; max-height: 690px; width: 700%;">
                <div class="card-content">
                    <p><label for="details_flight" style="font-size: 14.2px; font-weight: bold; color: #262E55;">Detalles del vuelo</label></p>
                    <ul>
                        <li>Equipaje <b>' . $flight['equipajeKg'] . ' KG</b> </li>
                        <li>Comida incluida</li>
                        <li>WiFi disponible</li>
                    </ul>
                </div>
                <div class="flight-card" style="margin-left: 15% ;width: 60%; text-align: center;">
                    <p class="card-title"><strong>Directo</strong></p>
                    <div style="font-size: 30px; font-weight: bold; color: #262E55;">$' . $flight['price'] . '  MXN</div>
                </div>
            </div>
           
            
            <div id="details-content" class="details-card d-flex d-md-none" style="box-shadow: 0px 5px 10px rgba(0, 0, 0, 0.5); display: flex; margin-left: 6%; max-height: 694px; width: 700%;">
                <div class="card-content">
                    <p><label for="details_flight" style="font-size: 15px; font-weight: bold; color: #262E55;">Detallsses del vuelo</label></p>
                    <ul>
                        <li>Equipaje <b>' . $flight['equipajeKg'] . ' KG</b> </li>
                        <li>Comida incluida</li>
                        <li>WiFi disponible</li>
                    </ul>
                </div>
                <div class="flight-card">
                    <p class="card-title"><strong>Directo</strong></p>
                    <div style="font-size: 30px; font-weight: bold; color: #262E55;">$' . $flight['price'] . '  MXN </div>
                </div>
            </div>
        </div>';
                    }
                    ?>
                </div><br><br><br>
                <div class="left-text">
                    <div class="fade-in d-none d-md-block" id="salida-desktop" style="background-color: #ffffff; height: 240px; margin-left:10%;">
                        <div class="responsive-text">
                            <h2 style="margin-bottom: 40px; text-decoration: none; margin-left:-9%;" class="txtTitles" data-aos="fade-up">Extras</h2>
                        </div>
                    </div>
                    <!-- MOBILE VERSION -->
                    <div class="fade-in d-block d-md-none" id="salida-mobile" style="background-color: #ffffff; padding: 0px;">
                        <h2 style="margin-bottom: 40px;  text-decoration: none;" class="txtTitles" data-aos="fade-up">Extras</h2>
                    </div><br>
                </div><br><br><br><br>

                





                <!-- Extras -->
                <div class="card-container" style="margin-left:-12%; margin-top:-39%;">
                    <div class="content fade-in " style="margin-top: 5%;">
                        <div class="flight-info" id="flight-infoCard" style="background-color:#ffffff;">
                            <div style="display: flex; justify-content: center; gap: 50px; margin-left:20%;">

                                <!-- Columna Izquierda -->
                                <div style="display: flex; flex-direction: column; align-items: flex-end;">
                                    <div>
                                        <input type="checkbox" id="leftOption1">
                                        <label for="leftOption1">Opción 1</label>
                                    </div>
                                    <div>
                                        <input type="checkbox" id="leftOption2">
                                        <label for="leftOption2">Opción 2</label>
                                    </div>
                                    <div>
                                        <input type="checkbox" id="leftOption3">
                                        <label for="leftOption3">Opción 3</label>
                                    </div>
                                    <div>
                                        <input type="checkbox" id="leftOption4">
                                        <label for="leftOption4">Opción 4</label>
                                    </div>
                                    <div>
                                        <input type="checkbox" id="leftOption5">
                                        <label for="leftOption5">Opción 5</label>
                                    </div>
                                </div>

                                <!-- Columna Derecha -->
                                <div style="display: flex; flex-direction: column; align-items: flex-start;">
                                    <div>
                                        <input type="checkbox" id="rightOption6">
                                        <label for="rightOption6">Opción 6</label>
                                    </div>
                                    <div>
                                        <input type="checkbox" id="rightOption7">
                                        <label for="rightOption7">Opción 7</label>
                                    </div>
                                    <div>
                                        <input type="checkbox" id="rightOption8">
                                        <label for="rightOption8">Opción 8</label>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>





                    <!--- DESKTOP --->
                    <div class="fade-in d-none d-md-block" id="salida-desktop" style="background-color: #ffffff; height: 240px; margin-left:10%; margin-top:10%;">
                        <div class="responsive-text">
                            <h2 style="text-decoration: none; margin-left:2.8%;" class="txtTitles" data-aos="fade-up">Selección de asientos</h2>
                        </div>
                    </div>

                    <!--- MOBILE  --->
                    <div class="fade-in d-block d-md-none" id="salida-desktop" style="background-color: #ffffff; height: 240px; margin-left:10%; margin-top:10%; margin-bottom:-12%;">
                        <div class="responsive-text">
                            <h2 style="text-decoration: none; margin-left:2.8%;" class="txtTitles" data-aos="fade-up">Selección de asientos</h2>
                        </div>
                    </div>

                    

                    <div class="content fade-in " style="margin-top: -25%;">

                        <div class="flight-info" id="flight-infoCard" style="background-color:#ffffff;">

                            <div class="container" style="width: 100%; display: flex; justify-content: center; align-items: flex-start; flex-direction: column; margin-top: 0px;">

                                <!-- Contenedor superior que contiene los botones y leyenda -->
                                <div style="display: flex; justify-content: space-between; width: 100%;">

                                    <!-- Columna izquierda con botones Salida y Regreso -->



                                    <div class="switch-container">
                                        <input type="radio" name="switch" id="salida" checked>
                                        <input type="radio" name="switch" id="regreso">

                                        <div class="switch">
                                            <label for="salida" class="switch-label salida d-none d-md-block">Salida</label>
                                            <label for="regreso" class="switch-label regreso d-none d-md-block">Regreso</label>

                                            <!--- MOBILE --->
                                            <label for="salida" class="switch-label salida d-block d-md-none">Salida</label>
                                            <label for="regreso" class="switch-label regreso d-block d-md-none">Regreso</label>

                                            <div class="switch-toggle"></div>
                                        </div>
                                    </div>

                                    <style>
                                        .switch-container {
                                            display: flex;
                                            justify-content: center;
                                            width: 50%;
                                            margin: 20px auto;
                                        }

                                        .switch {
                                            position: relative;
                                            display: flex;
                                            width: 100%;
                                            background-color: #ccc;
                                            border-radius: 35px;
                                            overflow: hidden;
                                            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
                                            transition: box-shadow 0.3s ease;
                                        }

                                        .switch:hover {
                                            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.3);
                                        }

                                        .switch-label {
                                            flex: 1;
                                            text-align: center;
                                            padding: 15px;
                                            font-weight: bold;
                                            color: #262E55;
                                            cursor: pointer;
                                            z-index: 1;
                                            position: relative;
                                            transition: color 0.3s ease;
                                        }

                                        .switch-toggle {
                                            position: absolute;
                                            top: 0;
                                            bottom: 0;
                                            width: 50%;
                                            background-color: #861936;
                                            border-radius: 20px;
                                            transition: transform 0.3s ease, background-color 0.3s ease;
                                        }

                                        /* Ocultar inputs */
                                        input[type="radio"] {
                                            display: none;
                                        }

                                        /* Estilo de la opción seleccionada */
                                        input#salida:checked~.switch .switch-toggle {
                                            transform: translateX(0);
                                        }

                                        input#regreso:checked~.switch .switch-toggle {
                                            transform: translateX(100%);
                                        }

                                        /* Cambiar el color del texto según la selección */
                                        input#salida:checked~.switch .salida {
                                            color: white;
                                        }

                                        input#regreso:checked~.switch .regreso {
                                            color: white;
                                        }

                                        input#salida:checked~.switch .regreso,
                                        input#regreso:checked~.switch .salida {
                                            color: #262E55;
                                        }

                                        /* Iconos con pseudo-elementos */
                                        .switch-label::before {
                                            font-family: 'FontAwesome';
                                            content: '\f072';
                                            /* Icono de avión */
                                            display: block;
                                            font-size: 1.5em;
                                            margin-top: 5px;
                                            transition: transform 0.3s ease;
                                        }

                                        /* Rotación según selección */
                                        input#salida:checked~.switch .salida::before {
                                            transform: rotate(-314deg);
                                        }

                                        input#regreso:checked~.switch .regreso::before {
                                            transform: rotate(225deg);
                                        }
                                    </style>




                                    <!-- Leyenda de los asientos -->
                                    <div class="d-none d-md-block" style="padding: 10px; width: 45%; margin-left: 12px; margin-top:3%;">
                                        <div style="display: flex; align-items: center; margin-bottom: 10px;">
                                            <div style="width: 20px; height: 20px; background-color: green; border-radius: 50%; margin-right: 10px;"></div>
                                            <p style="margin: 0;">Libre</p>
                                        </div>
                                        <div style="display: flex; align-items: center; margin-bottom: 10px;">
                                            <div style="width: 20px; height: 20px; background-color: gray; border-radius: 50%; margin-right: 10px;"></div>
                                            <p style="margin: 0;">Ocupado</p>
                                        </div>
                                        <div style="display: flex; align-items: center;">
                                            <div style="width: 20px; height: 20px; background-color: yellow; border-radius: 50%; margin-right: 10px;"></div>
                                            <p style="margin: 0;">Seleccionado</p>
                                        </div>
                                    </div>


                                    <!-- MOBILE Leyenda de los asientos -->
                                    <br>
                                    <div class="d-block d-md-none" style="padding: 10px; width: 45%; margin-left: 12px; margin-top:4%;">
                                        <div style="display: flex; align-items: center; margin-bottom: 10px;">
                                            <div style="width: 20px; height: 20px; background-color: green; border-radius: 50%; margin-right: 10px;"></div>
                                            <p style="margin: 0;">Libre</p>
                                        </div>
                                        <div style="display: flex; align-items: center; margin-bottom: 10px;">
                                            <div style="width: 20px; height: 20px; background-color: gray; border-radius: 50%; margin-right: 10px;"></div>
                                            <p style="margin: 0;">Ocupado</p>
                                        </div>
                                        <div style="display: flex; align-items: center;">
                                            <div style="width: 20px; height: 20px; background-color: yellow; border-radius: 50%; margin-right: 10px;"></div>
                                            <p style="margin: 0;">Seleccionado</p>
                                        </div>
                                    </div>

                                </div>

                                <!-- Diagrama de aviones en la parte inferior y centrado -->
                                <div style="display: flex; justify-content: center; align-items: center; margin-top: 20px; margin-bottom: 15%; width: 100%; ">
                                    <div style="border: 1px solid #ccc; border-radius: 80px 80px 10px 10px; padding: 20px; text-align: center;  margin-top: 5%; ">
                                        <strong>CABINA</strong> <br>
                                        <div class="seat-container" style="align-items: center; margin-top: 5%;   ">
                                            <!-- Asientos (Ejemplo: 12 asientos) -->
                                            <div class="seat" data-seat="1A">1A</div>
                                            <div class="seat occupied" data-seat="1B">1B</div>
                                            <div class="space"></div>
                                            <div class="seat occupied" data-seat="1D">2C</div>
                                            <div class="seat" data-seat="2A">2D</div>
                                            <div class="seat" data-seat="2B">3E</div>
                                            <div class="seat" data-seat="2C">3F</div>
                                            <div class="space"></div>
                                            <div class="seat" data-seat="3A">4G</div>
                                            <div class="seat occupied" data-seat="3B">4H</div>
                                            <div class="seat" data-seat="3C">5I</div>
                                            <div class="seat" data-seat="3D">5J</div>
                                            <div class="space"></div>
                                            <div class="seat" data-seat="3C">6K</div>
                                            <div class="seat" data-seat="3D">6L</div>
                                            <div class="seat" data-seat="3C">7M</div>
                                            <div class="seat" data-seat="3D">7N</div>
                                            <div class="space"></div>
                                            <div class="seat" data-seat="3C">8O</div>
                                            <div class="seat" data-seat="3D">8P</div>
                                        </div>


                                    </div>

                                    <style>
                                        .space {
                                            width: 40px;
                                            height: 40px;
                                            margin: 5px;
                                            background-color: transparent;
                                        }


                                        /* Estilos para los asientos */
                                        .seat {
                                            width: 40px;
                                            height: 40px;
                                            margin: 5px;
                                            background-color: green;
                                            /* Asientos disponibles */
                                            border-radius: 5px;
                                            display: inline-block;
                                            text-align: center;
                                            line-height: 40px;
                                            color: white;
                                            font-weight: bold;
                                            cursor: pointer;
                                        }

                                        .seat.occupied {
                                            background-color: grey;
                                            /* Asientos ocupados */
                                            cursor: not-allowed;
                                        }

                                        .seat.selected {
                                            background-color: yellow;
                                            /* Asiento seleccionado */
                                            color: black;
                                        }

                                        .seat-container {
                                            display: flex;
                                            flex-wrap: wrap;
                                            width: 250px;
                                            margin-top: 20px;
                                        }
                                    </style>


                                    <script>
                                        const seats = document.querySelectorAll('.seat:not(.occupied)'); // Asientos que no están ocupados

                                        seats.forEach(seat => {
                                            seat.addEventListener('click', () => {
                                                seat.classList.toggle('selected'); // Alternar entre seleccionado y no seleccionado
                                            });
                                        });
                                    </script>


                                </div>





                            </div>
                        </div>



                    </div>
















                </div>
                <!-- Mobile: Another div below (before footer) -->
                <div class="alert d-block d-md-none fade-in" data-aos="fade-up">


                    <div class="alert flight-deta12" id="casientosSeleccion" style="color: #262E55; margin-bottom:40%;"> <!-- Ajuste en top -->
                        <b style="color: #861936; font-size:20px;">Asientos seleccionados </b><br>
                        <div class="flight-detaInfoo fade-in" style="margin-top:14%; margin-left:-25%; width:100%;">
                            <div style="display: flex; justify-content: space-between;">
                                <p style="font-weight: bold; font-size:18px;">Salida</p>
                                <p style="font-weight: bold;">&nbsp;&nbsp; CDMX → MTY</p>
                                <p style="font-weight: bold; color: #861936;">8P</p>
                            </div>
                            <div style="display: flex; justify-content: space-between;">
                                <p style="font-weight: bold; font-size:18px;">Regreso</p>
                                <p style="font-weight: bold;">MTY → CDMX</p>
                                <p style="font-weight: bold; color: #861936;">6K</p>
                            </div>
                        </div>
                    </div>



                    <div class="alert flight-deta12" id="costosDetails" style="color: #262E55; margin-bottom:70%; margin-top:15%;">
                    <b style="color: #861936;">Reservación</b>
                    <div class="flight-detaInfoo fade-in" style="margin-top:12%; margin-left:-25%; width:100%;">
                        <div style="display: flex; justify-content: space-between;">
                            <p style="font-weight: bold;">Tarifa base</p>
                            <p>$00.0</p>
                        </div>
                        <div style="display: flex; justify-content: space-between;">
                            <p style="font-weight: bold;">TUA
                                <span style="font-size: 17px; cursor: pointer;"
                                    title="El TUA es el impuesto de uso aeroportuario.">
                                    <i class="fa-solid fa-circle-question"></i>
                                </span>
                            </p>
                            <p>$00.0</p>
                        </div>
                        <div style="display: flex; justify-content: space-between;">
                            <p style="font-weight: bold;">Descuento</p>
                            <p>$00.0</p>
                        </div>
                        <div style="display: flex; justify-content: space-between;">
                            <p style="font-weight: bold;">Tarifa base con descuento</p>
                            <p>$00.0</p>
                        </div>
                        <div style="display: flex; justify-content: space-between;">
                            <p style="font-weight: bold;">IBBBA</p>
                            <p>$00.0</p>
                        </div>

                    </div>
                </div>

                <div class="alert flight-deta12" id="costosDetails" style="color: #262E55; margin-bottom:95%; position: sticky; top: 15%;">
                    <b style="color: #861936;">Costos de vuelo</b>
                    <div class="flight-detaInfoo fade-in" style="margin-top:12%; margin-left:-25%; width:100%;">
                        <div style="display: flex; justify-content: space-between;">
                            <p style="font-weight: bold;">Tarifa base</p>
                            <p>$00.0</p>
                        </div>
                        <div style="display: flex; justify-content: space-between;">
                            <p style="font-weight: bold;">TUA
                                <span style="font-size: 17px; cursor: pointer;" title="El TUA es el impuesto de uso aeroportuario.">
                                    <i class="fa-solid fa-circle-question"></i>
                                </span>
                            </p>
                            <p>$00.0</p>
                        </div>
                        <div style="display: flex; justify-content: space-between;">
                            <p style="font-weight: bold;">Descuento</p>
                            <p>$00.0</p>
                        </div>
                        <div style="display: flex; justify-content: space-between;">
                            <p style="font-weight: bold;">Tarifa base con descuento</p>
                            <p>$00.0</p>
                        </div>
                        <div style="display: flex; justify-content: space-between;">
                            <p style="font-weight: bold;">IVA</p>
                            <p>$00.0</p>
                        </div>
                        
                    </div>
                </div>

                <div class="flight-cost-container" style=" margin-bottom:-1%; position: sticky; top:calc(45% + 550px);">
                    <div class="alert flight-deta12" id="costosDetails" style="color: #262E55; ">
                        <b style="color: #861936; font-size:25px;" class="text-success">Total</b>
                        <b style="color: #861936; font-size:25px;" class="text-success">$&nbsp;3,731 MXN </b>
                    </div>
                    <!--<div class="alert flight-deta12" id="costosDetails" style="color: green;  margin-bottom:-2.5%; top:-9%; display: flex; justify-content: center; align-items: center; background-color:#31BC36;">
                        <b style="color: #861936; font-size:17px; text-align:center;" class="text-light">PRECIO FINAL</b>
                    </div>--->
                    <button type="submit" class="btn-s btn-submit" style="border-radius: 20px; width:80%; margin-left:12%; display: flex; justify-content: center;">Adquirir vuelo</button>
                </div>


                









                </div>
            </div>

            <!-- Right Side (Visible only on desktop) -->
            <div class="right-side fade-in">


                <div class="alert flight-deta12" id="costosDetails" style="color: #262E55; margin-bottom:7%; margin-top:15%;">
                    <b style="color: #861936;">Reservación</b>
                    <div class="flight-detaInfoo fade-in" style="margin-top:8%; margin-left:-25%; width:120%;">
                        <div style="display: flex; justify-content: space-between;">
                            <p style="font-weight: bold;">Tarifa base</p>
                            <p>$00.0</p>
                        </div>
                        <div style="display: flex; justify-content: space-between;">
                            <p style="font-weight: bold;">TUA
                                <span style="font-size: 17px; cursor: pointer;"
                                    title="El TUA es el impuesto de uso aeroportuario.">
                                    <i class="fa-solid fa-circle-question"></i>
                                </span>
                            </p>
                            <p>$00.0</p>
                        </div>
                        <div style="display: flex; justify-content: space-between;">
                            <p style="font-weight: bold;">Descuento</p>
                            <p>$00.0</p>
                        </div>
                        <div style="display: flex; justify-content: space-between;">
                            <p style="font-weight: bold;">Tarifa base con descuento</p>
                            <p>$00.0</p>
                        </div>
                        <div style="display: flex; justify-content: space-between;">
                            <p style="font-weight: bold;">IBBBA</p>
                            <p>$00.0</p>
                        </div>

                    </div>
                </div><br><br><br><br><br><br><br><br><br>


                <!-- Primer div -->
                <div class="alert flight-deta12" id="costosDetails" style="color: #262E55; margin-bottom:95%; position: sticky; top: 15%;">
                    <b style="color: #861936;">Costos de vuelo</b>
                    <div class="flight-detaInfoo fade-in" style="margin-top:8%; margin-left:-25%; width:120%;">
                        <div style="display: flex; justify-content: space-between;">
                            <p style="font-weight: bold;">Tarifa base</p>
                            <p>$00.0</p>
                        </div>
                        <div style="display: flex; justify-content: space-between;">
                            <p style="font-weight: bold;">TUA
                                <span style="font-size: 17px; cursor: pointer;" title="El TUA es el impuesto de uso aeroportuario.">
                                    <i class="fa-solid fa-circle-question"></i>
                                </span>
                            </p>
                            <p>$00.0</p>
                        </div>
                        <div style="display: flex; justify-content: space-between;">
                            <p style="font-weight: bold;">Descuento</p>
                            <p>$00.0</p>
                        </div>
                        <div style="display: flex; justify-content: space-between;">
                            <p style="font-weight: bold;">Tarifa base con descuento</p>
                            <p>$00.0</p>
                        </div>
                        <div style="display: flex; justify-content: space-between;">
                            <p style="font-weight: bold;">IVA</p>
                            <p>$00.0</p>
                        </div>
                        <div style="display: flex; justify-content: space-between;">
                            <p style="font-weight: bold;" class="text-success">TOTAL</p>
                            <p style="font-weight: bold; font-size:18px;" class="text-success">$00.0</p>
                        </div>
                    </div>
                </div>

                <!-- Segundo div -->
                <div class="alert flight-deta12" id="casientosSeleccion" style="color: #262E55; margin-bottom:40%; position: sticky; top: calc(15% + 350px);"> <!-- Ajuste en top -->
                    <b style="color: #861936; font-size:20px;">Asientos seleccionados </b><br>
                    <div class="flight-detaInfoo fade-in" style="margin-top:10%; margin-left:-25%; width:200%;">
                        <div style="display: flex; justify-content: space-between;">
                            <p style="font-weight: bold; font-size:18px;">Salida</p>
                            <p style="font-weight: bold;">&nbsp;&nbsp; CDMX → MTY</p>
                            <p style="font-weight: bold; color: #861936;">8P</p>
                        </div>
                        <div style="display: flex; justify-content: space-between;">
                            <p style="font-weight: bold; font-size:18px;">Regreso</p>
                            <p style="font-weight: bold;">MTY → CDMX</p>
                            <p style="font-weight: bold; color: #861936;">6K</p>
                        </div>
                    </div>
                </div>



                <!-- Tercer div -->
                <div class="flight-cost-container" style=" margin-bottom:-1%; position: sticky; top:calc(45% + 550px);">
                    <div class="alert flight-deta12" id="costosDetails" style="color: #262E55; ">
                        <b style="color: #861936; font-size:25px;" class="text-success">Total</b>
                        <b style="color: #861936; font-size:25px;" class="text-success">$&nbsp;3,731 MXN </b>
                    </div>
                    <!--<div class="alert flight-deta12" id="costosDetails" style="color: green;  margin-bottom:-2.5%; top:-9%; display: flex; justify-content: center; align-items: center; background-color:#31BC36;">
                        <b style="color: #861936; font-size:17px; text-align:center;" class="text-light">PRECIO FINAL</b>
                    </div>--->
                    <button type="submit" class="btn-s btn-submit" style="border-radius: 20px; width:80%; margin-left:12%; display: flex; justify-content: center;">Adquirir vuelo</button>
                </div>

            </div>
        </div>








        <style>

        </style>
        <!-- Footer -->
        <div>
            <footer class="footer fade-in" id="footer-section" style="background-color: #262E55; margin-top:5%;">
                <?php include('layouts/footer.php') ?>
            </footer>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="./assets/js/logo.js"></script>
    <script src="./assets/js/outDetailsFlight.js"></script>
    <script src="./assets/js/outDetailsFM.js"></script>
    <script src="./assets/js/outDetailsFMRegreso.js"></script>
    <script src="./assets/js/outDetailsFlightMobile2.js"></script>
    <script src="./assets/js/outDetailsFliCards.js"></script>
    <script>
        AOS.init();
    </script>
    <script>
        AOS.init({
            duration: 1000, // Duración de la animación en milisegundos
            once: true // Si quieres que la animación se ejecute solo una vez
        });
    </script>
</body>

</html>