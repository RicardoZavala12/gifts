<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>JETFLA | Confirmar Pago</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="./assets/css/outFlights.css" rel="stylesheet">
    <link href="./assets/css/nabvar.css" rel="stylesheet">
    <link href="./assets/css/home.css" rel="stylesheet">
    <link href="./assets/css/pago.css" rel="stylesheet">
   
    <link href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.css" rel="stylesheet">
    <style> body {margin: 0;padding: 0;font-family: Arial, sans-serif;}.content {padding: 20px;}</style>

</head>

<body>
    <div class="grid-container">
        <!-- Navbar -->
        <nav class="navbar navbar-expand-lg navbar-light fixed-top fade-in" style="background-color: #262E55" aria-label="Ninth navbar example">
            <div class="container-xl">
                <a class="navbar-brand" href="#">
                    <img id="logoCH" src="./assets/img/jetflaLogo.png" class="img-fluid hidden" alt="LogoCH" style="height: 50px;">
                </a>
                <button style="background-color:white" class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarsExample07XL" aria-controls="navbarsExample07XL" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarsExample07XL">
                    <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="#" style="color:white;">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#" style="color:white;">Link</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link disabled" href="#" tabindex="-1" aria-disabled="true" style="color:white;">Disabled</a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="dropdown07XL" data-bs-toggle="dropdown" aria-expanded="false">Dropdown</a>
                            <ul class="dropdown-menu" aria-labelledby="dropdown07XL" style="color: red">
                                <li><a class="dropdown-item" href="#"><label style="color: black;">Action</label></a></li>
                                <li><a class="dropdown-item" href="#"><label style="color: black;">Another action</label></a></li>
                                <li><a class="dropdown-item" href="#"><label style="color: black;">Something else here</label></a></li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </div>
        </nav><br><br><br><br><br>

        <!-- Main Content -->
        <div class="content-grid">
            <!-- Left Side -->
            <div class="left">
                <div class="left-text">
                    <div class="reservation-cards fade-in d-none d-md-flex" style="margin-bottom:25%; margin-right: 6%; box-shadow: 0px 5px 10px rgba(0, 0, 0, 0.2);" data-aos="fade-up">
                        <div class="icon-text">
                            <div class="icon">
                                <img src="./assets/img/reloj.png" alt="Clock Icon">
                            </div>
                            <div class="text">
                                <strong>JETFLA | Reservar tarifas</strong>
                                <p>Cuentas con 24 hrs para realizar
                                    el pago de tu vuelo.</p>
                            </div>
                        </div>
                        <button class="pay-later">Pagar después</button>
                    </div>

                    <!-- MOBILE -->
                    <div class="reservation-cards fade-in d-flex d-md-none" style="margin-bottom:25%; box-shadow: 0px 5px 10px rgba(0, 0, 0, 0.2    );" data-aos="fade-up">
                        <div class="icon-text">
                            <div class="icon">
                                <img src="./assets/img/reloj.png" alt="Clock Icon">
                            </div>
                            <div class="text">
                                <strong>JETFLA | Reservar tarifas</strong>
                                <p>Cuentas con 24 hrs para realizar
                                    el pago de tu vuelo.</p>
                            </div>
                        </div>
                        <button class="pay-later">Pagar después</button>
                    </div><br><br>
                </div>

                <div class="card-container" style="margin-left:2%; margin-top:-30%;"><br>

                    <div class="responsive-text fade-in" style="margin-left:3%;" data-aos="fade-up">
                        <span class="fw-bold fs-8" style="color: #861936; font-size:28px;">Información del pasajero</span>
                    </div>
                    <div class="content fade-in" style="margin-top: 5%; " data-aos="fade-up">
                        <div class="form-container fade-in" style="height: 370px; position: relative;">
                            <!-- Contenedor del Título -->
                            <div style="position: absolute; top: 10px; left: 5%; text-align: start;">
                                <h6 style="font-weight: bold; margin: 0; color:#262E55;">Adulto 1</h6>
                                <p style="opacity: 0.6; margin: 0; color:#262E55;">Complete su información personal.</p>
                            </div>

                            <!-- Formulario Info del Pasajero -->
                            <form>
                                <div class="row" style="padding-top: 10%;">
                                    <!-- Columna Izquierda -->
                                    <div class="col-6">
                                        <div class="form-group custom-form-group">
                                            <label for="nombres" class="form-label" style="opacity: 0.6;">Nombres</label>
                                            <input style="font-style: italic;" type="text" class="form-control" id="nombres" name="nombres" placeholder="Ingresar" required>
                                        </div>
                                        <div class="form-group custom-form-group">
                                            <label for="genero" class="form-label" style="opacity: 0.6;">Género</label>
                                            <select class="form-control" id="genero" name="genero" required>
                                                <option value="" disabled selected>Seleccionar</option>
                                                <option value="femenino">Femenino</option>
                                                <option value="masculino">Masculino</option>
                                                <option value="otro">Otro</option>
                                            </select>
                                        </div>
                                        <div class="form-group custom-form-group">
                                            <label for="nacionalidad" class="form-label" style="opacity: 0.6;">Nacionalidad</label>
                                            <select class="form-control" id="nacionalidad" name="nacionalidad" required>
                                                <option value="" disabled selected>Seleccionar</option>
                                                <option value="mx">Mexicana</option>
                                                <option value="us">Estadounidense</option>
                                                <option value="otro">Otra</option>
                                            </select>
                                        </div>
                                    </div>

                                    <!-- Columna Derecha -->
                                    <div class="col-6">
                                        <div class="form-group custom-form-group">
                                            <label for="apellidos" class="form-label" style="opacity: 0.6;">Apellidos</label>
                                            <input style="font-style: italic;" type="text" class="form-control" id="apellidos" name="apellidos" placeholder="Ingresar" required>
                                        </div>
                                        <div class="form-group custom-form-group">
                                            <label for="fechaNacimiento" class="form-label" style="opacity: 0.6;">Fecha de nacimiento</label>
                                            <input type="date" class="form-control" id="fechaNacimiento" name="fechaNacimiento" required>
                                        </div>
                                        <div class="form-group custom-form-group" style="margin-top: 18%;">
                                            <button type="submit" class="btn-submit" style="width: 100%; ">Siguiente&nbsp;<i class="fa-solid fa-arrow-right"></i></button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>


                    <div class="responsive-text fade-in" style="margin-left:3%; margin-top: 10%;" data-aos="fade-up">
                        <span class="fw-bold fs-8" style="color: #861936; font-size:28px;">Contacto</span>
                    </div>
                    <div class="content fade-in" style="margin-top: 5%; " data-aos="fade-up">
                        <div class="form-container fade-in" style="height: 370px; position: relative;">
                            <!-- Contenedor del Título -->
                            <div style="position: absolute; top: 10px; left: 5%; text-align: start;">
                                <h6 style="font-weight: bold; margin: 0; color:#262E55;">Deatalles de contacto</h6>
                                <p style="opacity: 0.6; margin: 0; color:#262E55;">Notificaremos toda informacion relacionada con tu vuelo.</p>
                            </div>

                            <!-- Formulario -->
                            <form>
                                <div class="row" style="padding-top: 10%;">
                                    <!-- Columna Izquierda -->
                                    <div class="col-6">
                                        <div class="form-group custom-form-group">
                                            <label for="nombres" class="form-label" style="opacity: 0.6;">Nombres</label>
                                            <input style="font-style: italic;" type="text" class="form-control" id="nombres" name="nombres" placeholder="Ingresar" required>
                                        </div>
                                        <div class="form-group custom-form-group">
                                            <label for="nombres" class="form-label" style="opacity: 0.6;">Email</label>
                                            <input style="font-style: italic;" type="email" class="form-control" id="nombres" name="nombres" placeholder="Ingresar" required>
                                        </div>
                                        <div class="form-group" style="display: flex; align-items: center; gap: 10px;">
                                            <!-- Select de claves de país -->
                                            <div style="flex: 0 0 auto;">
                                                <label for="countryCode" class="form-label" style="opacity: 0.6;">Clave País</label>
                                                <select id="countryCode" name="countryCode" class="form-select" style="font-style: italic; background-color:transparent;">
                                                    <option value="+1">+1</option>
                                                    <option value="+44">+44</option>
                                                    <option value="+52">+52</option>
                                                    <option value="+34">+34 </option>
                                                    <option value="+91">+91</option>
                                                    <!-- Agrega más opciones según los países que necesites -->
                                                </select>
                                            </div>
                                            <!-- Input del teléfono celular -->
                                            <div style="flex: 1;">
                                                <label for="nombres" class="form-label" style="opacity: 0.6;">Teléfono celular</label>
                                                <input style="font-style: italic;" type="number" class="form-control" id="nombres" name="nombres" placeholder="Ingresar" required>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Columna Derecha -->
                                    <div class="col-6">
                                        <div class="form-group custom-form-group">
                                            <label for="apellidos" class="form-label" style="opacity: 0.6;">Apellidos</label>
                                            <input style="font-style: italic;" type="text" class="form-control" id="apellidos" name="apellidos" placeholder="Ingresar" required>
                                        </div>
                                        <div class="form-group custom-form-group">
                                            <label for="nombres" class="form-label" style="opacity: 0.6;">Verificar email</label>
                                            <input style="font-style: italic;" type="email" class="form-control" id="nombres" name="nombres" placeholder="Ingresar" required>
                                        </div>
                                        <div class="form-group" style="margin-top: 18%;">
                                            <button type="submit" class="btn-submit" style="width: 100%; ">Siguiente&nbsp;<i class="fa-solid fa-arrow-right"></i></button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>

                    <div class="responsive-text fade-in" style="margin-left:3%; margin-top: 10%;" data-aos="fade-up">
                        <span class="fw-bold fs-8" style="color: #861936; font-size:28px;">Seleccionar forma de pago</span>
                    </div>
                    <div class="fade-in" style="display: flex; gap: 20px; margin-top: 5%; margin-left:20%;" data-aos="fade-up">
                        <!-- Botón PayPal -->
                        <div class="payment-option">
                            <img src="https://upload.wikimedia.org/wikipedia/commons/a/a4/Paypal_2014_logo.png" alt="PayPal" width="50">
                            <p>PayPal</p>
                        </div>

                        <!-- Botón Tarjeta de débito/crédito -->
                        <div class="payment-option">
                            <img src="./assets/img/creditCard.png" alt="Tarjeta" width="50">
                            <p>Tarjeta de débito/crédito</p>
                        </div>
                    </div>

                    <div class="content fade-in" style="margin-top: 3%; " data-aos="fade-up">
                        <div class="form-container fade-in" style="height: 370px; position: relative;">
                            <!-- Contenedor del Título -->
                            <div style="position: absolute; top: 10px; left: 5%; text-align: start;">
                                <h6 style="font-weight: bold; margin: 0; color:#262E55;">Tarjeta de debito/credito</h6>
                                <p style="opacity: 0.6; margin: 0; color:#262E55;">Ingresa los datos de tu tarjeta.</p>
                            </div>

                            <!-- Formulario -->
                            <form>
                                <div class="row" style="padding-top: 10%;">
                                    <!-- Columna Izquierda -->
                                    <div class="col-6">
                                        <div class="form-group custom-form-group">
                                            <label for="nombres" class="form-label" style="opacity: 0.6;">Numero de tarjeta</label>
                                            <input style="font-style: italic;" type="number" class="form-control" id="card-number" name="card-number" maxlength="4" placeholder="1234 5678 9012 3456" required>
                                        </div>
                                        <div class="form-group custom-form-group">
                                            <label for="nombres" class="form-label" style="opacity: 0.6;">CCV</label>
                                            <input style="font-style: italic;" type="number" class="form-control" id="nombres" name="nombres" maxlength="4" placeholder="000'0" required>
                                        </div>
                                    </div>

                                    <!-- Columna Derecha -->
                                    <div class="col-6">
                                        <div class="form-group custom-form-group">
                                            <label for="nombres" class="form-label" style="opacity: 0.6;">Fecha de expiración</label>
                                            <input style="font-style: italic;" type="text" class="form-control" id="expiry-date" name="nombres" maxlength="5" placeholder="MM/YY" required oninput="applyMask(this)">

                                        </div><br>
                                        <div class="form-group custom-form-group">
                                            <input type="checkbox" id="nombres" name="nombres" required> <b style="opacity: 0.6; font-weight: normal;">
                                                Acepto el uso de mi información en <a href="#" style="color: #861936 !important; text-decoration: none;">Términos y condiciones</a>
                                            </b>
                                        </div>
                                        <div class="form-group" style="margin-top: 18%; margin-left:-60%;">
                                            <button type="submit" class="btn-submit" style="width: 100%; margin-left:-30%; ">Pagar mi proximo vuelo ✓</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div><br><br><br>

                <!-- Mobile: Another div below (before footer) -->
                <div class="alert d-block d-md-none fade-in" data-aos="fade-up">
                    <div class="alert flight-deta12" id="casientosSeleccion" style="color: #262E55; margin-bottom:40%;"> <!-- Ajuste en top -->
                        <b style="color: #861936; font-size:20px;">Asientos seleccionados </b><br>
                        <div class="flight-detaInfoo fade-in" style="margin-top:14%; margin-left:-25%; width:100%;">
                            <div style="display: flex; justify-content: space-between;">
                                <p style="font-weight: bold; font-size:18px;">Salida</p>
                                <p style="font-weight: bold;">&nbsp;&nbsp; CDMX → MTY</p>
                                <p style="font-weight: bold; color: #861936;">8P</p>
                            </div>
                            <div style="display: flex; justify-content: space-between;">
                                <p style="font-weight: bold; font-size:18px;">Regreso</p>
                                <p style="font-weight: bold;">MTY → CDMX</p>
                                <p style="font-weight: bold; color: #861936;">6K</p>
                            </div>
                        </div>
                    </div>

                    <div class="alert flight-deta12" id="costosDetails" style="color: #262E55; margin-bottom:70%; margin-top:15%;">
                        <b style="color: #861936;">Reservación</b>
                        <div class="flight-detaInfoo fade-in" style="margin-top:12%; margin-left:-25%; width:100%;">
                            <div style="display: flex; justify-content: space-between;">
                                <p style="font-weight: bold;">Tarifa base</p>
                                <p>$00.0</p>
                            </div>
                            <div style="display: flex; justify-content: space-between;">
                                <p style="font-weight: bold;">TUA
                                    <span style="font-size: 17px; cursor: pointer;"
                                        title="El TUA es el impuesto de uso aeroportuario.">
                                        <i class="fa-solid fa-circle-question"></i>
                                    </span>
                                </p>
                                <p>$00.0</p>
                            </div>
                            <div style="display: flex; justify-content: space-between;">
                                <p style="font-weight: bold;">Descuento</p>
                                <p>$00.0</p>
                            </div>
                            <div style="display: flex; justify-content: space-between;">
                                <p style="font-weight: bold;">Tarifa base con descuento</p>
                                <p>$00.0</p>
                            </div>
                            <div style="display: flex; justify-content: space-between;">
                                <p style="font-weight: bold;">IBBBA</p>
                                <p>$00.0</p>
                            </div>

                        </div>
                    </div>

                    <div class="alert flight-deta12" id="costosDetails" style="color: #262E55; margin-bottom:95%; position: sticky; top: 15%;">
                        <b style="color: #861936;">Costos de vuelo</b>
                        <div class="flight-detaInfoo fade-in" style="margin-top:12%; margin-left:-25%; width:100%;">
                            <div style="display: flex; justify-content: space-between;">
                                <p style="font-weight: bold;">Tarifa base</p>
                                <p>$00.0</p>
                            </div>
                            <div style="display: flex; justify-content: space-between;">
                                <p style="font-weight: bold;">TUA
                                    <span style="font-size: 17px; cursor: pointer;" title="El TUA es el impuesto de uso aeroportuario.">
                                        <i class="fa-solid fa-circle-question"></i>
                                    </span>
                                </p>
                                <p>$00.0</p>
                            </div>
                            <div style="display: flex; justify-content: space-between;">
                                <p style="font-weight: bold;">Descuento</p>
                                <p>$00.0</p>
                            </div>
                            <div style="display: flex; justify-content: space-between;">
                                <p style="font-weight: bold;">Tarifa base con descuento</p>
                                <p>$00.0</p>
                            </div>
                            <div style="display: flex; justify-content: space-between;">
                                <p style="font-weight: bold;">IVA</p>
                                <p>$00.0</p>
                            </div>

                        </div>
                    </div>

                    <div class="flight-cost-container" style=" margin-bottom:-1%; position: sticky; top:calc(45% + 550px);">
                        <div class="alert flight-deta12" id="costosDetails" style="color: #262E55; ">
                            <b style="color: #861936; font-size:25px;" class="text-success">Total</b>
                            <b style="color: #861936; font-size:25px;" class="text-success">$&nbsp;3,731 MXN </b>
                        </div>
                        <div class="alert flight-deta12" id="costosDetails" style="color: green;  margin-bottom:-2.5%; top:-9%; display: flex; justify-content: center; align-items: center; background-color:#31BC36;">
                            <b style="color: #861936; font-size:17px; text-align:center;" class="text-light">PRECIO FINAL</b>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Right Side (Visible only on desktop) -->
            <div class="right-side fade-in">

                <div class="alert flight-deta12" id="costosDetails" style="color: #262E55; margin-bottom:7%; margin-top:22%;">
                    <b style="color: #861936;">Reservación</b>
                    <div class="flight-detaInfoo fade-in" style="margin-top:8%; margin-left:-25%; width:120%;">
                        <div style="display: flex; justify-content: space-between;">
                            <p style="font-weight: bold;">Tarifa base</p>
                            <p>$00.0</p>
                        </div>
                        <div style="display: flex; justify-content: space-between;">
                            <p style="font-weight: bold;">TUA
                                <span style="font-size: 17px; cursor: pointer;"
                                    title="El TUA es el impuesto de uso aeroportuario.">
                                    <i class="fa-solid fa-circle-question"></i>
                                </span>
                            </p>
                            <p>$00.0</p>
                        </div>
                        <div style="display: flex; justify-content: space-between;">
                            <p style="font-weight: bold;">Descuento</p>
                            <p>$00.0</p>
                        </div>
                        <div style="display: flex; justify-content: space-between;">
                            <p style="font-weight: bold;">Tarifa base con descuento</p>
                            <p>$00.0</p>
                        </div>
                        <div style="display: flex; justify-content: space-between;">
                            <p style="font-weight: bold;">IBBBA</p>
                            <p>$00.0</p>
                        </div>

                    </div>
                </div><br><br><br><br><br><br><br><br><br>
                <!-- Primer div -->
                <div class="alert flight-deta12" id="costosDetails" style="color: #262E55; margin-bottom:95%; position: sticky; top: 15%;">
                    <b style="color: #861936;">Costos de vuelo</b>
                    <div class="flight-detaInfoo fade-in" style="margin-top:8%; margin-left:-25%; width:120%;">
                        <div style="display: flex; justify-content: space-between;">
                            <p style="font-weight: bold;">Tarifa base</p>
                            <p>$00.0</p>
                        </div>
                        <div style="display: flex; justify-content: space-between;">
                            <p style="font-weight: bold;">TUA
                                <span style="font-size: 17px; cursor: pointer;" title="El TUA es el impuesto de uso aeroportuario.">
                                    <i class="fa-solid fa-circle-question"></i>
                                </span>
                            </p>
                            <p>$00.0</p>
                        </div>
                        <div style="display: flex; justify-content: space-between;">
                            <p style="font-weight: bold;">Descuento</p>
                            <p>$00.0</p>
                        </div>
                        <div style="display: flex; justify-content: space-between;">
                            <p style="font-weight: bold;">Tarifa base con descuento</p>
                            <p>$00.0</p>
                        </div>
                        <div style="display: flex; justify-content: space-between;">
                            <p style="font-weight: bold;">IVA</p>
                            <p>$00.0</p>
                        </div>
                        <div style="display: flex; justify-content: space-between;">
                            <p style="font-weight: bold;" class="text-success">TOTAL</p>
                            <p style="font-weight: bold; font-size:18px;" class="text-success">$00.0</p>
                        </div>
                    </div>
                </div>

                <!-- Segundo div -->
                <div class="alert flight-deta12" id="casientosSeleccion" style="color: #262E55; margin-bottom:35%; position: sticky; top: calc(15% + 350px);"> <!-- Ajuste en top -->
                    <b style="color: #861936; font-size:20px;">Asientos seleccionados </b><br>
                    <div class="flight-detaInfoo fade-in" style="margin-top:10%; margin-left:-25%; width:200%;">
                        <div style="display: flex; justify-content: space-between;">
                            <p style="font-weight: bold; font-size:18px;">Salida</p>
                            <p style="font-weight: bold;">&nbsp;&nbsp; CDMX → MTY</p>
                            <p style="font-weight: bold; color: #861936;">8P</p>
                        </div>
                        <div style="display: flex; justify-content: space-between;">
                            <p style="font-weight: bold; font-size:18px;">Regreso</p>
                            <p style="font-weight: bold;">MTY → CDMX</p>
                            <p style="font-weight: bold; color: #861936;">6K</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Footer -->
        <div>
            <footer class="footer fade-in" id="footer-section" style="background-color: #262E55; margin-top:5%;">
                <?php include('layouts/footer.php') ?>
            </footer>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/5.3.2/js/bootstrap.min.js"></script>
    <script src="https://getbootstrap.com/docs/5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>   
    <script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>
    <script src="./assets/js/logo.js"></script>
    <script src="./assets/js/outDetailsFlight.js"></script>
    <script src="./assets/js/outDetailsFM.js"></script>
    <script src="./assets/js/outDetailsFMRegreso.js"></script>
    <script src="./assets/js/outDetailsFlightMobile2.js"></script>
    <script src="./assets/js/outDetailsFliCards.js"></script>
    <script>AOS.init();</script>
    <script>
        AOS.init({
        duration: 1000, // Duración de la animación en milisegundos
        once: true // Si quieres que la animación se ejecute solo una vez
        });
    </script>
    <script>
        function applyMask(input) {
            let value = input.value.replace(/\D/g, ''); // Elimina caracteres que no son números
            if (value.length >= 3) {
                input.value = value.slice(0, 2) + '/' + value.slice(2, 4);
            } else {
                input.value = value;
            }
        }
    </script>
</body>

</html>