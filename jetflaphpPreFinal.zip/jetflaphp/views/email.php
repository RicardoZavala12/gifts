<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <title>Tu reservación está lista</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f5f5f5;
            color: #333;
        }

        .email-container {
            max-width: 600px;
            margin: 20px auto;
            background-color: #ffffff;
            border: 1px solid #ddd;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .header {
            background-color: #262E55;
            color: #fff;
            text-align: center;
            padding: 15px;
        }

        .header img {
            max-width: 120px;
            margin-bottom: 10px;
        }

        .header h1 {
            margin: 0;
            font-size: 20px;
        }

        .content {
            padding: 20px;
        }

        .reservation-code {
            font-size: 18px;
            font-weight: bold;
            color: #262E55;
            margin-bottom: 10px;
        }

        .flight-details-container {
            display: flex;
            gap: 20px;
            align-items: center;
            margin-bottom: 20px;
        }

        .flight-details-container .reservation-code {
            flex: 1;
        }

        .flight-details {
            background-color: #f0f9f4;
            padding: 15px;
            border-radius: 8px;
            flex: 2;
        }

        .flight-details p {
            margin: 5px 0;
            font-size: 14px;
        }

        .flight-details .section-title {
            font-weight: bold;
            margin-bottom: 10px;
        }

        .schedule {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px;
            background-color: #e9ecef;
            border-radius: 8px;
        }

        .schedule div {
            text-align: center;
        }

        .schedule .icon {
            font-size: 18px;
            color: #262E55;
        }

        .contact-details {
            background-color: #262E55;
            color: #fff;
            padding: 15px;
            margin: 20px 0;
            border-radius: 8px;
        }

        .contact-details table {
            width: 100%;
            border-collapse: collapse;
        }

        .contact-details table td {
            padding: 10px;
            font-size: 14px;
        }

        .contact-details table td:first-child {
            text-align: left;
        }

        .contact-details table td:last-child {
            text-align: right;
        }

        .contact-details a {
            color: #FFD700;
            text-decoration: none;
        }

        .footer {
            background-color: #f9f9f9;
            text-align: center;
            padding: 10px;
            font-size: 12px;
            color: #777;
        }

        .footer a {
            color: #262E55;
            text-decoration: none;
        }
    </style>
</head>

<body>
    <div class="email-container">
        <div class="header">
            <img src="./assets/img/jetflaLogo.png" alt="JETFLA Logo">
            <h1>¡Tu reservación está lista!</h1>
        </div>
        <?php foreach ($dataVuelosSalida as $vuelo): ?>
            <div class="content">
                <p>¡Hola <strong>Nombre_pasajero_completo</strong>!</p>
                <p>Ya estás list@ para volar. Revisa los detalles de tu reservación y prepárate para vivir la mejor experiencia de viaje en <strong>destino</strong>.</p>
                <div class="flight-details-container">
                    <div class="reservation-code">
                        <p style="font-size: 12px;">Código de reservación</p>
                        <strong>cod_res</strong>
                    </div>
                    <div class="flight-details" style="text-align: center;">
                        <p class="section-title">Vuelo</p>
                        <b><p style="font-size: 18px;">2<?php echo $vuelo['codigo_vuelo']; ?></p></b>
                        <p><?php echo $vuelo['fecha_salida_detail']; ?></p>
                    </div>
                </div>
                <div class="schedule">
                    <div>
                        <p><strong><?php echo $vuelo['hora_salida']; ?></strong></p>
                        <p><?php echo $vuelo['origen']; ?></p>
                    </div>
                    <div class="flight-icon">
                        <span class="line"></span>
                        <i class="fa fa-plane"></i>
                        <span class="line"></span>
                    </div>
                    <div>
                        <p><strong><?php echo $vuelo['hora_llegada']; ?></strong></p>
                        <p><?php echo $vuelo['destino']; ?></p>
                    </div>
                </div>
                <div class="contact-details">
                    <table>
                        <tr>
                            <td>Correo electrónico</td>
                            <td>Teléfono</td>
                        </tr>
                        <tr>
                            <td><a href="mailto:gaby_081280@hotmail.com">emai@email.com</a></td>
                            <td>+num_contacto</td>
                        </tr>
                    </table>
                </div>
            </div>
        <?php endforeach; ?>
        <div class="footer">
            <p>¿Tienes dudas? <a href="#">Visita nuestro sitio web</a> para más información.</p>
            <p>&copy; 2024 JETFLA</p>
        </div>
    </div>
</body>

</html>