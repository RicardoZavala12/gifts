<?php
//include_once("./views/session/session_check.php");
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>JETFLA | Seleccionar Asientos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/5.3.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://getbootstrap.com/docs/5.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@docsearch/css@3">
    <link href="./assets/css/outFlights.css" rel="stylesheet">
    <link href="./assets/css/seat.css" rel="stylesheet">
    <link href="navbar.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.css" rel="stylesheet">
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
        }

        .content {
            padding: 20px;
        }
    </style>
</head>

<body>
    <div class="grid-container">
        <!-- Navbar -->
        <?php include('layouts/navbar.php') ?>
        <br><br><br><br><br>

        <!-- Main Content -->
        <div class="content-grid">
            <!-- Left Side -->
            <div class="left">
                <div class="left-text">
                    <div class="fade-in d-none d-md-block" id="salida-desktop" style="background-color: #ffffff; height: 240px; margin-left:10%;" data-aos="fade-up">
                        <div class="responsive-text">
                            <span class="fw-bold fs-8" style="color: #861936; font-size:30px;">Vuelos seleccionados <?php echo htmlspecialchars($tipo); ?></span>
                        </div>

                    </div>

                    <!-- MOBILE VERSION -->
                    <div class="fade-in d-block d-md-none" id="salida-mobile" style="background-color: #ffffff; padding: 0px; margin-top:-10%; margin-bottom:12%;" data-aos="fade-up">
                        <div class="responsive-text"><br><br><br>
                            <span class="fw-bold fs-8" style="color: #861936; font-size:28px;">Vuelos seleccionados</span>
                        </div><br>
                        <div class="responsive-text mt-2">
                        </div>
                    </div><br><br>
                </div>
                <div class="card-container" style="margin-left:-12%; margin-top:-40%;">

                    <div class="content fade-in " style="margin-top: 5%;" data-aos="fade-up">
                        <div class="flight-info" id="flight-infoCard" style="box-shadow: 0px 5px 10px rgba(0, 0, 0, 0.5);">
                            <div class="flight-details">
                                <div class="price-details">
                                    <span class="price">Salida</span><br><br>
                                </div>
                                <div style="margin-left: 0;">
                                    <?php foreach ($dataVuelosSalida as $vuelo): ?>
                                        <p style="margin: 0; padding: 0; display:flex;"><b><?php echo $vuelo['fecha_salida_detail']; ?></b></p>
                                        <p style="margin: 0; padding: 0; display:flex;">Vuelo&nbsp;<b><?php echo $vuelo['codigo_vuelo']; ?></b></p>
                                        <p style="margin: 0; padding: 0; display:flex; flex-wrap: nowrap; gap: 5px;"><b><?php echo $vuelo['hora_salida']; ?></b>&nbsp;<?php echo $vuelo['origen']; ?></p>
                                </div>
                            </div>
                            <div class="flight-schedule" style="margin-top: -15px;">
                                <div class="flight-time">
                                    <span class="time"><?php echo $vuelo['hora_salida']; ?></span><br>
                                    <span class="airport-code"><?php echo $vuelo['origen']; ?></span>
                                </div>
                                <div class="flight-icon">
                                    <span class="line"></span>
                                    <i class="fa fa-plane"></i>
                                    <span class="line"></span>
                                </div>
                                <div class="flight-time">
                                    <span class="time"><?php echo $vuelo['hora_llegada']; ?></span><br>
                                    <span class="airport-code"><?php echo $vuelo['destino']; ?></span>
                                </div>
                            </div>

                            <div class="layover" style="margin-left:30%;"><?php echo $vuelo['duracion']; ?></div>
                        </div>

                        <div id="details-content" class="details-card d-none d-md-flex" style="box-shadow: 0px 5px 10px rgba(0, 0, 0, 0.5); display: flex; margin-left: 13%; max-height: 690px; width: 700%;">
                            <div class="card-content">
                                <p><label for="details_flight" style="font-size: 14.2px; font-weight: bold; color: #262E55;">Detalles del vuelo</label></p>
                                <ul>
                                    <li>Equipaje <b>20 KG</b> </li>
                                    <li>Comida incluida</li>
                                    <li>WiFi disponible</li>
                                </ul>
                            </div>
                            <div class="flight-card" style="margin-left: 15% ;width: 60%; text-align: center;">
                                <p class="card-title"><strong><?php echo $vuelo['tipo']; ?></strong></p>
                                <div style="font-size: 30px; font-weight: bold; color: #262E55;">$
                                    <?php echo $vuelo['costo']; ?>
                                    <span style="font-size: 0.6em; color: #262E55;">MXN</span>
                                </div>
                            </div>
                        </div>


                        <div id="details-content" class="details-card d-flex d-md-none" style="box-shadow: 0px 5px 10px rgba(0, 0, 0, 0.5); display: flex; margin-left: 6%; max-height: 694px; width: 700%;">
                            <div class="card-content">
                                <p><label for="details_flight" style="font-size: 15px; font-weight: bold; color: #262E55;">Detallsses del vuelo</label></p>
                                <ul>
                                    <li>Equipaje <b>20 KG</b> </li>
                                    <li>Comida incluida</li>
                                    <li>WiFi disponible</li>
                                </ul>
                            </div>
                            <div class="flight-card">
                                <p class="card-title"><strong><?php echo $vuelo['tipo']; ?></strong></p>
                                <div style="font-size: 30px; font-weight: bold; color: #262E55;">$
                                    <?php echo $vuelo['costo']; ?>
                                    <span style="font-size: 0.6em; color: #262E55;">MXN</span>
                                </div>
                            <?php endforeach; ?>
                            </div>
                        </div>
                    </div>


                </div><br><br><br>
                <div class="left-text">
                    <div class="fade-in d-none d-md-block" id="salida-desktop" style="background-color: #ffffff; height: 240px; margin-left:10%;">
                        <div class="responsive-text">
                            <h2 style="margin-bottom: 40px; text-decoration: none; margin-left:-9%;" class="txtTitles" data-aos="fade-up">Extras</h2>
                        </div>
                    </div>
                    <!-- MOBILE VERSION -->
                    <div class="fade-in d-block d-md-none" id="salida-mobile" style="background-color: #ffffff; padding: 0px;">
                        <h2 style="margin-bottom: 40px;  text-decoration: none;" class="txtTitles" data-aos="fade-up">Extras</h2>
                    </div><br>
                </div><br><br><br><br>







                <!-- Extras -->
                <div class="card-container" style="margin-left:-12%; margin-top:-39%;" data-aos="fade-up">

                    <?php
                    // Divide el array de extras en dos partes
                    $totalExtras = count($extras);
                    $mitad = ceil($totalExtras / 2);
                    $extrasIzquierda = array_slice($extras, 0, $mitad);
                    $extrasDerecha = array_slice($extras, $mitad);
                    ?>
                    <style>
                        /* Ajuste para la versión móvil */
                        @media (max-width: 768px) {
                            .extras-containerr {
                                flex-direction: column;
                                align-items: flex-start;
                            }

                            .extras-column {
                                align-items: flex-start;
                                margin-left: 0;
                            }

                            .extra-itemm {
                                font-size: 14px;
                                /* Tamaño de fuente más pequeño para móviles */
                                display: flex;
                                align-items: center;
                                gap: 20px;
                                /* Alinear checkbox y texto en la misma línea */
                            }
                        }

                        /* Estilo para pantallas grandes */
                        .extras-containerr {
                            display: flex;
                            margin-left: 10%;
                        }

                        .extras-column {
                            flex: 1;
                            display: flex;
                            flex-direction: column;
                            margin-left: 5%;
                        }

                        .extra-itemm {
                            display: flex;
                            align-items: center;
                            font-size: 16px;
                            /* Tamaño de fuente normal */
                        }
                    </style>
                    <div class="extras-containerr">
                        <!-- Columna Izquierda -->
                        <div class="extras-column">
                            <?php foreach ($extrasIzquierda as $index => $extra): ?>
                                <div class="extra-itemm">
                                    <input
                                        type="checkbox"
                                        id="leftOption<?php echo $index + 1; ?>"
                                        data-description="<?php echo $extra['descripcion']; ?>"
                                        data-cost="<?php echo $extra['costo']; ?>"
                                        onclick="updateSelectedExtras(); updateSelectedExtrasMobile();">
                                    <label for="leftOption<?php echo $index + 1; ?>">&nbsp;<?php echo $extra['descripcion']; ?> <strong>($<?php echo $extra['costo']; ?>)</strong></label>
                                </div>
                            <?php endforeach; ?>
                        </div>

                        <!-- Columna Derecha -->
                        <div class="extras-column">
                            <?php foreach ($extrasDerecha as $index => $extra): ?>
                                <div class="extra-itemm">
                                    <input
                                        type="checkbox"
                                        id="rightOption<?php echo $index + 1 + $mitad; ?>"
                                        data-description="<?php echo $extra['descripcion']; ?>"
                                        data-cost="<?php echo $extra['costo']; ?>"
                                        onclick="updateSelectedExtras(); updateSelectedExtrasMobile();">
                                    <label for="rightOption<?php echo $index + 1 + $mitad; ?>">&nbsp;<?php echo $extra['descripcion']; ?> <strong>($<?php echo $extra['costo']; ?>)</label>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <style>
                        .extras-container {
                            display: flex;
                            flex-direction: column;
                            padding: 10px;
                        }

                        .extras-header {
                            font-weight: bold;
                            margin-bottom: 10px;
                        }

                        .extra-item {
                            display: flex;
                            justify-content: space-between;
                            margin-bottom: 5px;
                        }

                        .total-cost {
                            display: flex;
                            justify-content: space-between;
                            margin-top: 10px;
                            padding-top: 10px;
                            border-top: 1px solid #000;
                        }

                        /* Mobile Responsive */
                        @media screen and (max-width: 600px) {
                            .extra-item {
                                flex-direction: column;
                            }

                            .extra-item span {
                                margin-bottom: 5px;
                            }

                            .total-cost {
                                flex-direction: column;
                            }

                            .total-cost strong {
                                margin-bottom: 5px;
                            }

                            .cost {
                                text-align: right;
                            }
                        }
                    </style>

                    <script>
                        function updateSelectedExtras() {
                            const selectedExtrasContainer = document.getElementById('selectedExtrasContainer');

                            selectedExtrasContainer.innerHTML = `
                                <div class="extras-header">Extras</div>
                            `;

                            const extrasList = document.createElement('ul');
                            extrasList.style.listStyleType = 'none';
                            extrasList.style.padding = '0';
                            extrasList.style.margin = '0';

                            const checkboxes = document.querySelectorAll('.extra-itemm input[type="checkbox"]');
                            let totalCost = 0;

                            checkboxes.forEach((checkbox) => {
                                if (checkbox.checked) {
                                    const description = checkbox.getAttribute('data-description');
                                    const cost = parseFloat(checkbox.getAttribute('data-cost'));

                                    const extraItem = document.createElement('li');
                                    extraItem.className = 'extra-item';
                                    extraItem.innerHTML = `<span>${description}</span><span>$${cost.toFixed(2)}</span>`;

                                    extrasList.appendChild(extraItem);

                                    totalCost += cost;
                                }
                            });

                            selectedExtrasContainer.appendChild(extrasList);

                            const totalDiv = document.createElement('div');
                            totalDiv.className = 'total-cost';
                            totalDiv.innerHTML = `<strong>Total</strong><strong style="margin-left: auto;">$${totalCost.toFixed(2)}</strong>`;

                            selectedExtrasContainer.appendChild(totalDiv);
                        }
                    </script>

                    














                    <!--- DESKTOP --->
                    <div class="fade-in d-none d-md-block" id="salida-desktop" style="background-color: #ffffff; height: 240px; margin-left:10%; margin-top:10%;">
                        <div class="responsive-text">
                            <h2 style="text-decoration: none; margin-left:2.8%;" class="txtTitles" data-aos="fade-up">Selección de asientos</h2>
                        </div>
                    </div>

                    <!--- MOBILE  --->
                    <div class="fade-in d-block d-md-none" id="salida-desktop" style="background-color: #ffffff; height: 240px; margin-left:10%; margin-top:10%; margin-bottom:-12%;">
                        <div class="responsive-text">
                            <h2 style="text-decoration: none; margin-left:2.8%;" class="txtTitles" data-aos="fade-up">Selección de asientos</h2>
                        </div>
                    </div>



                    <div class="content fade-in " style="margin-top: -25%;">

                        <div class="flight-info" id="flight-infoCard" style="background-color:#ffffff;">

                            <div class="container" style="width: 100%; display: flex; justify-content: center; align-items: flex-start; flex-direction: column; margin-top: 0px;">

                                <!-- Contenedor superior que contiene los botones y leyenda -->
                                <div style="display: flex; justify-content: space-between; width: 100%;" data-aos="fade-up">

                                    <!-- Columna izquierda con botones Salida y Regreso -->



                                    <div class="switch-container">
                                        <input type="radio" name="switch" id="salida" checked>
                                        <input type="radio" name="switch" id="regreso">

                                        <div class="switch" style="background-color: #861936;">
                                            <label for="salida" class="switch-label salida d-none d-md-block">Salida</label>

                                            <!--- MOBILE --->
                                            <label for="salida" class="switch-label salida d-block d-md-none">Salida</label>


                                            <div class="switch-toggle"></div>
                                        </div>
                                    </div>





                                    <!-- Leyenda de los asientos -->
                                    <div class="d-none d-md-block" style="padding: 10px; width: 45%; margin-left: 12px; margin-top:3%;">
                                        <div style="display: flex; align-items: center; margin-bottom: 10px;">
                                            <div style="width: 20px; height: 20px; background-color: green; border-radius: 50%; margin-right: 10px;"></div>
                                            <p style="margin: 0;">Libre</p>
                                        </div>
                                        <div style="display: flex; align-items: center; margin-bottom: 10px;">
                                            <div style="width: 20px; height: 20px; background-color: gray; border-radius: 50%; margin-right: 10px;"></div>
                                            <p style="margin: 0;">Ocupado</p>
                                        </div>
                                        <div style="display: flex; align-items: center;">
                                            <div style="width: 20px; height: 20px; background-color: yellow; border-radius: 50%; margin-right: 10px;"></div>
                                            <p style="margin: 0;">Seleccionado</p>
                                        </div>
                                    </div>


                                    <!-- MOBILE Leyenda de los asientos -->
                                    <br>
                                    <div class="d-block d-md-none" style="padding: 10px; width: 45%; margin-left: 12px; margin-top:4%;">
                                        <div style="display: flex; align-items: center; margin-bottom: 10px;">
                                            <div style="width: 20px; height: 20px; background-color: green; border-radius: 50%; margin-right: 10px;"></div>
                                            <p style="margin: 0;">Libre</p>
                                        </div>
                                        <div style="display: flex; align-items: center; margin-bottom: 10px;">
                                            <div style="width: 20px; height: 20px; background-color: gray; border-radius: 50%; margin-right: 10px;"></div>
                                            <p style="margin: 0;">Ocupado</p>
                                        </div>
                                        <div style="display: flex; align-items: center;">
                                            <div style="width: 20px; height: 20px; background-color: yellow; border-radius: 50%; margin-right: 10px;"></div>
                                            <p style="margin: 0;">Seleccionado</p>
                                        </div>
                                    </div>

                                </div>

                                <!-- Diagrama de aviones en la parte inferior y centrado -->
                                <div style="display: flex; justify-content: center; align-items: center; margin-top: 20px; margin-bottom: 15%; width: 100%; ">
                                    <div style="border: 1px solid #ccc; border-radius: 80px 80px 10px 10px; padding: 20px; text-align: center;  margin-top: 5%;" data-aos="fade-up">
                                        <strong>CABINA</strong> <br>
                                        <div class="seat-container" style="align-items: center; margin-top: 5%;   ">
                                            <!-- Asientos (Ejemplo: 12 asientos) -->
                                            <div class="seat" data-seat="1A">1A</div>
                                            <div class="seat occupied" data-seat="1B">1B</div>
                                            <div class="space"></div>
                                            <div class="seat occupied" data-seat="1D">2C</div>
                                            <div class="seat" data-seat="2A">2D</div>
                                            <div class="seat" data-seat="2B">3E</div>
                                            <div class="seat" data-seat="2C">3F</div>
                                            <div class="space"></div>
                                            <div class="seat" data-seat="3A">4G</div>
                                            <div class="seat occupied" data-seat="3B">4H</div>
                                            <div class="seat" data-seat="3C">5I</div>
                                            <div class="seat" data-seat="3D">5J</div>
                                            <div class="space"></div>
                                            <div class="seat" data-seat="3C">6K</div>
                                            <div class="seat" data-seat="3D">6L</div>
                                            <div class="seat" data-seat="3C">7M</div>
                                            <div class="seat" data-seat="3D">7N</div>
                                            <div class="space"></div>
                                            <div class="seat" data-seat="3C">8O</div>
                                            <div class="seat" data-seat="3D">8P</div>
                                        </div>
                                    </div>

                                    <script>
                                        const seats = document.querySelectorAll(' .seat:not(.occupied)'); // Asientos que no están ocupados

                                        seats.forEach(seat => {
                                            seat.addEventListener('click', () => {
                                                seat.classList.toggle('selected'); // Alternar entre seleccionado y no seleccionado
                                            });
                                        });
                                    </script>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Mobile: Another div below (before footer) -->
                <div class="alert d-block d-md-none fade-in" data-aos="fade-up">


                    <div class="alert flight-deta12" id="casientosSeleccion" style="color: #262E55; margin-bottom:40%;"> <!-- Ajuste en top -->
                        <b style="color: #861936; font-size:20px;">Asientos seleccionados </b><br>
                        <div class="flight-detaInfoo fade-in" style="margin-top:14%; margin-left:-25%; width:100%;">
                            <div style="display: flex; justify-content: space-between;">
                                <p style="font-weight: bold; font-size:18px;">Salida</p>
                                <p style="font-weight: bold;">&nbsp;&nbsp; CDMX → MTY</p>
                                <p style="font-weight: bold; color: #861936;">8P</p>
                            </div>
                            <div style="display: flex; justify-content: space-between;">
                                <p style="font-weight: bold; font-size:18px;">Regreso</p>
                                <p style="font-weight: bold;">MTY → CDMX</p>
                                <p style="font-weight: bold; color: #861936;">6K</p>
                            </div>
                        </div>
                    </div>



                    <div class="alert flight-deta12" id="costosDetails" style="color: #262E55; margin-bottom:70%; margin-top:15%;">
                        <b style="color: #861936;">Reservación</b>
                        <div class="flight-detaInfoo fade-in" style="margin-top:12%; margin-left:-25%; width:100%;">
                            <?php foreach ($dataVuelosSalida as $vuelo): ?>
                                <p style="font-weight: bold;">Pasajeros</p>
                                <p><?php echo $vuelo['descripcion_pasajeros']; ?></p>

                                <p style="font-weight: bold;">Fecha de salida</p>
                                <p><?php echo $vuelo['fecha_salida_detail']; ?></p>
                                <p style="font-weight: bold;">Fecha de regreso</p>
                                <p><?php echo $vuelo['fecha_regreso_detail']; ?></p>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <div class="alert flight-deta12" id="costosDetails" style="color: #262E55; margin-bottom:190%; position: sticky; top: 55%;">
                        <b style="color: #861936;">Costos de vuelos</b>
                        <div class="flight-detaInfoo fade-in" style="margin-top:12%; margin-left:-25%; width:100%;">
                            <?php foreach ($dataVuelosSalida as $vuelo): ?>
                                <div style="display: flex; justify-content: space-between;">
                                    <p style="font-weight: bold;">Vuelo | Salida</p>
                                    <?php if ($vuelo['tipo'] === 'Escala'): ?>
                                        <b>
                                            <p>$<?php echo $vuelo['costo_escala_sin_iva_tua']; ?></p>
                                        </b>
                                    <?php else: ?>
                                        <b>
                                            <p>$<?php echo $vuelo['costo_directo_sin_iva_tua']; ?></p>
                                        </b>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; ?>

                            <div style="display: flex; justify-content: space-between;">
                                <?php foreach ($dataVuelosSalida as $vuelo): ?>
                                    <p style="font-weight: bold;">TUA
                                        <span style="font-size: 17px; cursor: pointer;" title="El TUA es el impuesto de uso aeroportuario.">
                                            <i class="fa-solid fa-circle-question"></i>
                                        </span>
                                    </p>
                                    <p>$<?php echo $vuelo['tua']; ?></p>
                            </div>

                            <div style="display: flex; justify-content: space-between;">
                                <p style="font-weight: bold;">IVA</p>
                                <p>$<?php echo $vuelo['iva']; ?></p>
                            </div>

                            <div style="display: flex; justify-content: space-between; color: green;">
                                <?php if ($vuelo['porcentaje_desc'] !== ''): ?>
                                    <p style="font-weight: bold;">Descuento</p>
                                    <p>-<?php echo $vuelo['porcentaje_desc']; ?>%</p>
                                <?php else: ?>
                                    <p></p>
                                <?php endif; ?>
                            </div>

                           
                        <?php endforeach; ?>

                        <div style="display: flex; justify-content: space-between;" id="selectedExtrasContainerMobile" class="extras-container">

                        </div>




                        </div>
                    </div>

                    <div class="flight-cost-container" style=" margin-bottom:-1%; position: sticky; top:calc(45% + 550px);">
                        <div class="alert flight-deta12" id="costosDetails" style="color: #262E55; ">
                            <b style="color: #861936; font-size:25px;" class="text-success">Total</b>
                            <b style="color: #861936; font-size:25px;" class="text-success">$&nbsp;3,731 MXN </b>
                        </div>
                        <!--<div class="alert flight-deta12" id="costosDetails" style="color: green;  margin-bottom:-2.5%; top:-9%; display: flex; justify-content: center; align-items: center; background-color:#31BC36;">
                        <b style="color: #861936; font-size:17px; text-align:center;" class="text-light">PRECIO FINAL</b>
                    </div>--->
                        <button type="submit" class="btn-s btn-submit" style="border-radius: 20px; width:80%; margin-left:12%; display: flex; justify-content: center;">Adquirir vuelo</button>
                    </div>
                </div>
            </div>

            <!-- Right Side (Visible only on desktop) -->
            <div class="right-side fade-in">


                <div class="alert flight-deta12" id="costosDetails" style="color: #262E55; margin-bottom:7%; margin-top:15%;">
                    <b style="color: #861936;">Reservación</b>
                    <div class="flight-detaInfoo fade-in" style="margin-top:8%; margin-left:-25%; width:120%;">
                        <?php foreach ($dataVuelosSalida as $vuelo): ?>
                            <p style="font-weight: bold;">Pasajeros</p>
                            <p><?php echo $vuelo['descripcion_pasajeros']; ?></p>

                            <p style="font-weight: bold;">Fecha de salida</p>
                            <p><?php echo $vuelo['fecha_salida_detail']; ?></p>
                            <p style="font-weight: bold;">Fecha de regreso</p>
                            <p><?php echo $vuelo['fecha_regreso_detail']; ?></p>
                        <?php endforeach; ?>
                    </div>
                </div><br><br><br><br><br><br><br><br><br>


                <!-- Primer div -->
                <div class="alert flight-deta12" id="costosDetails" style="color: #262E55; margin-bottom:110%; position: sticky; top: 15%;"> <b style="color: #861936;">Costos de vuelos</b>
                    <div class="flight-detaInfoo fade-in" style="margin-top:8%; margin-left:-25%; width:120%;">
                        <?php foreach ($dataVuelosSalida as $vuelo): ?>
                            <div style="display: flex; justify-content: space-between;">
                                <p style="font-weight: bold;">Vuelo | Salida</p>
                                <?php if ($vuelo['tipo'] === 'Escala'): ?>
                                    <b>
                                        <p>$<?php echo $vuelo['costo_escala_sin_iva_tua']; ?></p>
                                    </b>
                                <?php else: ?>
                                    <b>
                                        <p>$<?php echo $vuelo['costo_directo_sin_iva_tua']; ?></p>
                                    </b>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>

                        <div style="display: flex; justify-content: space-between;">
                            <?php foreach ($dataVuelosSalida as $vuelo): ?>
                                <p style="font-weight: bold;">TUA
                                    <span style="font-size: 17px; cursor: pointer;" title="El TUA es el impuesto de uso aeroportuario.">
                                        <i class="fa-solid fa-circle-question"></i>
                                    </span>
                                </p>
                                <p>$<?php echo $vuelo['tua']; ?></p>
                        </div>

                        <div style="display: flex; justify-content: space-between;">
                            <p style="font-weight: bold;">IVA</p>
                            <p>$<?php echo $vuelo['iva']; ?></p>
                        </div>

                        <div style="display: flex; justify-content: space-between; color: green;">
                            <?php if ($vuelo['porcentaje_desc'] !== ''): ?>
                                <p style="font-weight: bold;">Descuento</p>
                                <p>-<?php echo $vuelo['porcentaje_desc']; ?>%</p>
                            <?php else: ?>
                                <p></p>
                            <?php endif; ?>
                        </div>

                    <?php endforeach; ?>

                    <div style="display: flex; justify-content: space-between;" id="selectedExtrasContainer" class="extras-container">

                    </div>


                    <!---<div style="display: flex; justify-content: space-between;">
                            <p style="font-weight: bold;" class="text-success">TOTAL</p>
                            <p style="font-weight: bold; font-size:18px;" class="text-success">$00.0</p>
                        </div>--->

                    </div>
                </div>



                <!-- Segundo div -->
                <div class="alert flight-deta12" id="casientosSeleccion" style="color: #262E55; margin-bottom:40%; position: sticky; top: calc(25% + 350px);"> <!-- Ajuste en top -->
                    <b style="color: #861936; font-size:20px;">Asientos seleccionados </b><br>
                    <div class="flight-detaInfoo fade-in" style="margin-top:10%; margin-left:-25%; width:200%;">
                        <div style="display: flex; justify-content: space-between;">
                            <p style="font-weight: bold; font-size:18px;">Salida</p>
                            <p style="font-weight: bold;">&nbsp;&nbsp; CDMX → MTY</p>
                            <p style="font-weight: bold; color: #861936;">8P</p>
                        </div>
                        <div style="display: flex; justify-content: space-between;">
                            <p style="font-weight: bold; font-size:18px;">Regreso</p>
                            <p style="font-weight: bold;">MTY → CDMX</p>
                            <p style="font-weight: bold; color: #861936;">6K</p>
                        </div>
                    </div>
                </div>



                <!-- Tercer div -->
                <div class="flight-cost-container" style=" margin-bottom:-1%; position: sticky; top:calc(45% + 550px);">
                    <div class="alert flight-deta12" id="costosDetails" style="color: #262E55; ">
                        <b style="color: #861936; font-size:25px;" class="text-success">Total</b>
                        <b style="color: #861936; font-size:25px;" class="text-success">$&nbsp;3,731 MXN </b>
                    </div>
                    <!--<div class="alert flight-deta12" id="costosDetails" style="color: green;  margin-bottom:-2.5%; top:-9%; display: flex; justify-content: center; align-items: center; background-color:#31BC36;">
                        <b style="color: #861936; font-size:17px; text-align:center;" class="text-light">PRECIO FINAL</b>
                    </div>--->
                    <button type="submit" class="btn-s btn-submit" style="border-radius: 20px; width:80%; margin-left:12%; display: flex; justify-content: center;">Adquirir vuelo</button>
                </div>

            </div>
        </div>
        <!-- Footer -->
        <div>
            <footer class="footer fade-in" id="footer-section" style="background-color: #262E55; margin-top:5%;">
                <?php include('layouts/footer.php') ?>
            </footer>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/5.3.2/js/bootstrap.min.js"></script>
    <script src="https://getbootstrap.com/docs/5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>
    <script src="./assets/js/logo.js"></script>
    <script src="./assets/js/outDetailsFlight.js"></script>
    <script src="./assets/js/outDetailsFM.js"></script>
    <script src="./assets/js/outDetailsFMRegreso.js"></script>
    <script src="./assets/js/outDetailsFlightMobile2.js"></script>
    <script src="./assets/js/outDetailsFliCards.js"></script>
    <script>
        AOS.init();
    </script>
    <script>
        AOS.init({
            duration: 1000, // Duración de la animación en milisegundos
            once: true // Si quieres que la animación se ejecute solo una vez
        });
    </script>
</body>

</html>