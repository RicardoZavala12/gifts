<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Boleto de Avión</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            background-color: #f4f4f4;
        }
        .ticket {
            width: 350px;
            background-color: #43a047; /* Color similar al de la tarjeta */
            color: #fff;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            position: relative;
        }
        .ticket h1 {
            font-size: 20px;
            margin: 0 0 10px;
        }
        .ticket .header, .ticket .footer {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .ticket .details {
            margin: 20px 0;
        }
        .ticket .details div {
            margin-bottom: 10px;
        }
        .ticket .qr-code {
            width: 100%;
            text-align: center;
            margin: 20px 0;
        }
        .ticket .zone {
            background-color: #2e7d32;
            padding: 5px 10px;
            border-radius: 5px;
            text-align: center;
            font-weight: bold;
            font-size: 14px;
        }
    </style>
</head>
<body>
    <div class="ticket">
        <div class="header">
            <h1>Viva</h1>
            <span>num vuelo</span>
        </div>
        <p>Fecha</p>
        <h2>nombre_pasajero</h2>
        <div class="details">
            <div><strong>Ciudad de salida:</strong>ciudad_salida</div>
            <div><strong>Destino:</strong> ciudad_destino; ?>, terminal; ?></div>
            <div><strong>Abordaje:</strong> hora_abordaje; ?></div>
            <div><strong>Salida:</strong> hora_salida; ?></div>
            <div><strong>Puerta:</strong> puerta ?? 'No disponible'; ?></div>
        </div>
        <div class="qr-code">
            <!-- Aquí irá el QR generado dinámicamente con PHP -->
             qr_code; ?>
        </div>
        <div class="footer">
            <div>
                <strong>Asiento:</strong>asiento; ?> (tipo_asiento; ?>)
            </div>
            <div class="zone">
                Zona zona; ?>
            </div>
        </div>
        <p>Reserva: codigo_reserva; ?></p>
    </div>
</body>
</html>
