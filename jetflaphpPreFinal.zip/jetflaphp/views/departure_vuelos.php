<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>JETFLA | Seleccionar Salida</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="./assets/css/outFlights.css" rel="stylesheet">
    <link href="https://getbootstrap.com/docs/5.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@docsearch/css@3">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.css" rel="stylesheet">
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
        }

        .content {
            padding: 20px;
        }
    </style>
</head>

<body>

    <div class="grid-container">
        <?php include('layouts/navbar.php') ?><br><br><br><br>

        <!-- Main Content -->
        <div class="content-grid">
            <!-- Left Side -->
            <div class="left">
                <div class="left-text">
                    <div class="fade-in d-none d-md-block" id="salida-desktop" style="background-color: #ffffff; height: 240px; margin-left:10%;" data-aos="fade-up">
                        <div class="responsive-text">
                            <span class="fw-bold fs-5" style="color: #861936;">Elije tu vuelo de salida</span>
                            <?php foreach ($vuelosFiltrados as $vuelo): ?>
                                <span class="fw-light fs-5" style="margin-left: 0%; color: #861936;">&nbsp;<?php echo $vuelo['origen']; ?> → <?php echo $vuelo['destino']; ?></span>
                            <?php endforeach; ?>
                        </div>
                        <div class="responsive-text" style="margin-top: 0%;">
                            <?php foreach ($vuelosFiltrados as $vuelo): ?>
                                <span class="fw-light fs-6" style="color:#262E55;"><?php echo $vuelo['origen_full']; ?> a <?php echo $vuelo['destino_full']; ?> | <?php echo $vuelo['fecha_salida_detail']; ?></span>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <!-- MOBILE VERSION -->
                    <div class="fade-in d-block d-md-none" id="salida-mobile" style="background-color: #ffffff; padding: 0px;" data-aos="fade-up">
                        <div class="responsive-text">
                            <span class="fw-bold fs-6" style="color: #861936;">Elije tu vuelo de salida</span>
                            <?php foreach ($vuelosFiltrados as $vuelo): ?>
                                <span class="fw-light fs-6" style="margin-left: 10px; color: #861936;"><?php echo $vuelo['origen']; ?> → <?php echo $vuelo['destino']; ?></span>
                            <?php endforeach; ?>
                        </div>
                        <div class="responsive-text mt-2">
                            <?php foreach ($vuelosFiltrados as $vuelo): ?>
                                <span class="fw-light fs-6" style="color: #262E55;"><?php echo $vuelo['origen_full']; ?> a <br><?php echo $vuelo['destino_full']; ?> | <?php echo $vuelo['fecha_salida_detail']; ?></span>
                            <?php endforeach; ?>
                        </div>
                    </div><br>
                </div>

                <!-- Mobile: Toggleable div and button for mobile layout -->
                <div class="toggle-and-button d-block d-md-none fade-in" data-aos="fade-up">
                    <div class="alert flight-deta12Mobile" onclick="toggleFlightDetailsMobile()" style="color: #262E55;">
                        <strong>Detalles de reservación</strong>
                        <i class="arrow down" id="arrow-iconDetaM" style="margin-top:9px;"></i>
                    </div>

                    <div class="col-3 mb-4 flight-detaInfooMobile fade-in" id="flight-detaInfooMobile" style="margin-top:-3%; display: none; transition: max-height 0.5s ease-in-out; width:90%;">
                        <p style="font-weight: bold;">Pasajeros</p>
                        <?php foreach ($vuelosFiltrados as $vuelo): ?>
                            <p><?php echo $vuelo['descripcion_pasajeros']; ?></p>
                        <?php endforeach; ?>
                        <p style="font-weight: bold;">Origen</p>
                        <?php foreach ($vuelosFiltrados as $vuelo): ?>
                            <p><?php echo $vuelo['origen_full']; ?></p>
                        <?php endforeach; ?>
                        <p style="font-weight: bold;">Destino</p>
                        <?php foreach ($vuelosFiltrados as $vuelo): ?>
                            <p><?php echo $vuelo['destino_full']; ?></p>
                        <?php endforeach; ?>
                        <p style="font-weight: bold;">Fecha de salida</p>
                        <?php foreach ($vuelosFiltrados as $vuelo): ?>
                            <p><?php echo $vuelo['fecha_salida_detail']; ?></p>
                        <?php endforeach; ?>
                    </div>
                    <button type="submit" class="btn-s btn-submit" id="botonMobilee" style="border-radius: 20px; padding: 8px 30px;">Modificar vuelo</button><br><br><br><br><br><br>
                </div>

                <!-- Cards -->
                <div class="card-container" style="margin-left:-12%; margin-top:-34%;">
                    <?php

                    foreach ($vuelosFiltrados as $index => $flight) {
                        $detailsId = 'details-content-' . $index;
                        $detailsIcon = 'arrow-icon-' . $index;
                        echo '
        <div class="content fade-in " style="margin-top: 5%;" data-aos="fade-up">
            <div class="flight-info" id="flight-infoCard">
                <div class="flight-schedule" style="margin-top: -15px;">
                    <div class="flight-time">
                        <span class="time">' . $flight['hora_salida_format'] . '</span><br>
                        <span class="airport-code">' . $flight['origen'] . '</span>
                    </div>
                    <div class="flight-icon">
                        <span class="line"></span>
                        <i class="fa fa-plane" ></i>
                        <span class="line"></span>
                    </div>
                    <div class="flight-time">
                        <span class="time">' . $flight['hora_llegada_format'] . '</span><br>
                        <span class="airport-code">' . $flight['destino'] . '</span>
                    </div>
                </div>
                <div class="flight-details">
                    <div class="price-details">
                        <span class="price">$' . $flight['costo_directo'] . '
                            <span style="font-size: 0.6em; color: #262E55;">MXN</span>
                        </span>
                    </div>
                    <br>
                    <a href="javascript:void(0)" class="details-link" onclick="dinamicaDetails(\'' . $detailsId . '\', \'' . $detailsIcon . '\')" style="align-items: center;">
                        <span class="details-text"><label for="details" class="text-black">Detalles</label></span>
                        <i class="arrow down" id="' . $detailsIcon . '"></i>
                    </a>
                </div>
                <div class="layover">' . $flight['duracion'] . '</div>
            </div>

            <div id="' . $detailsId . '" class="details-card" style="margin-left: 0; display: none; margin-left: 12%;">
                <div class="card-content">
                    <p><label for="details_flight" style="font-size: 14.2px; font-weight: bold; color: #262E55;">Detalles del vuelo</label></p>
                    <ul>
                        <li>Equipaje <b> 20 KG</b> </li>
                        <li>Comida incluida</li>
                        <li>WiFi disponible</li>
                    </ul>
                </div>
                
                <div class="flight-card">
                    <p class="card-title"><strong>Directo</strong></p>
                    <div style="font-size: 30px; font-weight: bold; color: #262E55;">
                        $' . $flight['costo_directo'] . ' 
                        <span style="font-size: 0.6em; color: #262E55;">MXN</span>
                    </div>
                    <form action="index.php?controller=vuelos&action=findVuelosReturn" method="POST">
                        <input type="hidden" name="tipo" value="Directo">
                        <input type="hidden" name="costo" value="' . $flight['costo_directo'] . '">
                        <input type="hidden" name="origen" value="' . $flight['origen'] . '">
                        <input type="hidden" name="destino" value="' . $flight['destino'] . '">
                        <input type="hidden" name="duracion" value="' . $flight['duracion'] . '">
                        <input type="hidden" name="hora_salida_format" value="' . $flight['hora_salida_format'] . '">
                        <input type="hidden" name="hora_llegada_format" value="' . $flight['hora_llegada_format'] . '">
                        <input type="hidden" name="descripcion_pasajeros" value="' . $flight['descripcion_pasajeros'] . '">
                        <input type="hidden" name="origen_full" value="' . $flight['origen_full'] . '">
                        <input type="hidden" name="destino_full" value="' . $flight['destino_full'] . '">
                        <input type="hidden" name="fecha_salida_detail" value="' . $flight['fecha_salida_detail'] . '">
                        <input type="hidden" name="fecha_regreso_detail" value="' . $flight['fecha_regreso_detail'] . '">
                        <input type="hidden" name="fecha_salida" value="' . $flight['fecha_salida'] . '">
                        <input type="hidden" name="fecha_regreso" value="' . $flight['fecha_regreso'] . '">
                        <input type="hidden" name="costo_directo" value="' . $flight['costo_directo'] . '">
                        <input type="hidden" name="costo_escala" value="' . $flight['costo_escala'] . '">
                        <input type="hidden" name="tua" value="' . $flight['tua'] . '">
                        <input type="hidden" name="iva" value="' . $flight['iva'] . '">
                        <input type="hidden" name="codigo_vuelo" value="' . $flight['codigo_vuelo'] . '">
                        <input type="hidden" name="porcentaje_desc" value="' . $flight['porcentaje_desc'] . '">
                        <input type="hidden" name="costo_directo_sin_iva_tua" value="' . $flight['costo_directo_sin_iva_tua'] . '">
                        <input type="hidden" name="costo_escala_sin_iva_tua" value="' . $flight['costo_escala_sin_iva_tua'] . '">
                        <input type="hidden" name="num_asientos" value="' . $flight['num_asientos'] . '">
                        <input type="hidden" name="asientos_ocupados" value="' . $flight['asientos_ocupados'] . '">
                        <button type="submit" name="action" value="findVuelosReturn" class="select-button">Seleccionar</button>
                    </form>
                </div>';

                        // Aquí se evalúa el costo de escala
                        if ($flight['costo_escala'] > 0) {
                            echo '
                            <div class="flight-card">
                                <p class="card-title"><strong>Escala</strong></p>
                                <div style="font-size: 30px; font-weight: bold; color: #262E55;">
                                    $' . $flight['costo_escala'] . ' 
                                    <span style="font-size: 0.6em; color: #262E55;">MXN</span>
                                </div>
                                <form action="index.php?controller=vuelos&action=findVuelosReturn" method="POST">
                                    <input type="hidden" name="tipo" value="Escala">
                                    <input type="hidden" name="costo" value="' . $flight['costo_escala'] . '">
                                    <input type="hidden" name="origen" value="' . $flight['origen'] . '">
                                    <input type="hidden" name="destino" value="' . $flight['destino'] . '">
                                    <input type="hidden" name="duracion" value="' . $flight['duracion'] . '">
                                    <input type="hidden" name="hora_salida_format" value="' . $flight['hora_salida_format'] . '">
                                    <input type="hidden" name="hora_llegada_format" value="' . $flight['hora_llegada_format'] . '">
                                    <input type="hidden" name="descripcion_pasajeros" value="' . $flight['descripcion_pasajeros'] . '">
                                    <input type="hidden" name="origen_full" value="' . $flight['origen_full'] . '">
                                    <input type="hidden" name="destino_full" value="' . $flight['destino_full'] . '">
                                    <input type="hidden" name="fecha_salida_detail" value="' . $flight['fecha_salida_detail'] . '">
                                    <input type="hidden" name="fecha_regreso_detail" value="' . $flight['fecha_regreso_detail'] . '">
                                    <input type="hidden" name="fecha_salida" value="' . $flight['fecha_salida'] . '">
                                    <input type="hidden" name="fecha_regreso" value="' . $flight['fecha_regreso'] . '">
                                    <input type="hidden" name="costo_directo" value="' . $flight['costo_directo'] . '">
                                    <input type="hidden" name="costo_escala" value="' . $flight['costo_escala'] . '">
                                    <input type="hidden" name="tua" value="' . $flight['tua'] . '">
                                    <input type="hidden" name="iva" value="' . $flight['iva'] . '">
                                    <input type="hidden" name="codigo_vuelo" value="' . $flight['codigo_vuelo'] . '">
                                    <input type="hidden" name="porcentaje_desc" value="' . $flight['porcentaje_desc'] . '">
                                    <input type="hidden" name="costo_directo_sin_iva_tua" value="' . $flight['costo_directo_sin_iva_tua'] . '">
                                    <input type="hidden" name="costo_escala_sin_iva_tua" value="' . $flight['costo_escala_sin_iva_tua'] . '">
                                    <input type="hidden" name="num_asientos" value="' . $flight['num_asientos'] . '">
                                    <input type="hidden" name="asientos_ocupados" value="' . $flight['asientos_ocupados'] . '">
                                    <button type="submit" name="action" value="findVuelosReturn" class="select-button">Seleccionar</button>
                                </form>
                            </div>';
                        }

                        echo '
                        </div>
                    </div>';
                    }
                    ?>
                </div>
                <!-- Mobile: Another div below (before footer) -->
                <div class="alert d-block d-md-none">
                    <div class="destinos fade-in">
                        <?php include('layouts/newdestinos.php') ?><br><br><br><br>
                    </div>
                </div>
            </div>

            <!-- Right Side (Visible only on desktop) -->
            <div class="right-side fade-in">
                <button type="submit" class="btn-s btn-submit" style="border-radius: 20px; padding: 8px 30px;">Modificar vuelo</button>

                <div class="alert flight-deta12" onclick="toggleFlightDetails()" style="color: #262E55;">
                    <b>Detalles de reservación</b>
                    <i class="arrow down" id="arrow-iconDetaDesk" style="margin-top:9px;"></i>
                </div>


                <div class="col-3 mb-4 flight-detaInfoo fade-in" id="flight-detaInfoo" style="margin-top:9%;  display: none; transition: max-height 0.5s ease-in-out; width:100%;">
                    <p style="font-weight: bold;">Pasajeros</p>
                    <?php foreach ($vuelosFiltrados as $vuelo): ?>
                        <p><?php echo $vuelo['descripcion_pasajeros']; ?></p>
                    <?php endforeach; ?>
                    <p style="font-weight: bold;">Origen</p>
                    <?php foreach ($vuelosFiltrados as $vuelo): ?>
                        <p><?php echo $vuelo['origen_full']; ?></p>
                    <?php endforeach; ?>
                    <p style="font-weight: bold;">Destino</p>
                    <?php foreach ($vuelosFiltrados as $vuelo): ?>
                        <p><?php echo $vuelo['destino_full']; ?></p>
                    <?php endforeach; ?>
                    <p style="font-weight: bold;">Fecha de salida</p>
                    <?php foreach ($vuelosFiltrados as $vuelo): ?>
                        <p><?php echo $vuelo['fecha_salida_detail']; ?></p>
                    <?php endforeach; ?>
                </div>

                <div class="alert" id="alert-section">
                    <div class="destinos fade-in" style="transition: all 0.5s ease;">
                        <?php include('layouts/newdestinos.php') ?>
                        <br><br><br>
                    </div>
                </div>
            </div>

        </div>
        <!--- /*** MODAL VUELOS NO ENCONTRADOS ***/-->
                <!-- Modal de "No hay vuelos disponibles" -->
                <?php if (isset($noHayVuelos) && $noHayVuelos): ?>
                    <div id="noVuelosModal" class="modal" tabindex="-1" role="dialog">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title">Búsqueda sin resultados</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Cerrar" onclick="closeModal(); window.location.href='index.php?controller=home&action=index'">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <p>No se encontraron vuelos disponibles. Por favor, intente nuevamente con otros parámetros.</p>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" onclick="closeModal(); window.location.href='index.php?controller=home&action=index'">Cerrar</button>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

                <script>
                    // Función para abrir el modal si no hay vuelos disponibles
                    window.onload = function() {
                        const noVuelosModal = document.getElementById("noVuelosModal");
                        if (noVuelosModal) {
                            noVuelosModal.style.display = "block";
                        }
                    }

                    // Función para cerrar el modal
                    function closeModal() {
                        document.getElementById("noVuelosModal").style.display = "none";
                    }
                </script>

                <style>
                    /* Estilos básicos para el modal */
                    .modal {
                        display: none;
                        position: fixed;
                        top: 0;
                        left: 0;
                        width: 100%;
                        height: 100%;
                        background-color: rgba(0, 0, 0, 0.5);
                        align-items: center;
                        justify-content: center;
                    }

                    .modal-dialog {
                        max-width: 500px;
                    }

                    .modal-content {
                        background-color: #fff;
                        padding: 20px;
                        border-radius: 8px;
                    }
                </style>
                <!--- /***********************************/ -->
        <!-- Footer -->
        <div>
            <footer class="footer fade-in" id="footer-section" style="background-color: #262E55; margin-top:10%;">
                <?php include('layouts/footer.php') ?>
            </footer>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/5.3.2/js/bootstrap.min.js"></script>
    <script src="https://getbootstrap.com/docs/5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>

    <script src="./assets/js/logo.js"></script>
    <script src="./assets/js/outDetailsFlight.js"></script>
    <script src="./assets/js/outDetailsFM.js"></script>
    <script src="./assets/js/outDetailsFliCards.js"></script>
    <script>
        AOS.init();
    </script>
    <script>
        AOS.init({
            duration: 1000, // Duración de la animación en milisegundos
            once: true // Si quieres que la animación se ejecute solo una vez
        });
    </script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const navbarToggler = document.querySelector('.navbar-toggler');
            navbarToggler.addEventListener('click', function() {
                const navbarCollapse = document.querySelector('#navbarsExample07XL');
                if (navbarCollapse.classList.contains('false')) {
                    navbarCollapse.classList.remove('show');
                } else {
                    navbarCollapse.classList.add('show');
                }
            });
        });
    </script>


</body>

</html>