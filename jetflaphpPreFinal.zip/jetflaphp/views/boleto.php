<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>JETFLA | Seleccionar Asientos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .card-container {
            position: relative;
            width: 100%;
            max-width: 600px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0px 5px 10px rgba(0, 0, 0, 0.2);
            padding: 20px;
            text-align: center;
            overflow: hidden;
        }

        .blue-tab {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 50px;
            background-color: #262E55;
            border-top-left-radius: 10px;
            border-top-right-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 15px;
            color: #fff;
        }

        .logo {
            height: 30px;
            width: auto;
        }

        .ticket-text {
            font-size: 16px;
            font-weight: bold;
        }

        .flight-info {
            margin-top: 20px;
            text-align: left;
        }

        .flight-details {
            margin-top: 20px;
        }

        .flight-schedule {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 20px;
        }

        .flight-icon {
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .flight-icon .line {
            display: block;
            width: 40px;
            height: 2px;
            background-color: #000;
            margin: 0 10px;
        }

        .details-card {
            margin-top: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px;
            background-color: #e9ecef;
            border-radius: 10px;
        }

        .details-card ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .details-card .flight-card {
            text-align: center;
        }

        .price {
            font-size: 24px;
            font-weight: bold;
            color: #262E55;
        }

        .qr-section {
            margin-top: 30px;
            text-align: center;
            /* Cambiar a 'left' */
        }

        .qr-section img {
            width: 150px;
            height: 150px;
            margin-left: 0;
            /* Asegura que el QR no tenga margen izquierdo */
        }
    </style>
</head>

<body>
    <?php foreach ($dataVuelosSalida as $vuelo): ?>
        <div class="card-container">
            <!-- Blue tab with logo and ticket text -->
            <div class="blue-tab">
                <img src="./assets/img/jetflaLogo.png" alt="Logo" class="logo">
                <span class="ticket-text">Ticket/Boleto</span>
            </div>
            <div class="flight-info"><br><br>
                <!-- Upper left corner with passenger name, flight date, and flight code -->
                <div style="text-align: right; font-size:14px;">
                    <p>Vuelo<br><b><?php echo $vuelo['codigo_vuelo'];?></b></p>
                </div>
                <div style="text-align: left; font-size:14px;">
                    <p>Pasajero<br><b>Nombre_pasajero_completo</b></p>
                    <p>Descripcion<br><b><?php echo $vuelo['descripcion_pasajeros'];?></b></p>
                </div>
                <div style="text-align: right; font-size:14px;">
                    <p>Salida<br><b><?php echo $vuelo['fecha_salida_detail'];?></b></p>
                </div>
            </div><br>

            <div class="flight-details">
                <div class="flight-schedule">
                    <div>
                        <span class="time"><?php echo $vuelo['hora_salida'];?></span><br>
                        <b><span class="airport-code"><?php echo $vuelo['origen'];?></span></b>
                    </div>
                    <div class="flight-icon">
                        <span class="line"></span>
                        <i class="fa fa-plane"></i>
                        <span class="line"></span>
                    </div>
                    <div>
                        <span class="time"><?php echo $vuelo['hora_llegada'];?></span><br>
                        <b><span class="airport-code"><?php echo $vuelo['destino'];?></span></b>
                    </div>
                </div>
            </div>

            <div class="details-card">
                <div>
                    <p><b>Detalles del vuelo</b></p>
                    <ul style=" text-align: left;">
                        <li style=" text-align: left;font-size:11px;">Reserva</li>
                        <li style=" text-align: left;"><b>cod_reserva</b></li>
                        <li style=" text-align: left;font-size:11px;">Asiento</li>
                        <li style=" text-align: left;"><b><?php echo $vuelo['selectedSeat'];?></b></li>
                        <li>Equipaje <b>20 KG</b></li>
                        <li>Comida incluida</li>
                    </ul>
                </div>
                <div class="flight-card">
                    <div class="qr-section">
                        <p><b><?php echo $vuelo['tipo'];?></b></p>
                        <p><b>Código QR</b></p>
                        <img src="qr_placeholder.png" alt="Código QR">
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
</body>

</html>