<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>JETFLA | Confirmar Pago</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/5.3.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://getbootstrap.com/docs/5.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link href="./assets/css/outFlights.css" rel="stylesheet">
    <link href="./assets/css/nabvar.css" rel="stylesheet">
    <link href="./assets/css/home.css" rel="stylesheet">
    <link href="./assets/css/pago.css" rel="stylesheet">

    <link href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.css" rel="stylesheet">
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
        }

        .content {
            padding: 20px;
        }
    </style>

</head>

<body>
    <div class="grid-container">
        <?php include('layouts/navbar.php') ?><br><br><br><br><br>
        <!-- Main Content -->
        <div class="content-grid">
            <!-- Left Side -->
            <div class="left"><br><br><br><br><br><br><br><br>
                <!--<div class="left-text">
                    <div class="reservation-cards fade-in d-none d-md-flex" style="margin-bottom:25%; margin-right: 6%; box-shadow: 0px 5px 10px rgba(0, 0, 0, 0.2);" data-aos="fade-up">
                        <div class="icon-text">
                            <div class="icon">
                                <img src="./assets/img/reloj.png" alt="Clock Icon">
                            </div>
                            <div class="text">
                                <strong>JETFLA | Reservar tarifas</strong>
                                <p>Cuentas con 24 hrs para realizar
                                    el pago de tu vuelo.</p>
                            </div>
                        </div>
                        <button class="pay-later">Pagar después</button>
                    </div>

                    <- MOBILE 
                    <div class="reservation-cards fade-in d-flex d-md-none" style="margin-bottom:25%; box-shadow: 0px 5px 10px rgba(0, 0, 0, 0.2    );" data-aos="fade-up">
                        <div class="icon-text">
                            <div class="icon">
                                <img src="./assets/img/reloj.png" alt="Clock Icon">
                            </div>
                            <div class="text">
                                <strong>JETFLA | Reservar tarifas</strong>
                                <p>Cuentas con 24 hrs para realizar
                                    el pago de tu vuelo.</p>
                            </div>
                        </div>
                        <button class="pay-later">Pagar después</button>
                    </div><br><br>
                </div>-->

                <div class="card-container" style="margin-left:2%; margin-top:-30%;"><br>

                    <div class="responsive-text fade-in" style="margin-left:3%;" data-aos="fade-up">
                        <span class="fw-bold fs-8" style="color: #861936; font-size:28px;">Información del pasajero</span>
                    </div>
                    <div class="content fade-in" style="margin-top: 5%; " data-aos="fade-up">
                        <div class="form-container fade-in" style="height: 370px; position: relative;">
                            <!-- Contenedor del Título -->
                            <div style="position: absolute; top: 10px; left: 5%; text-align: start;">
                                <h6 style="font-weight: bold; margin: 0; color:#262E55;">Pasajero</h6>
                                <p style="opacity: 0.6; margin: 0; color:#262E55;">Complete su información personal.</p>
                            </div>

                            <!-- Formulario Info del Pasajero -->
                            <form id="formularioVueloDeReserva" action="index.php?controller=vuelos&action=reserva" method="POST">
                                <div class="row" style="padding-top: 10%;">
                                    <!-- Columna Izquierda -->
                                    <div class="col-6">
                                        <div class="form-group custom-form-group">
                                            <label for="nombres" class="form-label" style="opacity: 0.6;">Nombres</label>
                                            <input style="font-style: italic;" type="text" class="form-control" id="nombres" name="nombres" placeholder="Ingresar" required>
                                        </div>
                                        <div class="form-group custom-form-group">
                                            <label for="genero" class="form-label" style="opacity: 0.6;">Género</label>
                                            <select class="form-control" id="genero" name="genero" required>
                                                <option value="" disabled selected>Seleccionar</option>
                                                <option value="femenino">Femenino</option>
                                                <option value="masculino">Masculino</option>
                                                <option value="otro">Otro</option>
                                            </select>
                                        </div>
                                        <div class="form-group custom-form-group">
                                            <label for="nacionalidad" class="form-label" style="opacity: 0.6;">Nacionalidad</label>
                                            <select class="form-control" id="nacionalidad" name="nacionalidad" required>
                                                <option value="" disabled selected>Seleccionar</option>
                                                <option value="mx">Mexicana</option>
                                                <option value="us">Estadounidense</option>
                                                <option value="otro">Otra</option>
                                            </select>
                                        </div>
                                    </div>

                                    <!-- Columna Derecha -->
                                    <div class="col-6">
                                        <div class="form-group custom-form-group">
                                            <label for="apellidos" class="form-label" style="opacity: 0.6;">Apellidos</label>
                                            <input style="font-style: italic;" type="text" class="form-control" id="apellidos" name="apellidos" placeholder="Ingresar" required>
                                        </div>
                                        <div class="form-group custom-form-group">
                                            <label for="fechaNacimiento" class="form-label" style="opacity: 0.6;">Fecha de nacimiento</label>
                                            <input type="date" class="form-control" id="fechaNacimiento" name="fechaNacimiento" required>
                                        </div>
                                        <div class="form-group custom-form-group" style="margin-top: 18%;">
                                            <button id="btn-siguiente" type="button" class="btn-submit" style="width: 100%; ">Siguiente&nbsp;<i class="fa-solid fa-arrow-right"></i></button>
                                        </div>
                                    </div>
                                </div>
                        </div>
                        <script>
                            document.getElementById('btn-siguiente').addEventListener('click', function() {
                                location.href = '#contact-section';
                            });
                        </script>
                    </div>


                    <div id="contact-section" class="responsive-text fade-in" style="margin-left:3%; margin-top: 10%;" data-aos="fade-up">
                        <span class="fw-bold fs-8" style="color: #861936; font-size:28px;">Contacto</span>
                    </div>
                    <div class="content fade-in" style="margin-top: 5%; " data-aos="fade-up">
                        <div class="form-container fade-in" style="height: 370px; position: relative;">
                            <!-- Contenedor del Título -->
                            <div style="position: absolute; top: 10px; left: 5%; text-align: start;">
                                <h6 style="font-weight: bold; margin: 0; color:#262E55;">Deatalles de contacto</h6>
                                <p style="opacity: 0.6; margin: 0; color:#262E55;">Notificaremos toda informacion relacionada con tu vuelo.</p>
                            </div>

                            <!-- Formulario -->

                            <div class="row" style="padding-top: 10%;">
                                <!-- Columna Izquierda -->
                                <div class="col-6">
                                    <div class="form-group custom-form-group">
                                        <label for="nombres_contact_pasajero" class="form-label" style="opacity: 0.6;">Nombres</label>
                                        <input style="font-style: italic;" type="text" class="form-control" id="nombres_contact_pasajero" name="nombres_contact_pasajero" placeholder="Ingresar" required>
                                    </div>
                                    <div class="form-group custom-form-group">
                                        <label for="email" class="form-label" style="opacity: 0.6;">Email</label>
                                        <input style="font-style: italic;" type="email" class="form-control" id="email" name="email" placeholder="Ingresar" required>
                                    </div>
                                    <div class="form-group" style="display: flex; align-items: center; gap: 10px;">
                                        <!-- Select de claves de país -->
                                        <div style="flex: 0 0 auto;">
                                            <label for="countryCode" class="form-label" style="opacity: 0.6;">Clave País</label>
                                            <select id="countryCode" name="countryCode" class="form-select" style="font-style: italic; background-color:transparent;">
                                                <option value="+1">+1</option>
                                                <option value="+44">+44</option>
                                                <option value="+52">+52</option>
                                                <option value="+34">+34 </option>
                                                <option value="+91">+91</option>
                                                <!-- Agrega más opciones según los países que necesites -->
                                            </select>
                                        </div>
                                        <!-- Input del teléfono celular -->
                                        <div style="flex: 1;">
                                            <label for="telefono_contact" class="form-label" style="opacity: 0.6;">Teléfono celular</label>
                                            <input style="font-style: italic;" type="number" class="form-control" id="telefono_contact" name="telefono_contact" placeholder="Ingresar" required>
                                        </div>
                                    </div>
                                </div>

                                <!-- Columna Derecha -->
                                <div class="col-6">
                                    <div class="form-group custom-form-group">
                                        <label for="apellidos_contact_pasajero" class="form-label" style="opacity: 0.6;">Apellidos</label>
                                        <input style="font-style: italic;" type="text" class="form-control" id="apellidos_contact_pasajero" name="apellidos_contact_pasajero" placeholder="Ingresar" required>
                                    </div>
                                    <div class="form-group custom-form-group">
                                        <label for="email_verify" class="form-label" style="opacity: 0.6;">Verificar email</label>
                                        <input style="font-style: italic;" type="email" class="form-control" id="email_verify" name="email_verify" placeholder="Ingresar" required>
                                    </div>
                                    <div class="form-group" style="margin-top: 18%;">
                                        <button id="btn-siguiente-pay" type="button" class="btn-submit" style="width: 100%; ">Siguiente&nbsp;<i class="fa-solid fa-arrow-right"></i></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <script>
                        document.getElementById('btn-siguiente-pay').addEventListener('click', function() {
                            location.href = '#pay-section';
                        });
                    </script>

                    <div id="pay-section" class="responsive-text fade-in" style="margin-left:3%; margin-top: 10%;" data-aos="fade-up">
                        <span class="fw-bold fs-8" style="color: #861936; font-size:28px;">Seleccionar forma de pago</span>
                    </div>
                    <div class="fade-in" style="display: flex; gap: 20px; margin-top: 5%; margin-left:20%;" data-aos="fade-up">
                        <!-- Botón PayPal -->
                        <div class="payment-option">
                            <img src="https://upload.wikimedia.org/wikipedia/commons/a/a4/Paypal_2014_logo.png" alt="PayPal" width="50">
                            <p>PayPal</p>
                        </div>

                        <!-- Botón Tarjeta de débito/crédito -->
                        <div class="payment-option">
                            <img src="./assets/img/creditCard.png" alt="Tarjeta" width="50">
                            <p>Tarjeta de débito/crédito</p>
                        </div>
                    </div>

                    <div class="content fade-in" style="margin-top: 3%; " data-aos="fade-up">
                        <div class="form-container fade-in" style="height: 370px; position: relative;">
                            <!-- Contenedor del Título -->
                            <div style="position: absolute; top: 10px; left: 5%; text-align: start;">
                                <h6 style="font-weight: bold; margin: 0; color:#262E55;">Tarjeta de debito/credito</h6>
                                <p style="opacity: 0.6; margin: 0; color:#262E55;">Ingresa los datos de tu tarjeta.</p>
                            </div>

                            <!-- Formulario -->

                            <div class="row" style="padding-top: 10%;">
                                <!-- Columna Izquierda -->
                                <div class="col-6">
                                    <div class="form-group custom-form-group">
                                        <label for="card-number" class="form-label" style="opacity: 0.6;">Numero de tarjeta</label>
                                        <input style="font-style: italic;" type="number" class="form-control" id="card-number" name="card-number" maxlength="4" placeholder="1234 5678 9012 3456" required>
                                    </div>
                                    <div class="form-group custom-form-group">
                                        <label for="CCV" class="form-label" style="opacity: 0.6;">CCV</label>
                                        <input style="font-style: italic;" type="number" class="form-control" id="CCV" name="CCV" maxlength="4" placeholder="000" required>
                                    </div>
                                </div>

                                <!-- Columna Derecha -->
                                <div class="col-6">
                                    <div class="form-group custom-form-group">
                                        <label for="fecha_expiracion" class="form-label" style="opacity: 0.6;">Fecha de expiración</label>
                                        <input style="font-style: italic;" type="text" class="form-control" id="fecha_expiracion" name="fecha_expiracion" maxlength="5" placeholder="MM/YY" required oninput="applyMask(this)">

                                    </div><br>
                                    <div class="form-group custom-form-group">
                                        <input type="checkbox" id="terminos" name="terminos" required> <b style="opacity: 0.6; font-weight: normal;">
                                            Acepto el uso de mi información en <a href="#" style="color: #861936 !important; text-decoration: none;">Términos y condiciones</a>
                                        </b>
                                    </div>
                                    <div class="form-group" style="margin-top: 18%; margin-left:-60%;">
                                        <?php foreach ($dataVuelosSalida as $vuelo): ?>
                                            <?php if (!empty($vuelo['selectedExtras'])): ?>
                                                <?php foreach ($vuelo['selectedExtras'] as $extra): ?>
                                                    <input type="hidden" name="selectedExtras[description][]" value="<?php echo $extra['description']; ?>">
                                                    <input type="hidden" name="selectedExtras[cost][]" value="<?php echo $extra['cost']; ?>">
                                                <?php endforeach; ?>
                                            <?php endif; ?>
                                            <input type="hidden" name="selectedSeat" value="<?php echo $vuelo['selectedSeat']; ?>">
                                            <input type="hidden" name="totalGlobal" value="<?php echo $vuelo['totalGlobal']; ?>">
                                            <input type="hidden" name="codigo_vuelo" value="<?php echo $vuelo['codigo_vuelo']; ?>">
                                            <input type="hidden" name="hora_salida" value="<?php echo $vuelo['hora_salida']; ?>">
                                            <input type="hidden" name="origen" value="<?php echo $vuelo['origen']; ?>">
                                            <input type="hidden" name="hora_llegada" value="<?php echo $vuelo['hora_llegada']; ?>">
                                            <input type="hidden" name="destino" value="<?php echo $vuelo['destino']; ?>">
                                            <input type="hidden" name="tipo" value="<?php echo $vuelo['tipo']; ?>">
                                            <input type="hidden" name="costo" value="<?php echo $vuelo['costo']; ?>">
                                            <input type="hidden" name="descripcion_pasajeros" value="<?php echo $vuelo['descripcion_pasajeros']; ?>">
                                            <input type="hidden" name="fecha_salida_detail" value="<?php echo $vuelo['fecha_salida_detail']; ?>">
                                            <input type="hidden" name="fecha_regreso_detail" value="<?php echo $vuelo['fecha_regreso_detail']; ?>">
                                            <input type="hidden" name="costo_escala_sin_iva_tua" value="<?php echo $vuelo['costo_escala_sin_iva_tua']; ?>">
                                            <input type="hidden" name="costo_directo_sin_iva_tua" value="<?php echo $vuelo['costo_directo_sin_iva_tua']; ?>">
                                            <input type="hidden" name="iva" value="<?php echo $vuelo['iva']; ?>">
                                            <input type="hidden" name="tua" value="<?php echo $vuelo['tua']; ?>">
                                            <input type="hidden" name="porcentaje_desc" value="<?php echo $vuelo['porcentaje_desc']; ?>">
                                        <?php endforeach; ?>
                                        <button type="submit" class="btn-submit" style="width: 100%; margin-left:-30%; ">Pagar mi proximo vuelo ✓</button>
                                    </div>
                                </div>
                            </div>
                            </form>
                        </div>
                    </div>
                </div><br><br><br>

                <!-- Mobile: Another div below (before footer) -->
                <div class="alert d-block d-md-none fade-in" data-aos="fade-up">
                    <div class="flight-cost-container" style=" margin-bottom:5%; position: sticky; top:calc(3% + 550px); z-index: 1;">
                        <?php foreach ($dataVuelosSalida as $vuelo): ?>
                            <div class="alert flight-deta12" id="costosDetails" style="color: #262E55; ">
                                <b style="color: #861936; font-size:25px;" class="text-success">Total</b>
                                <b style="color: #861936; font-size:25px;" class="text-success">$&nbsp;<?php echo number_format($vuelo['totalGlobal'], 2); ?> MXN </b>
                            </div>
                            <div class="alert flight-deta12" id="costosDetails" style="color: green;  margin-bottom:-2.5%; top:-9%; display: flex; justify-content: center; align-items: center; background-color:#31BC36;">
                                <b style="color: #861936; font-size:17px; text-align:center;" class="text-light">PRECIO FINAL</b>
                            </div>
                        <?php endforeach; ?>
                    </div>

                    <div class="alert flight-deta12" id="casientosSeleccion" style="color: #262E55; margin-bottom:30%; margin-top:20%;"> <!-- Ajuste en top -->
                        <b style="color: #861936; font-size:20px;">Asientos seleccionados </b><br>
                        <div class="flight-detaInfoo fade-in" style="margin-top:14%; margin-left:-25%; width:100%;">
                            <?php foreach ($dataVuelosSalida as $vuelo): ?>
                                <?php if ($vuelo['fecha_regreso_detail'] == 'Sin fecha de regreso'): ?>
                                    <div style="display: flex; justify-content: space-between;">
                                        <p style="font-weight: bold; font-size:18px;">Salida</p>
                                        <p style="font-weight: bold;">&nbsp;&nbsp; <?php echo $vuelo['origen']; ?> → <?php echo $vuelo['destino']; ?></p>
                                        <p style="font-weight: bold; color: #861936;"><?php echo $vuelo['selectedSeat']; ?></p>
                                    </div>
                                <?php else: ?>
                                    <div style="display: flex; justify-content: space-between;">
                                        <p style="font-weight: bold; font-size:18px;">Salida</p>
                                        <p style="font-weight: bold;">&nbsp;&nbsp; <?php echo $vuelo['origen']; ?> → <?php echo $vuelo['destino']; ?></p>
                                        <p style="font-weight: bold; color: #861936;"><?php echo $vuelo['selectedSeat']; ?></p>
                                    </div>
                                    <div style="display: flex; justify-content: space-between;">
                                        <p style="font-weight: bold; font-size:18px;">Regreso</p>
                                        <p style="font-weight: bold;">&nbsp;&nbsp; <?php echo $vuelo['origen']; ?> → <?php echo $vuelo['destino']; ?></p>
                                        <p style="font-weight: bold; color: #861936;"><?php echo $vuelo['selectedSeat']; ?></p>
                                    </div>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <div class="alert flight-deta12" id="costosDetails" style="color: #262E55; margin-bottom:70%; margin-top:15%;">
                        <b style="color: #861936;">Reservación</b>
                        <div class="flight-detaInfoo fade-in" style="margin-top:12%; margin-left:-25%; width:100%;">
                            <?php foreach ($dataVuelosSalida as $vuelo): ?>
                                <p style="font-weight: bold;">Pasajeros</p>
                                <p><?php echo $vuelo['descripcion_pasajeros']; ?></p>

                                <p style="font-weight: bold;">Fecha de salida</p>
                                <p><?php echo $vuelo['fecha_salida_detail']; ?></p>
                                <p style="font-weight: bold;">Fecha de regreso</p>
                                <p><?php echo $vuelo['fecha_regreso_detail']; ?></p>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <div class="alert flight-deta12" id="costosDetails" style="color: #262E55; margin-bottom:113%; position: sticky; top: 15%;">
                        <b style="color: #861936;">Costos de vuelo</b>
                        <div class="flight-detaInfoo fade-in" style="margin-top:12%; margin-left:-25%; width:100%;">
                            <?php foreach ($dataVuelosSalida as $vuelo): ?>
                                <div style="display: flex; justify-content: space-between;">
                                    <p style="font-weight: bold;">Vuelo | Salida</p>
                                    <?php if ($vuelo['tipo'] === 'Escala'): ?>
                                        <b>
                                            <p>$<?php echo $vuelo['costo_escala_sin_iva_tua']; ?></p>
                                        </b>
                                    <?php else: ?>
                                        <b>
                                            <p>$<?php echo $vuelo['costo_directo_sin_iva_tua']; ?></p>
                                        </b>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; ?>

                            <div style="display: flex; justify-content: space-between;">
                                <?php foreach ($dataVuelosSalida as $vuelo): ?>
                                    <p style="font-weight: bold;">TUA
                                        <span style="font-size: 17px; cursor: pointer;" title="El TUA es el impuesto de uso aeroportuario.">
                                            <i class="fa-solid fa-circle-question"></i>
                                        </span>
                                    </p>
                                    <p>$<?php echo $vuelo['tua']; ?></p>
                            </div>

                            <div style="display: flex; justify-content: space-between;">
                                <p style="font-weight: bold;">IVA</p>
                                <p>$<?php echo $vuelo['iva']; ?></p>
                            </div>

                            <div style="display: flex; justify-content: space-between; color: green;">
                                <?php if ($vuelo['porcentaje_desc'] !== ''): ?>
                                    <p style="font-weight: bold;">Descuento</p>
                                    <p>-<?php echo $vuelo['porcentaje_desc']; ?>%</p>
                                <?php else: ?>
                                    <p></p>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>

                        <!-- Extras Seleccionados -->
                        <?php foreach ($dataVuelosSalida as $vuelo): ?>
                            <?php if (!empty($vuelo['selectedExtras'])): ?>
                                <div style="margin-top: 10px; border-top: 1px solid #ccc; padding-top: 10px; ">
                                    <p style="font-weight: bold;">Extras seleccionados:</p>
                                    <?php foreach ($vuelo['selectedExtras'] as $extra): ?>
                                        <div style="display: flex; justify-content: space-between;">
                                            <p><?php echo $extra['description']; ?></p>
                                            <p>$<?php echo $extra['cost']; ?></p>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            <?php else: ?>
                                <div style="margin-top: 10px; border-top: 1px solid #ccc; padding-top: 10px;">
                                    <p>No se seleccionaron extras.</p>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; ?>

                        </div>
                    </div>


                </div>
            </div>

            <!-- Right Side (Visible only on desktop) -->
            <div class="right-side fade-in">

                <div class="alert flight-deta12" id="costosDetails" style="color: #262E55; margin-bottom:7%; margin-top:22%;">
                    <b style="color: #861936;">Reservación</b>
                    <div class="flight-detaInfoo fade-in" style="margin-top:8%; margin-left:-25%; width:120%;">
                        <?php foreach ($dataVuelosSalida as $vuelo): ?>
                            <p style="font-weight: bold;">Pasajeros</p>
                            <p><?php echo $vuelo['descripcion_pasajeros']; ?></p>

                            <p style="font-weight: bold;">Fecha de salida</p>
                            <p><?php echo $vuelo['fecha_salida_detail']; ?></p>
                            <p style="font-weight: bold;">Fecha de regreso</p>
                            <p><?php echo $vuelo['fecha_regreso_detail']; ?></p>
                        <?php endforeach; ?>
                    </div>
                </div><br><br><br><br><br><br><br><br><br>
                <!-- Primer div -->
                <div class="alert flight-deta12" id="costosDetails" style="color: #262E55; margin-bottom:95%; position: sticky; top: 15%;">
                    <b style="color: #861936;">Costos de vuelo</b>
                    <div class="flight-detaInfoo fade-in" style="margin-top:8%; margin-left:-25%; width:120%;">
                        <?php foreach ($dataVuelosSalida as $vuelo): ?>
                            <div style="display: flex; justify-content: space-between;">
                                <p style="font-weight: bold;">Vuelo | Salida</p>
                                <?php if ($vuelo['tipo'] === 'Escala'): ?>
                                    <b>
                                        <p>$<?php echo $vuelo['costo_escala_sin_iva_tua']; ?></p>
                                    </b>
                                <?php else: ?>
                                    <b>
                                        <p>$<?php echo $vuelo['costo_directo_sin_iva_tua']; ?></p>
                                    </b>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>

                        <div style="display: flex; justify-content: space-between;">
                            <?php foreach ($dataVuelosSalida as $vuelo): ?>
                                <p style="font-weight: bold;">TUA
                                    <span style="font-size: 17px; cursor: pointer;" title="El TUA es el impuesto de uso aeroportuario.">
                                        <i class="fa-solid fa-circle-question"></i>
                                    </span>
                                </p>
                                <p>$<?php echo $vuelo['tua']; ?></p>
                        </div>

                        <div style="display: flex; justify-content: space-between;">
                            <p style="font-weight: bold;">IVA</p>
                            <p>$<?php echo $vuelo['iva']; ?></p>
                        </div>

                        <div style="display: flex; justify-content: space-between; color: green;">
                            <?php if ($vuelo['porcentaje_desc'] !== ''): ?>
                                <p style="font-weight: bold;">Descuento</p>
                                <p>-<?php echo $vuelo['porcentaje_desc']; ?>%</p>
                            <?php else: ?>
                                <p></p>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                    <!-- Extras Seleccionados -->
                    <?php foreach ($dataVuelosSalida as $vuelo): ?>
                        <?php if (!empty($vuelo['selectedExtras'])): ?>
                            <div style="margin-top: 10px; border-top: 1px solid #ccc; padding-top: 10px;">
                                <p style="font-weight: bold;">Extras seleccionados:</p>
                                <?php foreach ($vuelo['selectedExtras'] as $extra): ?>
                                    <div style="display: flex; justify-content: space-between;">
                                        <p><?php echo $extra['description']; ?></p>
                                        <p>$<?php echo $extra['cost']; ?></p>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php else: ?>
                            <div style="margin-top: 10px; border-top: 1px solid #ccc; padding-top: 10px;">
                                <p>No se seleccionaron extras.</p>
                            </div>
                        <?php endif; ?>
                    <?php endforeach; ?>

                    </div>
                </div>
                <div class="flight-cost-container" style=" margin-bottom:-1%; position: sticky; top:calc(45% + 550px);">
                    <?php foreach ($dataVuelosSalida as $vuelo): ?>
                        <div class="alert flight-deta12" id="costosDetails" style="color: #262E55; ">
                            <b style="color: #861936; font-size:25px;" class="text-success">Total</b>
                            <b style="color: #861936; font-size:25px;" class="text-success">$&nbsp;<?php echo number_format($vuelo['totalGlobal'], 2); ?> MXN </b>
                        </div>
                        <div class="alert flight-deta12" id="costosDetails" style="color: green;  margin-bottom:-2.5%; top:-9%; display: flex; justify-content: center; align-items: center; background-color:#31BC36;">
                            <b style="color: #861936; font-size:17px; text-align:center;" class="text-light">PRECIO FINAL</b>
                        </div>
                    <?php endforeach; ?>
                </div>

                <!-- Segundo div -->
                <div class="alert flight-deta12" id="casientosSeleccion" style="color: #262E55; margin-bottom:35%; position: sticky; top: calc(15% + 350px);"> <!-- Ajuste en top -->
                    <b style="color: #861936; font-size:20px;">Asientos seleccionsados </b><br>
                    <div class="flight-detaInfoo fade-in" style="margin-top:10%; margin-left:-25%; width:200%;">
                        <?php foreach ($dataVuelosSalida as $vuelo): ?>
                            <?php if ($vuelo['fecha_regreso_detail'] == 'Sin fecha de regreso'): ?>
                                <div style="display: flex; justify-content: space-between;">
                                    <p style="font-weight: bold; font-size:18px;">Salida</p>
                                    <p style="font-weight: bold;">&nbsp;&nbsp; <?php echo $vuelo['origen']; ?> → <?php echo $vuelo['destino']; ?></p>
                                    <p style="font-weight: bold; color: #861936;"><?php echo $vuelo['selectedSeat']; ?></p>
                                </div>
                            <?php else: ?>
                                <div style="display: flex; justify-content: space-between;">
                                    <p style="font-weight: bold; font-size:18px;">Salida</p>
                                    <p style="font-weight: bold;">&nbsp;&nbsp; <?php echo $vuelo['origen']; ?> → <?php echo $vuelo['destino']; ?></p>
                                    <p style="font-weight: bold; color: #861936;"><?php echo $vuelo['selectedSeat']; ?></p>
                                </div>
                                <div style="display: flex; justify-content: space-between;">
                                    <p style="font-weight: bold; font-size:18px;">Regreso</p>
                                    <p style="font-weight: bold;">&nbsp;&nbsp; <?php echo $vuelo['origen']; ?> → <?php echo $vuelo['destino']; ?></p>
                                    <p style="font-weight: bold; color: #861936;"><?php echo $vuelo['selectedSeat']; ?></p>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
        <!-- Footer -->
        <div>
            <footer class="footer fade-in" id="footer-section" style="background-color: #262E55; margin-top:5%;">
                <?php include('layouts/footer.php') ?>
            </footer>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/2.11.7/umd/popper.min.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/5.3.2/js/bootstrap.min.js"></script>
    <script src="https://getbootstrap.com/docs/5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

    <script src="https://getbootstrap.com/docs/5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>
    <script src="./assets/js/logo.js"></script>
    <script src="./assets/js/outDetailsFlight.js"></script>
    <script src="./assets/js/outDetailsFM.js"></script>
    <script src="./assets/js/outDetailsFMRegreso.js"></script>
    <script src="./assets/js/outDetailsFlightMobile2.js"></script>
    <script src="./assets/js/outDetailsFliCards.js"></script>
    <script>
        AOS.init();
    </script>
    <script>
        AOS.init({
            duration: 1000, // Duración de la animación en milisegundos
            once: true // Si quieres que la animación se ejecute solo una vez
        });
    </script>
    <script>
        function applyMask(input) {
            let value = input.value.replace(/\D/g, ''); // Elimina caracteres que no son números
            if (value.length >= 3) {
                input.value = value.slice(0, 2) + '/' + value.slice(2, 4);
            } else {
                input.value = value;
            }
        }
    </script>
</body>

</html>