// Obtener referencias a los elementos
const tripTypeSwitch = document.getElementById('tripTypeSwitch');
const tripTypeSwitch2 = document.getElementById('tripTypeSwitch2');
const regresoInput = document.getElementById('regreso');

// Función para manejar el cambio del switch
tripTypeSwitch.addEventListener('change', function () {
    if (!this.checked) { // Si el switch está en "Sencillo"
        regresoInput.value = ''; // Vaciar el input
        regresoInput.disabled = true; // Deshabilitar el input
        regresoInput.removeAttribute('name'); // Quitar el atributo 'name' para que no se envíen datos
    } else { // Si el switch está en "Redondo"
        regresoInput.disabled = false; // Habilitar el input
        regresoInput.setAttribute('name', 'regreso'); // Restaurar el atributo 'name'
    }
});

// Función para manejar el cambio del switch 2
tripTypeSwitch2.addEventListener('change', function () {
    if (!this.checked) { // Si el switch está en "Sencillo"
        regresoInput.value = ''; // Vaciar el input
        regresoInput.disabled = true; // Deshabilitar el input
        regresoInput.removeAttribute('name'); // Quitar el atributo 'name' para que no se envíen datos
    } else { // Si el switch está en "Redondo"
        regresoInput.disabled = false; // Habilitar el input
        regresoInput.setAttribute('name', 'regreso'); // Restaurar el atributo 'name'
    }
});

// Deshabilitar el input al cargar la página si el switch está en "Sencillo"
if (!tripTypeSwitch.checked) {
    regresoInput.disabled = true;
    regresoInput.removeAttribute('name');
}
 // Deshabilitar el input al cargar la página si el switch está en "Sencillo"
 if (!tripTypeSwitch2.checked) {
    regresoInput.disabled = true;
    regresoInput.removeAttribute('name');
}