// MOVER LOGO CH
window.addEventListener('scroll', function() {
            const logoXL = document.getElementById('logoXL');
            const logoCH = document.getElementById('logoCH');
            const quienSos = document.getElementById('quienSos');
            const scrollPosition = window.scrollY;
            const threshold = 100; // Adjust this value based on when you want the transition to occur

            if (scrollPosition > threshold) {
                // Scroll down
                logoXL.classList.remove('visible');
                logoXL.classList.add('hidden');
                logoCH.classList.remove('hidden');
                logoCH.classList.add('visible');
            } else {
                // Scroll up
                logoCH.classList.remove('visible');
                logoCH.classList.add('hidden');
                logoXL.classList.remove('hidden');
                logoXL.classList.add('visible');
            }
        });
// END MOVER LOGO CH

