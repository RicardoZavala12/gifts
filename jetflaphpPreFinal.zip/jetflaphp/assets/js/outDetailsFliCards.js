function dinamicaDetails(detailsId, detailsIcon) {
    var detailsElement = document.getElementById(detailsId);
    var arrowIcon = document.getElementById(detailsIcon);

    if (detailsElement.style.maxHeight === "0px" || detailsElement.style.maxHeight === "") {
        // Mostrar el contenido con efecto de despliegue
        detailsElement.style.display = "flex"; // Asegura que el elemento sea visible
        detailsElement.style.maxHeight = detailsElement.scrollHeight + "px"; // Expande
        arrowIcon.classList.remove('down');
        arrowIcon.classList.add('up');
    } else {
        // Colapsar el contenido
        detailsElement.style.maxHeight = "0px"; // Colapsa
        setTimeout(function() {
            detailsElement.style.display = "none";
        }, 400); // Esperar el final de la animación antes de ocultarlo
        arrowIcon.classList.remove('up');
        arrowIcon.classList.add('down');
    }
}