<?php
require_once './models/Destino.php';

class DestinosController
{
    public static function getDestinosCarousel()
    {
        $destinosImg = Destino::getAllImg();

        /********* GET IMG FOR CARDS NEW DESTINATIONS CAROUSEL *******/
        // Filtrar destinos con tipo_visualizacion = 0
        $destinosCarousel = array_filter($destinosImg, function ($destino) {
            return isset($destino['tipo_visualizacion']) && $destino['tipo_visualizacion'] == 0;
        });

        // Ordenar por fecha_publicacion descendente para tener los más recientes primero
        usort($destinosCarousel, function ($a, $b) {
            return strtotime($b['fecha_publicacion']) - strtotime($a['fecha_publicacion']);
        });

        // Seleccionar solo los primeros 3 registros
        $destinosCarousel = array_slice($destinosCarousel, 0, 3);
        return $destinosCarousel;
        require './views/layouts/newdestinos.php';
        //var_dump($destinosCarousel);        
    }

    public static function getDestinosCards()
    {
        $destinosImg = Destino::getAllImg();

        /********* GET IMG FOR CARDS NEW DESTINATIONS CAROUSEL *******/
        // Filtrar destinos con tipo_visualizacion = 1
        $destinosCards = array_filter($destinosImg, function ($destino) {
            return isset($destino['tipo_visualizacion']) && $destino['tipo_visualizacion'] == 1;
        });

        // Ordenar por fecha_publicacion descendente para tener los más recientes primero
        usort($destinosCards, function ($a, $b) {
            return strtotime($b['fecha_publicacion']) - strtotime($a['fecha_publicacion']);
        });

        // Seleccionar solo los primeros 4 registros
        $destinosCards = array_slice($destinosCards, 0, 4);
        return $destinosCards;
    }

    public static function getDestinosCompletos()
    {
        // Obtener los destinos desde el modelo (o la API) usando Destino::getAll()
        $destinosCompleto = Destino::getAll();

        // Crear el array de mapeo
        $destinosCompletos = [];
        foreach ($destinosCompleto as $destino) {
            // Mapear abreviación a nombre completo
            $destinosCompletos[$destino['abrev']] = $destino['nombre_destino'];
        }

        return $destinosCompletos;
    }


    /*  public function create() {
        require './views/admin_create.php';
    }

    public function store() {
        Admin::create($_POST);
        header('Location: index.php?controller=admin&action=index');
    }
    
    public function edit($id) {
        $admins = Admin::getAll();
        $admin = $admins[$id];
        require './views/admin_edit.php';
    }

    public function update($id) {
        Admin::update($id, $_POST);
        header('Location: index.php?controller=admin&action=index');
    }

    public function destroy($id) {
        Admin::delete($id);
        header('Location: index.php?controller=admin&action=index');
    }
    */
}
