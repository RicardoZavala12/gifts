<?php
require_once './models/Destino.php';
require_once 'DestinosController.php';


class HomeController
{
    public static function index()
    {
        $destinos = Destino::getAll();
        $destinosImg = Destino::getAllImg();

        //Get img new destinations cards
        $destinosCards = DestinosController::getDestinosCards();
        //Get img new destinations carousel
        $destinosCarousel = DestinosController::getDestinosCarousel();
        // Definir la variable para evitar errores si no está establecida
        $noHayVuelos = $noHayVuelos ?? false;
        include './views/home.php';
    }


    /*  public function create() {
        require './views/admin_create.php';
    }

    public function store() {
        Admin::create($_POST);
        header('Location: index.php?controller=admin&action=index');
    }
    
    public function edit($id) {
        $admins = Admin::getAll();
        $admin = $admins[$id];
        require './views/admin_edit.php';
    }

    public function update($id) {
        Admin::update($id, $_POST);
        header('Location: index.php?controller=admin&action=index');
    }

    public function destroy($id) {
        Admin::delete($id);
        header('Location: index.php?controller=admin&action=index');
    }
    */
}
