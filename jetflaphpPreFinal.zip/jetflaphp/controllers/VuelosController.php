<?php
require_once './models/Vuelos.php';
require_once './models/Extras.php';
require_once 'DestinosController.php';
require_once 'HomeController.php';


class VuelosController
{

    //Seleccionar vuelos salida
    public function index()
    {
        $destinosCarousel = DestinosController::getDestinosCarousel();
        require './views/departure_vuelos.php';
    }

    public function findVuelos()
    {
        // Obtener los vuelos de la API
        $vuelos = Vuelos::getAll();
        // Obtener los codigos promo de la API
        $codPromoAPI = Vuelos::getAllCodigosPromos();
        // Obtener los destinos completos de la API
        $destinosCompletos = DestinosController::getDestinosCompletos();
        // Obtener los img de destinos de la API
        $destinosCarousel = DestinosController::getDestinosCarousel();

        $origen = $_POST['origen'];
        $destino = $_POST['destino'];
        $salida = $_POST['salida'];
        $regreso = isset($_POST['regreso']) ? $_POST['regreso'] : 'Sin fecha de regreso';
        $codigoPromo = $_POST['codigoPromo'];

        // Verificar que `passengerData` está presente y no es nulo
        $passengerData = isset($_POST['passengerData']) ? json_decode($_POST['passengerData'], true) : null;

        $adultos = $passengerData['adult'] ?? 0;
        $menores = $passengerData['child'] ?? 0;
        $bebes = $passengerData['infant'] ?? 0;

        $vuelosData = [
            'origen' => $origen,
            'destino' => $destino,
            'salida' => $salida,
            'regreso' => $regreso,
            'codigoPromo' => $codigoPromo,
            'adultos' => $adultos,
            'menores' => $menores,
            'bebes' => $bebes
        ];

        $codigosActivos = array_filter($codPromoAPI, function ($codigo) {
            return $codigo['estado'] == 1; // Filtra solo los códigos que estén activos
        });

        // Buscar el código promocional específico en los códigos activos
        $codigoEncontrado = array_filter($codigosActivos, function ($codigo) use ($codigoPromo) {
            return $codigo['codigo'] === $codigoPromo; // Filtrar por el atributo 'codigo'
        });

        // Obtener el descuento si se encuentra el código
        $descuento = !empty($codigoEncontrado) ? reset($codigoEncontrado)['descuento'] : null;

        $vuelosFiltrados = array_filter($vuelos, function ($vueloDesc) use ($vuelosData) {
            return $vueloDesc['origen'] === $vuelosData['origen'] &&
                $vueloDesc['destino'] === $vuelosData['destino'] &&
                $vueloDesc['fecha_salida'] === $vuelosData['salida'];
        });

        // mandar la cantidad de porcentaje
        foreach ($vuelosFiltrados as &$desc) {
            $desc['porcentaje_desc'] = $descuento;
        }
        unset($desc);


        // Guardar los costos originales antes de sumar IVA y TUA
        foreach ($vuelosFiltrados as &$vueloCost) {
            // Guardar el costo directo y el costo escala sin IVA y TUA
            $vueloCost['costo_directo_sin_iva_tua'] = $vueloCost['costo_directo'];
            $vueloCost['costo_escala_sin_iva_tua'] = $vueloCost['costo_escala'];

            // Sumar IVA y TUA al costo directo
            $vueloCost['costo_directo'] += ($vueloCost['iva'] + $vueloCost['tua']);

            // Sumar IVA y TUA al costo escala solo si no es 0.00
            if ($vueloCost['costo_escala'] != 0.00) {
                $vueloCost['costo_escala'] += ($vueloCost['iva'] + $vueloCost['tua']);
            }
        }
        unset($vueloCost);

        //Aplicar descuento a los costos directos o de escala 
        foreach ($vuelosFiltrados as &$vueloWithDesc) {
            // Restar el descuento a costo_directo y costo_escala
            $vueloWithDesc['costo_directo'] -= ($vueloWithDesc['costo_directo'] * ($descuento / 100));
            $vueloWithDesc['costo_escala'] -= ($vueloWithDesc['costo_escala'] * ($descuento / 100));
        }
        unset($vueloWithDesc);

        foreach ($vuelosFiltrados as &$vueloHoras) {
            //Ver cuantas horas se va llevar el vuelo en base a la hora salida y llegada
            $horaSalida = new DateTime($vueloHoras['hora_salida']);
            $horaLlegada = new DateTime($vueloHoras['hora_llegada']);

            // Calcular la diferencia
            $duracionVuelo = $horaSalida->diff($horaLlegada);

            // Formatear la duración en horas y minutos
            $vueloHoras['duracion'] = $duracionVuelo->h . ' horas ' . $duracionVuelo->i . ' minutos';
        }
        unset($vueloHoras);
        foreach ($vuelosFiltrados as &$formatHrs) {
            $formatHrs['hora_salida_format'] = (new DateTime($formatHrs['hora_salida']))->format('H:i');
            $formatHrs['hora_llegada_format'] = (new DateTime($formatHrs['hora_llegada']))->format('H:i');
        }
        unset($formatHrs);


        // Mostrar la cantidad de pasajeros
        foreach ($vuelosFiltrados as &$pasajerosFlight) {
            $pasajeros = [];

            // Agregar la cantidad de adultos, menores y bebés a la descripción
            if ($adultos > 0) {
                $pasajeros[] = ($adultos > 1) ? "$adultos Adultos" : "1 Adulto";
            }
            if ($menores > 0) {
                $pasajeros[] = ($menores > 1) ? "$menores Menores" : "1 Menor";
            }
            if ($bebes > 0) {
                $pasajeros[] = ($bebes > 1) ? "$bebes Bebés" : "1 Bebé";
            }
            // Une las descripciones con una coma
            $pasajerosFlight['descripcion_pasajeros'] = implode(", ", $pasajeros);
        }
        unset($pasajerosFlight);


        // Buscar los nombres completos del origen y destino
        $vuelosData['full_origen'] = $destinosCompletos[$vuelosData['origen']] ?? $vuelosData['origen'];
        $vuelosData['full_destino'] = $destinosCompletos[$vuelosData['destino']] ?? $vuelosData['destino'];
        // Agregar los nombres completos al array final de vuelos
        foreach ($vuelosFiltrados as &$fullNameOD) {
            $fullNameOD['origen_full'] = $vuelosData['full_origen'];
            $fullNameOD['destino_full'] = $vuelosData['full_destino'];
        }
        unset($fullNameOD);


        // Validar regreso y formatear la fecha de regreso solo si es válida
        foreach ($vuelosFiltrados as &$flightRegreso) {
            // Verifica que no sea el mensaje 'Sin fecha de regreso'
            if ($vuelosData['regreso'] !== 'Sin fecha de regreso') {
                // Asigna la fecha de regreso y formatea solo si es una fecha válida
                $flightRegreso['fecha_regreso'] = $vuelosData['regreso'];
                $fechaRegresoDetails = new DateTime($flightRegreso['fecha_regreso']);
                $flightRegreso['fecha_regreso_detail'] = $fechaRegresoDetails->format('d M, Y');
            } else {
                // Si no hay fecha de regreso, puedes dejar el campo vacío o asignar un valor alternativo
                $flightRegreso['fecha_regreso_detail'] = 'Sin fecha de regreso';
                $flightRegreso['fecha_regreso'] = 0;
            }
        }
        unset($flightRegreso);


        // Obtener las fechas en el formato deseado
        foreach ($vuelosFiltrados as &$formatHrs) {
            // Convertir las fechas de salida y llegada
            $fechaSalida = new DateTime($formatHrs['fecha_salida']);
            $fechaLlegada = new DateTime($formatHrs['fecha_llegada']);
            // Formatear la fecha como "D, d M, Y" (por ejemplo: "Vie, 05 jul, 2024")
            $formatHrs['fecha_salida_detail'] = $fechaSalida->format('d M, Y');
            $formatHrs['fecha_llegada_detail'] = $fechaLlegada->format('d M, Y');
        }
        unset($formatHrs);

        //validar vuelos disponibles
        if (empty($vuelosFiltrados)) {
            // Establece una variable de control para indicar que no hay vuelos
            $noHayVuelos = true;
            require './views/departure_vuelos.php';
            return;
        }

        //var_dump($vuelosFiltrados);
        // Cargar la vista
        require './views/departure_vuelos.php';
    }























    public function findVuelosReturn()
    {
        // Obtener los vuelos de la API
        $vuelos = Vuelos::getAll();
        // Obtener los extras de la API
        $extras = Extras::getAllExtras();
        $destinosCarousel = DestinosController::getDestinosCarousel();
        // Obtener los destinos completos de la API
        $destinosCompletos = DestinosController::getDestinosCompletos();


        // Inicializa las variables individuales
        $tipo = $costo = $origen = $destino = $duracion = $hora_salida =
            $hora_llegada = $descripcion_pasajeros = $origen_full = $destino_full =
            $fecha_salida_detail = $fecha_regreso_detail = $fecha_salida = $fecha_regreso = null;

        // Verifica que los datos vengan por POST
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // Asigna cada dato a una variable individual
            $tipo = $_POST['tipo'] ?? null;
            $costo = $_POST['costo'] ?? null;
            $origen = $_POST['origen'] ?? null;
            $destino = $_POST['destino'] ?? null;
            $duracion = $_POST['duracion'] ?? null;
            $hora_salida = $_POST['hora_salida_format'] ?? null;
            $hora_llegada = $_POST['hora_llegada_format'] ?? null;
            $descripcion_pasajeros = $_POST['descripcion_pasajeros'] ?? null;
            $origen_full = $_POST['origen_full'] ?? null;
            $destino_full = $_POST['destino_full'] ?? null;
            $fecha_salida_detail = $_POST['fecha_salida_detail'] ?? null;
            $fecha_regreso_detail = $_POST['fecha_regreso_detail'] ?? null;
            $fecha_salida = $_POST['fecha_salida'] ?? null;
            $fecha_regreso = $_POST['fecha_regreso'] ?? null;
            $costo_directo = $_POST['costo_directo'] ?? null;
            $costo_escala = $_POST['costo_escala'] ?? null;
            $tua = $_POST['tua'] ?? null;
            $iva = $_POST['iva'] ?? null;
            $codigo_vuelo = $_POST['codigo_vuelo'] ?? null;
            $porcentaje_desc = $_POST['porcentaje_desc'] ?? null;
            $costo_directo_sin_iva_tua = $_POST['costo_directo_sin_iva_tua'] ?? null;
            $costo_escala_sin_iva_tua = $_POST['costo_escala_sin_iva_tua'] ?? null;
            $num_asientos = $_POST['num_asientos'] ?? null;
            $asientos_ocupados = $_POST['asientos_ocupados'] ?? null;
        }

        $dataVuelosSalida = [
            [
                'tipo' => $tipo,
                'costo' => $costo,
                'origen' => $origen,
                'destino' => $destino,
                'duracion' => $duracion,
                'hora_salida' => $hora_salida,
                'hora_llegada' => $hora_llegada,
                'descripcion_pasajeros' => $descripcion_pasajeros,
                'origen_full' => $origen_full,
                'destino_full' => $destino_full,
                'fecha_salida_detail' => $fecha_salida_detail,
                'fecha_regreso_detail' => $fecha_regreso_detail,
                'fecha_salida' => $fecha_salida,
                'fecha_regreso' => $fecha_regreso,
                'costo_directo' => $costo_directo,
                'costo_escala' => $costo_escala,
                'tua' => $tua,
                'iva' => $iva,
                'codigo_vuelo' => $codigo_vuelo,
                'porcentaje_desc' => $porcentaje_desc,
                'costo_directo_sin_iva_tua' => $costo_directo_sin_iva_tua,
                'costo_escala_sin_iva_tua' => $costo_escala_sin_iva_tua,
                'num_asientos' => $num_asientos,
                'asientos_ocupados' => $asientos_ocupados,

            ],
            // Más vuelos si es necesario
        ];




        // Filtrar vuelos de regreso basados en la fecha de regreso y destino
        $dataVuelosRegreso = array_filter($vuelos, function ($vuelo) use ($fecha_regreso, $destino, $origen) {
            return $vuelo['fecha_salida'] === $fecha_regreso &&
                $vuelo['destino'] === $origen &&
                $vuelo['origen']  === $destino;
        });


        // Guardar los costos originales antes de sumar IVA y TUA
        foreach ($dataVuelosRegreso as &$vueloCost) {
            // Guardar el costo directo y el costo escala sin IVA y TUA
            $vueloCost['costo_directo_base'] = $vueloCost['costo_directo'];
            $vueloCost['costo_escala_base'] = $vueloCost['costo_escala'];

            // Sumar IVA y TUA al costo directo
            $vueloCost['costo_directo'] += ($vueloCost['iva'] + $vueloCost['tua']);

            // Sumar IVA y TUA al costo escala solo si no es 0.00
            if ($vueloCost['costo_escala'] != 0.00) {
                $vueloCost['costo_escala'] += ($vueloCost['iva'] + $vueloCost['tua']);
            }
            // Aplicar descuento
            if ($porcentaje_desc != '') {
                $vueloCost['costo_directo'] -= ($vueloCost['costo_directo'] * ($porcentaje_desc / 100));
                $vueloCost['costo_escala'] -= ($vueloCost['costo_escala'] * ($porcentaje_desc / 100));
            }
        }
        unset($vueloCost);

        // mandar la cantidad de porcentaje
        foreach ($dataVuelosRegreso as &$desc) {
            $desc['porcentaje_desc'] = $porcentaje_desc;
        }
        unset($desc);





        // Calcular asientos libres y generar identificadores de asientos
        foreach ($dataVuelosSalida as &$asiento) {
            $asiento['asientos_libres'] = $asiento['num_asientos'];
            -$asiento['asientos_ocupados'];
            $fila = 1;
            $columna = 'A';
            $asiento['asientos_identificadores'] = [];

            for ($i = 0; $i < $asiento['num_asientos']; $i++) {
                // Generar identificador en formato `1A`, `1B`, `2C`, etc.
                $asiento['asientos_identificadores'][] = $fila . $columna;

                // Alternar entre columnas para formar el diseño deseado
                if ($columna === 'A') {
                    $columna = 'B';
                } elseif ($columna === 'B') {
                    $columna = 'C';
                } elseif ($columna === 'C') {
                    $columna = 'D';
                } elseif ($columna === 'D') {
                    $fila++;
                    $columna = 'A';
                }
            }
        }














        // calcular la duracion del vuelo de regreso
        foreach ($dataVuelosRegreso as &$vueloHoras) {
            //Ver cuantas horas se va llevar el vuelo en base a la hora salida y llegada
            $horaSalida = new DateTime($vueloHoras['hora_salida']);
            $horaLlegada = new DateTime($vueloHoras['hora_llegada']);

            // Calcular la diferencia
            $duracionVuelo = $horaSalida->diff($horaLlegada);

            // Formatear la duración en horas y minutos
            $vueloHoras['duracion'] = $duracionVuelo->h . ' horas ' . $duracionVuelo->i . ' minutos';
        }





        // cambiar formato de horas
        foreach ($dataVuelosRegreso as &$formatHrs) {
            $formatHrs['hora_salida_format'] = (new DateTime($formatHrs['hora_salida']))->format('H:i');
            $formatHrs['hora_llegada_format'] = (new DateTime($formatHrs['hora_llegada']))->format('H:i');
        }
        unset($formatHrs);

        // Mostrar  descripcion de la cantidad de pasajeros
        foreach ($dataVuelosRegreso as &$pasajerosFlight) {
            $pasajerosFlight['descripcion_pasajeros'] = $descripcion_pasajeros;
        }
        unset($pasajerosFlight);

        // Buscar los nombres completos del origen y destino
        foreach ($dataVuelosRegreso as &$nameFull) {
            $nameFull['origen_full'] = $origen_full;
            $nameFull['destino_full'] = $destino_full;
        }
        unset($nameFull);

        // Traer las fechas en formato completo
        foreach ($dataVuelosRegreso as &$fechasDetails) {
            $fechasDetails['fecha_salida_detail'] = $fecha_salida_detail;
            $fechasDetails['fecha_regreso_detail'] = $fecha_regreso_detail;
        }
        unset($fechasDetails);


        // Validar si hay regreso
        if ($fecha_regreso == 0) {
            // Redirigir a selección de asientos
            //var_dump('NO hay fecha de regreso del chavalo');
            //  var_dump($dataVuelosSalida);
            require './views/seat_vuelosSalida.php';
            return;
        }

        // Carga la vista y pasa cada variable individualmente
        //var_dump($dataVuelosRegreso);
        require './views/return_vuelos.php';
    }
















    //Seleccionar asientos de vuelos
    public function findVuelosSeat()
    {
        // Obtener los extras de la API
        $extras = Extras::getAllExtras();
        // Verifica que los datos vengan por POST
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // Asigna cada dato a una variable individual
            $tipo = $_POST['tipo'] ?? null;
            $costo = $_POST['costo'] ?? null;
            $origen = $_POST['origen'] ?? null;
            $destino = $_POST['destino'] ?? null;
            $duracion = $_POST['duracion'] ?? null;
            $hora_salida_format = $_POST['hora_salida_format'] ?? null;
            $hora_llegada_format = $_POST['hora_llegada_format'] ?? null;
            $descripcion_pasajeros = $_POST['descripcion_pasajeros'] ?? null;
            $origen_full = $_POST['origen_full'] ?? null;
            $destino_full = $_POST['destino_full'] ?? null;
            $fecha_salida_detail = $_POST['fecha_salida_detail'] ?? null;
            $fecha_regreso_detail = $_POST['fecha_regreso_detail'] ?? null;
            $fecha_salida = $_POST['fecha_salida'] ?? null;
            $costo_directo_base = $_POST['costo_directo_base'] ?? null;
            $costo_escala_base = $_POST['costo_escala_base'] ?? null;
            $tua = $_POST['tua'] ?? null;
            $iva = $_POST['iva'] ?? null;
            $codigo_vuelo = $_POST['codigo_vuelo'] ?? null;
            $porcentaje_desc = $_POST['porcentaje_desc'] ?? null;
        }

        $dataVuelosRegreso = [
            [
                'tipo' => $tipo,
                'costo' => $costo,
                'origen' => $origen,
                'destino' => $destino,
                'duracion' => $duracion,
                'hora_salida_format' => $hora_salida_format,
                'hora_llegada_format' => $hora_llegada_format,
                'descripcion_pasajeros' => $descripcion_pasajeros,
                'origen_full' => $origen_full,
                'destino_full' => $destino_full,
                'fecha_salida_detail' => $fecha_salida_detail,
                'fecha_regreso_detail' => $fecha_regreso_detail,
                'fecha_salida' => $fecha_salida,
                'costo_directo_base' => $costo_directo_base,
                'costo_escala_base' => $costo_escala_base,
                'tua' => $tua,
                'iva' => $iva,
                'codigo_vuelo' => $codigo_vuelo,
                'porcentaje_desc' => $porcentaje_desc,

            ],
            // Más vuelos si es necesario
        ];


        $dataVuelosSalida = json_decode($_POST['dataVuelosSalida'], true);


        // echo "<pre>Salida - Data Vuelos Salida:</pre>";
        // var_dump($dataVuelosSalida);

        // echo "<pre>Salida - Data Vuelos Regreso:</pre>";
        // var_dump($dataVuelosRegreso);
        //var_dump($dataVuelosSalida);
        require './views/seat_vuelos.php';
    }




    //Formulario de pago
    public function payVuelos()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $selectedSeat = $_POST['selectedSeat'] ?? null;
            $codigo_vuelo = $_POST['codigo_vuelo'] ?? null;
            $totalGlobal = $_POST['totalGlobal'] ?? null;
            $tua = $_POST['tua'] ?? null;
            $iva = $_POST['iva'] ?? null;
            $costo = $_POST['costo'] ?? null;
            $costo_escala_sin_iva_tua = $_POST['costo_escala_sin_iva_tua'] ?? null;
            $costo_directo_sin_iva_tua = $_POST['costo_directo_sin_iva_tua'] ?? null;
            $porcentaje_desc = $_POST['porcentaje_desc'] ?? null;
            $tipo = $_POST['tipo'] ?? null;
            $fecha_salida_detail = $_POST['fecha_salida_detail'] ?? null;
            $fecha_regreso_detail = $_POST['fecha_regreso_detail'] ?? null;
            $hora_salida = $_POST['hora_salida'] ?? null;
            $hora_llegada = $_POST['hora_llegada'] ?? null;
            $origen = $_POST['origen'] ?? null;
            $destino = $_POST['destino'] ?? null;
            $descripcion_pasajeros = $_POST['descripcion_pasajeros'] ?? null;
            $selectedExtras = json_decode($_POST['selectedExtras'], true);

            // Depuración
            // var_dump($totalGlobal);
            // var_dump($selectedExtras);
        }

        $dataVuelosSalida = [
            [
                'selectedSeat' => $selectedSeat,
                'codigo_vuelo' => $codigo_vuelo,
                'totalGlobal' => $totalGlobal,
                'tua' => $tua,
                'iva' => $iva,
                'costo' => $costo,
                'costo_escala_sin_iva_tua' => $costo_escala_sin_iva_tua,
                'costo_directo_sin_iva_tua' => $costo_directo_sin_iva_tua,
                'porcentaje_desc' => $porcentaje_desc,
                'tipo' => $tipo,
                'selectedSeat' => $selectedSeat,
                'fecha_salida_detail' => $fecha_salida_detail,
                'fecha_regreso_detail' => $fecha_regreso_detail,
                'hora_salida' => $hora_salida,
                'hora_llegada' => $hora_llegada,
                'origen' => $origen,
                'destino' => $destino,
                'descripcion_pasajeros' => $descripcion_pasajeros,
                'selectedExtras' => $selectedExtras,

            ],
        ];
        //var_dump($dataVuelosSalida);
        require './views/pago_vuelos.php';
        //require './views/boleto.php';
        //require './views/email.php';
    }






    public function reserva()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // Incluir el archivo de configuración
            require_once './config/config.php';

            // Obtener los datos del formulario
            $nombres = $_POST['nombres'] ?? null;
            $apellidos = $_POST['apellidos'] ?? null;
            $genero = $_POST['genero'] ?? null;
            $nacionalidad = $_POST['nacionalidad'] ?? null;
            $fechaNacimiento = $_POST['fechaNacimiento'] ?? null;
            $nombres_contact_pasajero = $_POST['nombres_contact_pasajero'] ?? null;
            $apellidos_contact_pasajero = $_POST['apellidos_contact_pasajero'] ?? null;
            $email = $_POST['email'] ?? null;
            $countryCode = $_POST['countryCode'] ?? null;
            $telefono_contact = $_POST['telefono_contact'] ?? null;
            $selectedSeat = $_POST['selectedSeat'] ?? null;
            $codigo_vuelo = $_POST['codigo_vuelo'] ?? null;
            $totalGlobal = $_POST['totalGlobal'] ?? null;
            $tua = $_POST['tua'] ?? null;
            $iva = $_POST['iva'] ?? null;
            $costo = $_POST['costo'] ?? null;
            $costo_escala_sin_iva_tua = $_POST['costo_escala_sin_iva_tua'] ?? null;
            $costo_directo_sin_iva_tua = $_POST['costo_directo_sin_iva_tua'] ?? null;
            $porcentaje_desc = $_POST['porcentaje_desc'] ?? null;
            $tipo = $_POST['tipo'] ?? null;
            $fecha_salida_detail = $_POST['fecha_salida_detail'] ?? null;
            $fecha_regreso_detail = $_POST['fecha_regreso_detail'] ?? null;
            $hora_salida = $_POST['hora_salida'] ?? null;
            $hora_llegada = $_POST['hora_llegada'] ?? null;
            $origen = $_POST['origen'] ?? null;
            $destino = $_POST['destino'] ?? null;
            $descripcion_pasajeros = $_POST['descripcion_pasajeros'] ?? null;

            $selectedExtrasDescriptions = $_POST['selectedExtras']['description'] ?? [];
            $selectedExtrasCosts = $_POST['selectedExtras']['cost'] ?? [];
            $selectedExtras = [];

            foreach ($selectedExtrasDescriptions as $index => $description) {
                $selectedExtras[] = [
                    'description' => $description,
                    'cost' => $selectedExtrasCosts[$index] ?? 0
                ];
            }

            // Generar códigos únicos
            $codigo_reserva = strtoupper(bin2hex(random_bytes(3))); // Código de 6 caracteres alfanuméricos
            $codigo_boleto = str_pad(random_int(0, 99999999999), 11, '0', STR_PAD_LEFT); // Código de 11 dígitos

            try {
                // Preparar la consulta SQL
                $query = "INSERT INTO reserva (
                codigo_reserva, nombres, apellidos, genero, nacionalidad, fecha_nacimiento,
                nombres_contact_pasajero, apellidos_contact_pasajero, email, country_code, telefono_contact,
                selected_seat, codigo_vuelo, total_global, tua, iva, costo, 
                costo_escala_sin_iva_tua, costo_directo_sin_iva_tua, porcentaje_desc, 
                tipo, fecha_salida_detail, fecha_regreso_detail, hora_salida, hora_llegada, 
                origen, destino, descripcion_pasajeros, estatus, codigo_boleto
            ) VALUES (
                :codigo_reserva, :nombres, :apellidos, :genero, :nacionalidad, :fecha_nacimiento,
                :nombres_contact_pasajero, :apellidos_contact_pasajero, :email, :country_code, :telefono_contact,
                :selected_seat, :codigo_vuelo, :total_global, :tua, :iva, :costo, 
                :costo_escala_sin_iva_tua, :costo_directo_sin_iva_tua, :porcentaje_desc, 
                :tipo, :fecha_salida_detail, :fecha_regreso_detail, :hora_salida, :hora_llegada, 
                :origen, :destino, :descripcion_pasajeros, 1, :codigo_boleto
            )";

                // Preparar la declaración
                $stmt = $pdo->prepare($query);

                // Vincular parámetros
                $stmt->bindParam(':codigo_reserva', $codigo_reserva);
                $stmt->bindParam(':nombres', $nombres);
                $stmt->bindParam(':apellidos', $apellidos);
                $stmt->bindParam(':genero', $genero);
                $stmt->bindParam(':nacionalidad', $nacionalidad);
                $stmt->bindParam(':fecha_nacimiento', $fechaNacimiento);
                $stmt->bindParam(':nombres_contact_pasajero', $nombres_contact_pasajero);
                $stmt->bindParam(':apellidos_contact_pasajero', $apellidos_contact_pasajero);
                $stmt->bindParam(':email', $email);
                $stmt->bindParam(':country_code', $countryCode);
                $stmt->bindParam(':telefono_contact', $telefono_contact);
                $stmt->bindParam(':selected_seat', $selectedSeat);
                $stmt->bindParam(':codigo_vuelo', $codigo_vuelo);
                $stmt->bindParam(':total_global', $totalGlobal);
                $stmt->bindParam(':tua', $tua);
                $stmt->bindParam(':iva', $iva);
                $stmt->bindParam(':costo', $costo);
                $stmt->bindParam(':costo_escala_sin_iva_tua', $costo_escala_sin_iva_tua);
                $stmt->bindParam(':costo_directo_sin_iva_tua', $costo_directo_sin_iva_tua);
                $stmt->bindParam(':porcentaje_desc', $porcentaje_desc);
                $stmt->bindParam(':tipo', $tipo);
                $stmt->bindParam(':fecha_salida_detail', $fecha_salida_detail);
                $stmt->bindParam(':fecha_regreso_detail', $fecha_regreso_detail);
                $stmt->bindParam(':hora_salida', $hora_salida);
                $stmt->bindParam(':hora_llegada', $hora_llegada);
                $stmt->bindParam(':origen', $origen);
                $stmt->bindParam(':destino', $destino);
                $stmt->bindParam(':descripcion_pasajeros', $descripcion_pasajeros);
                $stmt->bindParam(':codigo_boleto', $codigo_boleto);

                // Ejecutar la consulta
                if ($stmt->execute()) {
                    echo "Reserva guardada con éxito.";
                } else {
                    echo "Error al guardar la reserva.";
                }
            } catch (PDOException $e) {
                echo "Error: " . $e->getMessage();
            }

            // Preparar datos para mostrar o redirigir a una vista
            $dataVuelosSalida = [
                [
                    'codigo_reserva' => $codigo_reserva,
                    'codigo_boleto' => $codigo_boleto,
                    'nombres' => $nombres,
                    'apellidos' => $apellidos,
                    'selectedExtras' => $selectedExtras,
                    // Otros datos relevantes...
                ],
            ];

            // require './views/admin_create.php';
            var_dump($dataVuelosSalida);

            
        }
    }















    /*  public function create() {
        require './views/admin_create.php';
    }

    public function store() {
        Admin::create($_POST);
        header('Location: index.php?controller=admin&action=index');
    }
    
    public function edit($id) {
        $admins = Admin::getAll();
        $admin = $admins[$id];
        require './views/admin_edit.php';
    }

    public function update($id) {
        Admin::update($id, $_POST);
        header('Location: index.php?controller=admin&action=index');
    }

    public function destroy($id) {
        Admin::delete($id);
        header('Location: index.php?controller=admin&action=index');
    }
    */
}
