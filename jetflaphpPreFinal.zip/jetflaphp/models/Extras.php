<?php
require_once './config/api_url.php';

class Extras
{
    public static function getAllExtras()
    {
        $response = file_get_contents(GET_EXTRAS_API);
        return json_decode($response, true);
    }
    
}
