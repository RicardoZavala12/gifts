<?php
require_once './config/api_url.php';

class Pasajero
{
    public static function getAll()
    {
        $response = file_get_contents(GET_PASAJERO_API);
        return json_decode($response, true);
    }

    public static function create($data)
    {
        $options = [
            'http' => [
                'header'  => "Content-type: application/json\r\n",
                'method'  => 'POST',
                'content' => json_encode($data),
            ],
        ];
        $context = stream_context_create($options);
        $response = file_get_contents(GET_PASAJERO_API, false, $context);
        return json_decode($response, true);
    }
}
