<?php

require_once './models/Pasajeros.php';

class LoginController
{
    public function showLoginForm()
    {
        $this->logout();
        require './views/404.php';
    }

    public function login()
    {
        $email = $_POST['email'];
        $password = $_POST['pass'];
        $pasajeros = Pasajero::getAll();

        session_start();
        foreach ($pasajeros as $pasajero) {
            if ($pasajero['email'] == $email && $pasajero['password'] == $password) {
                $_SESSION['admin_logged_in'] = true;
                header('Location: index.php?controller=home&action=index');
                exit();
            }
        }

        $_SESSION['login_attempt_failed'] = true;
        header('Location: index.php?controller=login&action=showLoginForm&error=invalid_credentials');
        exit();
    }

    public function register()
    {
        // Datos de registro obtenidos del formulario
        $data = [
            'nombre' => $_POST['username'],
            'apellidos' => $_POST['lastname'],
            'email' => $_POST['email'],
            'telefono' => $_POST['number'],
            'password' => $_POST['password']
        ];

        // Llama al método de creación en el modelo Admin
        $result = Pasajero::create($data);

        if ($result) {
            header('Location: index.php?controller=login&action=showLoginForm&success=registered');
        } else {
            header('Location: index.php?controller=login&action=showLoginForm&error=registration_failed');
        }
        exit();
    }

    public function logout()
    {
        if (session_status() == PHP_SESSION_NONE) {
            session_start();
        }
        session_unset();
        session_destroy();
    }
}
