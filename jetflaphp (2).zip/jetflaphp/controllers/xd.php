<?php
class MiControlador
{
    private $miArray;
    // Constructor para inicializar $miArray
    public function __construct($arrayInicial)
    {
        $this->miArray = $arrayInicial;
    }



    public function funcionA()
    {
        foreach ($this->miArray as $elemento) {
            echo "Desde funcionA: " . $elemento . "<br>";
        }
    }


    public function funcionB()
    {
        foreach ($this->miArray as $elemento) {
            echo "Desde funcionB: " . $elemento . "<br>";
        }
    }
}
// Crear una instancia de MiControlador pasando el array inicial
$controlador = new MiControlador($miArray);
// Llamar a las funciones que usan el array
$controlador->funcionA();
$controlador->funcionB();


//O podes asignarle una una función para estar cambiando el valor del arreglo cuantas veces quieras:
class MiControlador
{
    private $miArray;
    public function __construct()
    {
        $this->miArray = []; // Inicializar el array como vacío
    }
    // Función para asignar un valor global a $miArray
    public function asignarArray($nuevoArray)
    {
        $this->miArray = $nuevoArray;
    }
    public function funcionA()
    {
        // Aquí puedes usar $miArray ya asignado globalmente
        foreach ($this->miArray as $elemento) {
            echo "Desde funcionA: " . $elemento . "<br>";
        }
    }
    public function funcionB()
    {
        // Aquí también puedes usar $miArray ya asignado globalmente
        foreach ($this->miArray as $elemento) {
            echo "Desde funcionB: " . $elemento . "<br>";
        }
    }
}
// Crear una instancia de MiControlador
$controlador = new MiControlador();
// Asignar un valor global al array
$controlador->asignarArray(['elemento1', 'elemento2', 'elemento3']);
// Llamar a las funciones que usan el array globalmente
$controlador->funcionA();
$controlador->funcionB();
