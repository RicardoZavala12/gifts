<?php
require_once './models/Vuelos.php';
require_once 'DestinosController.php';
require_once 'HomeController.php';


class VuelosController
{

    //Seleccionar vuelos salida
    public function index()
    {
        $destinosCarousel = DestinosController::getDestinosCarousel();
        require './views/departure_vuelos.php';
    }

    public function findVuelos()
    {
        // Obtener los vuelos de la API
        $vuelos = Vuelos::getAll();
        // Obtener los codigos promo de la API
        $codPromoAPI = Vuelos::getAllCodigosPromos();
        // Obtener los destinos completos de la API
        $destinosCompletos = DestinosController::getDestinosCompletos();
        // Obtener los img de destinos de la API
        $destinosCarousel = DestinosController::getDestinosCarousel();

        $origen = $_POST['origen'];
        $destino = $_POST['destino'];
        $salida = $_POST['salida'];
        $regreso = isset($_POST['regreso']) ? $_POST['regreso'] : 'Sin fecha de regreso';
        $codigoPromo = $_POST['codigoPromo'];

        // Verificar que `passengerData` está presente y no es nulo
        $passengerData = isset($_POST['passengerData']) ? json_decode($_POST['passengerData'], true) : null;

        $adultos = $passengerData['adult'] ?? 0;
        $menores = $passengerData['child'] ?? 0;
        $bebes = $passengerData['infant'] ?? 0;

        $vuelosData = [
            'origen' => $origen,
            'destino' => $destino,
            'salida' => $salida,
            'regreso' => $regreso,
            'codigoPromo' => $codigoPromo,
            'adultos' => $adultos,
            'menores' => $menores,
            'bebes' => $bebes
        ];

        $codigosActivos = array_filter($codPromoAPI, function ($codigo) {
            return $codigo['estado'] == 1; // Filtra solo los códigos que estén activos
        });

        // Buscar el código promocional específico en los códigos activos
        $codigoEncontrado = array_filter($codigosActivos, function ($codigo) use ($codigoPromo) {
            return $codigo['codigo'] === $codigoPromo; // Filtrar por el atributo 'codigo'
        });

        // Obtener el descuento si se encuentra el código
        $descuento = !empty($codigoEncontrado) ? reset($codigoEncontrado)['descuento'] : null;

        $vuelosFiltrados = array_filter($vuelos, function ($vueloDesc) use ($vuelosData) {
            return $vueloDesc['origen'] === $vuelosData['origen'] &&
                $vueloDesc['destino'] === $vuelosData['destino'] &&
                $vueloDesc['fecha_salida'] === $vuelosData['salida'];
        });

        // mandar la cantidad de porcentaje
        foreach ($vuelosFiltrados as &$desc) {
            $desc['porcentaje_desc'] = $descuento;
        }
        unset($desc);


        // Guardar los costos originales antes de sumar IVA y TUA
        foreach ($vuelosFiltrados as &$vueloCost) {
            // Guardar el costo directo y el costo escala sin IVA y TUA
            $vueloCost['costo_directo_sin_iva_tua'] = $vueloCost['costo_directo'];
            $vueloCost['costo_escala_sin_iva_tua'] = $vueloCost['costo_escala'];

            // Sumar IVA y TUA al costo directo
            $vueloCost['costo_directo'] += ($vueloCost['iva'] + $vueloCost['tua']);

            // Sumar IVA y TUA al costo escala solo si no es 0.00
            if ($vueloCost['costo_escala'] != 0.00) {
                $vueloCost['costo_escala'] += ($vueloCost['iva'] + $vueloCost['tua']);
            }
        }
        unset($vueloCost);

        //Aplicar descuento a los costos directos o de escala 
        foreach ($vuelosFiltrados as &$vueloWithDesc) {
            // Restar el descuento a costo_directo y costo_escala
            $vueloWithDesc['costo_directo'] -= ($vueloWithDesc['costo_directo'] * ($descuento / 100));
            $vueloWithDesc['costo_escala'] -= ($vueloWithDesc['costo_escala'] * ($descuento / 100));
        }
        unset($vueloWithDesc);

        foreach ($vuelosFiltrados as &$vueloHoras) {
            //Ver cuantas horas se va llevar el vuelo en base a la hora salida y llegada
            $horaSalida = new DateTime($vueloHoras['hora_salida']);
            $horaLlegada = new DateTime($vueloHoras['hora_llegada']);

            // Calcular la diferencia
            $duracionVuelo = $horaSalida->diff($horaLlegada);

            // Formatear la duración en horas y minutos
            $vueloHoras['duracion'] = $duracionVuelo->h . ' horas ' . $duracionVuelo->i . ' minutos';
        }
        unset($vueloHoras);
        foreach ($vuelosFiltrados as &$formatHrs) {
            $formatHrs['hora_salida_format'] = (new DateTime($formatHrs['hora_salida']))->format('H:i');
            $formatHrs['hora_llegada_format'] = (new DateTime($formatHrs['hora_llegada']))->format('H:i');
        }
        unset($formatHrs);


        // Mostrar la cantidad de pasajeros
        foreach ($vuelosFiltrados as &$pasajerosFlight) {
            $pasajeros = [];

            // Agregar la cantidad de adultos, menores y bebés a la descripción
            if ($adultos > 0) {
                $pasajeros[] = ($adultos > 1) ? "$adultos Adultos" : "1 Adulto";
            }
            if ($menores > 0) {
                $pasajeros[] = ($menores > 1) ? "$menores Menores" : "1 Menor";
            }
            if ($bebes > 0) {
                $pasajeros[] = ($bebes > 1) ? "$bebes Bebés" : "1 Bebé";
            }
            // Une las descripciones con una coma
            $pasajerosFlight['descripcion_pasajeros'] = implode(", ", $pasajeros);
        }
        unset($pasajerosFlight);


        // Buscar los nombres completos del origen y destino
        $vuelosData['full_origen'] = $destinosCompletos[$vuelosData['origen']] ?? $vuelosData['origen'];
        $vuelosData['full_destino'] = $destinosCompletos[$vuelosData['destino']] ?? $vuelosData['destino'];
        // Agregar los nombres completos al array final de vuelos
        foreach ($vuelosFiltrados as &$fullNameOD) {
            $fullNameOD['origen_full'] = $vuelosData['full_origen'];
            $fullNameOD['destino_full'] = $vuelosData['full_destino'];
        }
        unset($fullNameOD);


        // Validar regreso y formatear la fecha de regreso solo si es válida
        foreach ($vuelosFiltrados as &$flightRegreso) {
            // Verifica que no sea el mensaje 'Sin fecha de regreso'
            if ($vuelosData['regreso'] !== 'Sin fecha de regreso') {
                // Asigna la fecha de regreso y formatea solo si es una fecha válida
                $flightRegreso['fecha_regreso'] = $vuelosData['regreso'];
                $fechaRegresoDetails = new DateTime($flightRegreso['fecha_regreso']);
                $flightRegreso['fecha_regreso_detail'] = $fechaRegresoDetails->format('d M, Y');
            } else {
                // Si no hay fecha de regreso, puedes dejar el campo vacío o asignar un valor alternativo
                $flightRegreso['fecha_regreso_detail'] = 'Sin fecha de regreso';
                $flightRegreso['fecha_regreso'] = 0;
            }
        }
        unset($flightRegreso);


        // Obtener las fechas en el formato deseado
        foreach ($vuelosFiltrados as &$formatHrs) {
            // Convertir las fechas de salida y llegada
            $fechaSalida = new DateTime($formatHrs['fecha_salida']);
            $fechaLlegada = new DateTime($formatHrs['fecha_llegada']);
            // Formatear la fecha como "D, d M, Y" (por ejemplo: "Vie, 05 jul, 2024")
            $formatHrs['fecha_salida_detail'] = $fechaSalida->format('d M, Y');
            $formatHrs['fecha_llegada_detail'] = $fechaLlegada->format('d M, Y');
        }
        unset($formatHrs);

        //validar vuelos disponibles
        if (empty($vuelosFiltrados)) {
            // Establece una variable de control para indicar que no hay vuelos
            $noHayVuelos = true;
            require './views/departure_vuelos.php';
            return;
        }

        //var_dump($vuelosFiltrados);
        // Cargar la vista
        require './views/departure_vuelos.php';
        return $vuelosFiltrados;
    }



    public function findVuelosReturn()
    {
        // Obtener los vuelos de la API
        $vuelos = Vuelos::getAll();
        $destinosCarousel = DestinosController::getDestinosCarousel();

        // Inicializa las variables individuales
        $tipo = $costo = $origen = $destino = $duracion = $hora_salida =
            $hora_llegada = $descripcion_pasajeros = $origen_full = $destino_full =
            $fecha_salida_detail = $fecha_regreso_detail = $fecha_salida = $fecha_regreso = null;

        // Verifica que los datos vengan por POST
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // Asigna cada dato a una variable individual
            $tipo = $_POST['tipo'] ?? null;
            $costo = $_POST['costo'] ?? null;
            $origen = $_POST['origen'] ?? null;
            $destino = $_POST['destino'] ?? null;
            $duracion = $_POST['duracion'] ?? null;
            $hora_salida = $_POST['hora_salida_format'] ?? null;
            $hora_llegada = $_POST['hora_llegada_format'] ?? null;
            $descripcion_pasajeros = $_POST['descripcion_pasajeros'] ?? null;
            $origen_full = $_POST['origen_full'] ?? null;
            $destino_full = $_POST['destino_full'] ?? null;
            $fecha_salida_detail = $_POST['fecha_salida_detail'] ?? null;
            $fecha_regreso_detail = $_POST['fecha_regreso_detail'] ?? null;
            $fecha_salida = $_POST['fecha_salida'] ?? null;
            $fecha_regreso = $_POST['fecha_regreso'] ?? null;
            $costo_directo = $_POST['costo_directo'] ?? null;
            $costo_escala = $_POST['costo_escala'] ?? null;
            $tua = $_POST['tua'] ?? null;
            $iva = $_POST['iva'] ?? null;
            $codigo_vuelo = $_POST['codigo_vuelo'] ?? null;
            $porcentaje_desc = $_POST['porcentaje_desc'] ?? null;
            $costo_directo_sin_iva_tua = $_POST['costo_directo_sin_iva_tua'] ?? null;
            $costo_escala_sin_iva_tua = $_POST['costo_escala_sin_iva_tua'] ?? null;
        }

        $dataVuelosSalida = [
            [
                'tipo' => $tipo,
                'costo' => $costo,
                'origen' => $origen,
                'destino' => $destino,
                'duracion' => $duracion,
                'hora_salida' => $hora_salida,
                'hora_llegada' => $hora_llegada,
                'descripcion_pasajeros' => $descripcion_pasajeros,
                'origen_full' => $origen_full,
                'destino_full' => $destino_full,
                'fecha_salida_detail' => $fecha_salida_detail,
                'fecha_regreso_detail' => $fecha_regreso_detail,
                'fecha_salida' => $fecha_salida,
                'fecha_regreso' => $fecha_regreso,
                'costo_directo' => $costo_directo,
                'costo_escala' => $costo_escala,
                'tua' => $tua,
                'iva' => $iva,
                'codigo_vuelo' => $codigo_vuelo,
                'porcentaje_desc' => $porcentaje_desc,
                'costo_directo_sin_iva_tua' => $costo_directo_sin_iva_tua,
                'costo_escala_sin_iva_tua' => $costo_escala_sin_iva_tua,

            ],
            // Más vuelos si es necesario
        ];


        
        // Filtrar vuelos de regreso basados en la fecha de regreso y destino
        $dataVuelosRegreso = array_filter($vuelos, function ($vuelo) use ($fecha_regreso, $destino, $origen) {
            return $vuelo['fecha_salida'] === $fecha_regreso && 
                   $vuelo['destino'] === $destino &&
                   $vuelo['origen']  === $origen;
        });

















        


        // Validar si hay regreso
        if ($fecha_regreso == 0) {
            // Redirigir a selección de asientos
            var_dump('NO hay fecha de regreso del chavalo');
            //require './views/seat_vuelos.php';
            return;
        }

        // Carga la vista y pasa cada variable individualmente
        var_dump($dataVuelosRegreso);
        //require './views/return_vuelos.php';
    }
















    //$faces = Face::getAll();

    //Seleccionar vuelos regreso
    public function in_vuelos()
    {
        require './views/in_vuelos.php';
    }
    //$faces = Face::getAll();


    /*  public function create() {
        require './views/admin_create.php';
    }

    public function store() {
        Admin::create($_POST);
        header('Location: index.php?controller=admin&action=index');
    }
    
    public function edit($id) {
        $admins = Admin::getAll();
        $admin = $admins[$id];
        require './views/admin_edit.php';
    }

    public function update($id) {
        Admin::update($id, $_POST);
        header('Location: index.php?controller=admin&action=index');
    }

    public function destroy($id) {
        Admin::delete($id);
        header('Location: index.php?controller=admin&action=index');
    }
    */
}
