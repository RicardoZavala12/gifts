<?php
require_once './config/api_url.php';

class Destino
{
    public static function getAll()
    {
        $response = file_get_contents(GET_DESTINOS_API);
        return json_decode($response, true);
    }

    public static function getAllImg()
    {
        $response = file_get_contents(GET_DESTINOS_NUEVOS_API);
        return json_decode($response, true);
    }

}
