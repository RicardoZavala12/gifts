<?php
require_once './config/api_url.php';

class Vuelos
{
    public static function getAll()
    {
        $response = file_get_contents(GET_VUELOS_API);
        return json_decode($response, true);
    }
    
    public static function getAllCodigosPromos()
    {
        $response = file_get_contents(GET_CODIGOS_PROMOS_API);
        return json_decode($response, true);
    }



}
