function toggleDropdown() {
    const dropdown = document.getElementById('dropdown-content');
    dropdown.style.display = dropdown.style.display === 'none' || dropdown.style.display === '' ? 'block' : 'none';
}

// Función para inicializar los valores por defecto
function initializePassengerCounts() {
    const adultInput = document.getElementById('adult');
    const childInput = document.getElementById('child');
    const infantInput = document.getElementById('infant');

    // Inicializamos el número de adultos en 1 si no está configurado
    if (parseInt(adultInput.value) === 0) {
        adultInput.value = 1;
    }

    // Aseguramos que los valores de niños y bebés estén inicializados
    if (parseInt(childInput.value) === NaN) {
        childInput.value = 0;
    }
    if (parseInt(infantInput.value) === NaN) {
        infantInput.value = 0;
    }

    updateSelectedPassengersText();
}

// Función para cerrar el dropdown y actualizar el texto de los pasajeros
function closeDropdown() {
    const dropdown = document.getElementById('dropdown-content');
    dropdown.style.display = 'none';
    updateSelectedPassengersText();
}

// Función para actualizar la cantidad de pasajeros
function updatePassengerCount(type, change) {
    const adultInput = document.getElementById('adult');
    const childInput = document.getElementById('child');
    const infantInput = document.getElementById('infant');

    let adultCount = parseInt(adultInput.value);
    let childCount = parseInt(childInput.value);
    let infantCount = parseInt(infantInput.value);

    if (type === 'adult') {
        adultCount = Math.max(1, adultCount + change);
        adultInput.value = adultCount;
    } else if (type === 'child') {
        childCount = Math.max(0, childCount + change);
        childInput.value = childCount;
        if (childCount > 0 && adultCount === 0) {
            adultCount = 1;
            adultInput.value = adultCount;
        }
    } else if (type === 'infant') {
        infantCount = Math.max(0, infantCount + change);
        infantInput.value = infantCount;
        if (infantCount > 0 && adultCount === 0) {
            adultCount = 1;
            adultInput.value = adultCount;
        }
    }

    updateSelectedPassengersText();
}

// Función para actualizar el texto de la selección de pasajeros
function updateSelectedPassengersText() {
    const adultCount = parseInt(document.getElementById('adult').value);
    const childCount = parseInt(document.getElementById('child').value);
    const infantCount = parseInt(document.getElementById('infant').value);

    let text = 'Seleccionar';

    if (adultCount > 0) {
        text = `${adultCount} Adulto${adultCount > 1 ? 's' : ''}`;
    }
    if (adultCount > 0 && childCount > 0) {
        text = `${adultCount} Adulto${adultCount > 1 ? 's' : ''}, ${childCount} Menor${childCount > 1 ? 'es' : ''}`;
    }
    if (adultCount > 0 && infantCount > 0) {
        text = `${adultCount} Adulto${adultCount > 1 ? 's' : ''}, ${infantCount} Bebé${infantCount > 1 ? 's' : ''}`;
    }
    if (adultCount > 0 && childCount > 0 && infantCount > 0) {
        text = `${adultCount} Adulto${adultCount > 1 ? 's' : ''}, ${childCount} Menor${childCount > 1 ? 'es' : ''}, ${infantCount} Bebé${infantCount > 1 ? 's' : ''}`;
    }

    document.getElementById('selected-passengers').innerText = text;
}

// Llamar a la función de inicialización cuando se cargue la página
window.onload = function() {
    initializePassengerCounts();
};