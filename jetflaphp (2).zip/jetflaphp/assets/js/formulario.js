// Obtener la fecha de hoy
let today = new Date();
let dd = String(today.getDate()).padStart(2, '0');
let mm = String(today.getMonth() + 1).padStart(2, '0'); // Enero es 0
let yyyy = today.getFullYear();

// Formatear la fecha de hoy en el formato adecuado para el input date
let todayFormatted = yyyy + '-' + mm + '-' + dd;

// Establecer la fecha de hoy en el campo de salida
document.getElementById('salida').value = todayFormatted;

// Calcular la fecha de regreso (3 días después)
let returnDate = new Date();
returnDate.setDate(today.getDate() + 3);
let returnDd = String(returnDate.getDate()).padStart(2, '0');
let returnMm = String(returnDate.getMonth() + 1).padStart(2, '0');
let returnYyyy = returnDate.getFullYear();

// Formatear la fecha de regreso en el formato adecuado para el input date
let returnDateFormatted = returnYyyy + '-' + returnMm + '-' + returnDd;

// Establecer la fecha de regreso en el campo correspondiente
document.getElementById('regreso').value = returnDateFormatted;