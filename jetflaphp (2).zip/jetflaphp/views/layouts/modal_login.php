<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg" style="max-width: 500px;">
        <div class="modal-content" style="background: rgba(255, 255, 255, 0.1); backdrop-filter: blur(10px); border-radius: 12px;">
            <div class="modal-header">
                <h5 class="modal-title" id="modalTitle" style="color: white; text-align: center">Iniciar sesión</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <!-- Formulario de inicio de sesión -->
            <div id="loginForm" style="display: flex; flex-direction: column; align-items: center;">
                <form action="index.php?controller=login&action=login" method="POST" id="formParte1" style="color: white; display: flex; flex-direction: column; align-items: center;"><br>
                    <div class="row mb-3" title="Email del administrador">
                        <div class="col-sm-5" style="width: 100%;">
                            <input type="email" class="form-control" name="email" id="email" placeholder="Email address" required style="background: rgba(255, 255, 255, 0.5); color: black;">
                        </div>
                    </div>
                    <div class="row mb-3" title="Contraseña">
                        <div class="col-sm-5" style="width: 100%;">
                            <input type="password" class="form-control" name="pass" placeholder="Contraseña" id="pass" required style="background: rgba(255, 255, 255, 0.5); color: black;">
                        </div>
                    </div>
                    <p style="color: white; text-align: center;">¿No tienes cuenta? <a href="#" style="color: #00aaff;" onclick="toggleForms()">Regístrate</a></p>
                    <button style="color: white; background-color: #262E55" type="submit" class="btn" id="btnSiguiente">Iniciar</button>
                </form>
            </div>

            <!-- Formulario de registro -->
            <div id="registerForm" style="display: none; flex-direction: column; align-items: center;">
                <form action="index.php?controller=login&action=register" method="POST" id="formParte2" style="color: white; display: flex; flex-direction: column; align-items: center;"><br>
                    <div class="row mb-3" title="Nombres">
                        <div class="col-sm-5" style="width: 100%;">
                            <input type="text" class="form-control" name="username" id="username" placeholder="Nombres del usuario" required style="background: rgba(255, 255, 255, 0.5); color: black;">
                        </div>
                    </div>
                    <div class="row mb-3" title="Apellidos">
                        <div class="col-sm-5" style="width: 100%;">
                            <input type="text" class="form-control" name="lastname" id="lastname" placeholder="Apellidos del usuario" required style="background: rgba(255, 255, 255, 0.5); color: black;">
                        </div>
                    </div>
                    <div class="row mb-3" title="Email del usuario">
                        <div class="col-sm-5" style="width: 100%;">
                            <input type="email" class="form-control" name="email" id="emailRegister" placeholder="Correo electronico" required style="background: rgba(255, 255, 255, 0.5); color: black;">
                        </div>
                    </div>
                    <div class="row mb-3" title="Telefono">
                        <div class="col-sm-5" style="width: 100%;">
                            <input type="number" class="form-control" name="number" id="numberRegister" placeholder="Telefono" maxlength="10" pattern="\d{10}" required style="background: rgba(255, 255, 255, 0.5); color: black;">
                        </div>
                    </div>
                    <div class="row mb-3" title="Contraseña">
                        <div class="col-sm-5" style="width: 100%;">
                            <input type="password" class="form-control" name="password" placeholder="Contraseña" id="passwordRegister" required style="background: rgba(255, 255, 255, 0.5); color: black;">
                        </div>
                    </div>
                    <p style="color: white; text-align: center;">¿Ya tienes cuenta? <a href="#" style="color: #00aaff;" onclick="toggleForms()">Inicia sesión</a></p>
                    <button style="color: white; background-color: #262E55" type="submit" class="btn" id="btnRegister">Registrarse</button>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
    function toggleForms() {
        // Seleccionar los formularios y el título del modal
        const loginForm = document.getElementById('loginForm');
        const registerForm = document.getElementById('registerForm');
        const modalTitle = document.getElementById('modalTitle');

        // Alternar entre el formulario de inicio de sesión y el de registro
        if (loginForm.style.display === "none") {
            loginForm.style.display = "flex";
            registerForm.style.display = "none";
            modalTitle.textContent = "Iniciar sesión";
        } else {
            loginForm.style.display = "none";
            registerForm.style.display = "flex";
            modalTitle.textContent = "Registro";
        }
    }
</script>
